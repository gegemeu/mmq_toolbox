%MMQ_RUN_TEST_GCV_HEAT run GCV for the Heat problem
%
% Author G. Meurant Dec 2006
%

warning off

% Test problem: inverse heat equation
% (regutools/heat)

gcase = 5;
m=100;
n=100;


noise = 1E-5;
mmq_test_gcv;

pause

noise = 1E-3;
mmq_test_gcv;

pause

noise = 1E-1;
mmq_test_gcv;

pause

noise = 10;
mmq_test_gcv;


warning on