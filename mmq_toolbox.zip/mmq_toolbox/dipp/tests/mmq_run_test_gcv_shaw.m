%MMQ_RUN_TEST_GCV_SHAW run GCV for the Shaw problem
%
% Author G. Meurant Dec 2006
%

warning off

% Test problem: one-dimensional image restoration model
% (regutools/shaw)

gcase = 9;
m = 100;
n = 100;


noise = 1E-5;
mmq_test_gcv;

pause

noise = 1E-3;
mmq_test_gcv;

pause

noise = 1E-1;
mmq_test_gcv;

pause

noise = 1E1;
mmq_test_gcv;


warning on