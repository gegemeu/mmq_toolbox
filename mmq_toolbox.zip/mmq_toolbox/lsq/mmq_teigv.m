function z=mmq_teigv(n,alpha,beta,lambda,shift);
%MMQ_TEIGV computes an eigenvector of the symmetric tridiagonal matrix T
% given by alpha (diagonal) and beta (subdiagonal)
% lambda is the eigenvalue and shift the initial shift
% n is the length of alpha
% based on the work of Dhillon and Parlett (MRRR)
%
% Author G. Meurant
% June 2007
%

if shift == 0
 % find a shift using Gerschgorin bounds
 % to obtain a positive definite matrix
 r(1)=alpha(1)-abs(beta(1));
 for i=2:n-1
  r(i)=alpha(i)-(abs(beta(i-1))+abs(beta(i)));
 end
 r(n)=alpha(n)-abs(beta(n-1));
 rmin=min(r);
 if rmin > 0
  shift=0;
 else
  shift=1.5*abs(rmin);
 end
end

for k=1:5
 % factorization of T + shift I
 d(1)=alpha(1)+shift;
 for i=1:n-1
  l(i)=beta(i)/d(i);
  d(i+1)=(alpha(i+1)+shift)-l(i)*beta(i);
 end
 ind=find(d > 0);
 if length(ind) < n & shift > 0
  % the shift is too small
  shift=1.5*shift;
 else
  break
 end
end

ind=find(d > 0);
if length(ind) < n
 error('MMQ_TEIGV: the shift was too small, abort')
end
lambda=lambda+shift;

% LDL^T factorization using dstqds
s(1)=-lambda;
for i=1:n-1
 dp(i)=s(i)+d(i);
 lp(i)=(d(i)*l(i))/dp(i);
 s(i+1)=lp(i)*l(i)*s(i)-lambda;
end
dp(n)=s(n)+d(n);

% UDU^T factorization using dqds
p(n)=d(n)-lambda;
for i=n-1:-1:1
 dm(i+1)=d(i)*l(i)^2+p(i+1);
 t=d(i)/dm(i+1);
 um(i)=l(i)*t;
 p(i)=p(i+1)*t-lambda;
end
dm(1)=p(1);

% compute gamma_r
for i=1:n-1
 gamma(i)=d(i)+p(i+1)*d(i)/dm(i+1);
end
[gamma_r,r]=min(abs(gamma));
if length(r) > 1
 r=r(1);
 gamma_r=gamma_r(1);
end

% compute the eigenvector
z(r)=1;
for i=r-1:-1:1
 z(i)=-lp(i)*z(i+1);
end
for i=r:n-1
 z(i+1)=-um(i)*z(i);
end

z=z';
z=z/norm(z);


