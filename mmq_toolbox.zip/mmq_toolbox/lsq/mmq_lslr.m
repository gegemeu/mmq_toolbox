function [nt,sigt,alphat,betat,dt]=mmq_lslr(n,alpha,beta,sig,d,x,w,y);
%MMQ_LSLR least squares updating 
% Update of sig, alpha, beta, d with the data x, w, y (point, weight,
% value)
% from L. Reichel (Fast QR decomposition...)
% positive weights
%
%
% Author G. Meurant
% May 2007
%

if length(x) ~= 1 | length(w) ~= 1 | length(y) ~= 1
 error('MMQ_LSLR: must add one point at a time')
end

nt=n+1;
beta0=sig;
if n == 1
 tau=beta0;
 beta0=sqrt(beta0^2+w^2);
 gamma=tau/beta0;
 sigma=-w/beta0;
 tau=gamma*sigma*(alpha(1)-x);
 betat(1)=abs(tau);
 dt(2)=sign(tau)*(sigma*d(1)+gamma*w*y);
 dt(1)=gamma*d(1)-sigma*w*y;
 alphat(2)=sigma^2*alpha(1)+gamma^2*x;
 alphat(1)=gamma^2*alpha(1)+sigma^2*x;
 sigt=beta0;
 return
end

% n > 1
tau=beta0;
beta0=sqrt(beta0^2+w^2);
gamma=tau/beta0;
sigma=-w/beta0;
d(n+1)=sigma*d(1)+gamma*w*y;
d(1)=gamma*d(1)-sigma*w*y;
v1=gamma*sigma*(alpha(1)-x);
v2=sigma*beta(1);
v3=gamma^2*x+sigma^2*alpha(1);
alpha(1)=gamma^2*alpha(1)+sigma^2*x;
beta(1)=gamma*beta(1);

for k=1:n-2
 tau=beta(k);
 beta(k)=sqrt(beta(k)^2+v1^2);
 gamma=tau/beta(k);
 sigma=-v1/beta(k);
 tau=sigma*d(k+1)+gamma*d(n+1);
 d(k+1)=gamma*d(k+1)-sigma*d(n+1);
 d(n+1)=tau;
 tau=alpha(k+1);
 alpha(k+1)=gamma^2*tau+sigma^2*v3-2*gamma*sigma*v2;
 v1=(gamma-sigma)*(gamma+sigma)*v2+gamma*sigma*(tau-v3);
 v3=gamma^2*v3+2*gamma*sigma*v2+sigma^2*tau;
 v2=sigma*beta(k+1);
 beta(k+1)=gamma*beta(k+1);
end

tau=beta(n-1);
beta(n-1)=sqrt(beta(n-1)^2+v1^2);
gamma=tau/beta(n-1);
sigma=-v1/beta(n-1);
tau=(gamma-sigma)*(gamma+sigma)*v2+gamma*sigma*(alpha(n)-v3);
beta(n)=abs(tau);
tau=sign(tau)*(sigma*d(n)+gamma*d(n+1));
d(n)=gamma*d(n)-sigma*d(n+1);
d(n+1)=tau;
alpha(n+1)=sigma^2*alpha(n)+2*gamma*sigma*v2+gamma^2*v3;
alpha(n)=gamma^2*alpha(n)-2*gamma*sigma*v2+sigma^2*v3;
sigt=beta0;
alphat=alpha;
betat=beta;
dt=d;


