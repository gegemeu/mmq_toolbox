function [vt, dvt] = mmq_test_gcv_Vt (lambda);
%MMQ_TEST_GCV_VT computes the approximation of the GCV function and its derivative
%
% Author Urs von Matt
%
% The statement
%
%     [vt, dvt] = test_gcv_Vt (lambda)
%
% evaluates the function  Vt (lambda)  and its derivative:
%
%     vt = Vt (lambda)
%
%              d
%     dvt = ------- Vt (lambda)
%           dlambda
%
% the matrix is defined by the value of test_gcv_case

%
% communication among
% mmq_test_gcv, mmq_test_gcv_Kprod, mmq_test_gcv_V, mmq_test_gcv_Vt
%
global test_gcv_case test_gcv_sigma test_gcv_KU test_gcv_u ...
 test_gcv_KV test_gcv_v test_gcv_y;

%
% communication among
% gcv_lanczos, gcv_l_Bounds, gcv_l_Lt0, gcv_l_Lt1,
% gcv_l_Ut0, gcv_l_Ut1, test_gcv_Vt
%
global gcv_l_u;

[m_lambda, n_lambda] = size (lambda);
vt = zeros (m_lambda, n_lambda);
dvt = zeros (m_lambda, n_lambda);
N = m_lambda * n_lambda;

if test_gcv_case <= 1
 % sparse test matrix
 m = length (test_gcv_u);
 n = length (test_gcv_v);
 nu = length (gcv_l_u) / n;
 r = sum (test_gcv_sigma > 0);
 z = test_gcv_y - test_gcv_u * (test_gcv_u' * test_gcv_y);
 w = zeros (nu * n, 1);
 res = 0;
 for j = 1:nu
  w (1+(j-1)*n:j*n) = gcv_l_u (1+(j-1)*n:j*n) - ...
   test_gcv_v * (test_gcv_v' * gcv_l_u (1+(j-1)*n:j*n));
  res = res + sum (w (r+1+(j-1)*n:j*n).^2);
 end
else
 % full test matrix
 m = length (test_gcv_KU);
 n = length (test_gcv_KV);
 nu = length (gcv_l_u) / n;
 r = sum (test_gcv_sigma > 0);
 z = test_gcv_KU' * test_gcv_y;
 w = zeros (nu * n, 1);
 res = 0;
 for j = 1:nu
  w (1+(j-1)*n:j*n) = test_gcv_KV' * gcv_l_u (1+(j-1)*n:j*n);
  res = res + sum (w (r+1+(j-1)*n:j*n).^2);
 end
end

if (m > n) | (res > 0)
 for i = 1:N
  if lambda (i) < 0
   error ('MMQ_TEST_GCV_VT: lambda (i) < 0');
  end
  mu = m * lambda (i);
  t = test_gcv_sigma (1:r).^2 + mu;
  num = mu^2 * sum ((z (1:r) ./ t).^2) + sum (z (r+1:m).^2);
  nump = 2 * m * mu * sum ((test_gcv_sigma (1:r) .* z (1:r)).^2 ./ t.^3);
  den = m - n + res;
  denp = 0;
  for j = 1:nu
   den = den + mu * sum (w (1+(j-1)*n:r+(j-1)*n).^2 ./ t);
   denp = denp + m * sum ((test_gcv_sigma (1:r) .* ...
    w (1+(j-1)*n:r+(j-1)*n) ./ t).^2);
  end
  vt (i) = m * num / den^2;
  dvt (i) = m * nump / den^2 - 2 * m * num * denp / den^3;
 end
else  % (m == n) & (res == 0)
 for i = 1:N
  if lambda (i) < 0
   error ('MMQ_TEST_GCV_VT: lambda (i) < 0');
  end
  mu = m * lambda (i);
  t = test_gcv_sigma.^2 + mu;
  num = sum ((z ./ t).^2);
  nump = -2 * m * sum (z.^2 ./ t.^3);
  den = 0;
  denp = 0;
  for j = 1:nu
   den = den + sum (w (1+(j-1)*n:j*n).^2 ./ t);
   denp = denp - m * sum ((w (1+(j-1)*n:j*n) ./ t).^2);
  end
  
  vt (i) = m * num / den^2;
  dvt (i) = m * nump / den^2 - 2 * m * num * denp / den^3;
 end
end
