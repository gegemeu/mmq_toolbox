%MMQ_TEST_L_CORNER compute the regularization parameters
% finding the corner of the L-curve

% Needs Regutools
%
% Author G. Meurant 
% Feb 2007
%
%
global test_gcv_case test_gcv_sigma test_gcv_KU test_gcv_u ...
 test_gcv_KV test_gcv_v test_gcv_u test_gcv_y;

global gcv_func_min gcv_func_max;

% clear all figures
close all

fprintf (1, '\n\nMMQ_TEST_L_CORNER\n--------\n\n');

% reset random number generators
% the choice affects the noise which is added
% to reproduce the results of the Golub and von Matt paper
% choose the Matlab 4 generator

% Matlab 4 random number generator
rand ('seed', 0);
% Matlab 6,... random number generator
%rand('state',0);
randn ('seed', 0);
%randn('state',0);

test_gcv_case = gcase;
r = min (m, n);

plotsol = 0;
lc0=1;
lc=1;
lp=1;
lc1=1;
lc2=1;


if gcase == 1
 fprintf (1, 'Test problem with exponential singular value distribution.\n');
 fprintf (1, '(c = %11.4e)\n', c);
 
 % generate the singular values using c (set in run_test_gcv...)
 test_gcv_sigma = exp (-abs (c) * [1:r]');
 % generate random vectors
 test_gcv_u = randn (m, 1);
 test_gcv_u = (sqrt (2) / norm (test_gcv_u, 2)) * test_gcv_u;
 test_gcv_v = randn (n, 1);
 test_gcv_v = (sqrt (2) / norm (test_gcv_v, 2)) * test_gcv_v;
 normK = max (test_gcv_sigma);
 
 x0 = randn (n, 1);
 % matrix vector product using the SVD
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 2
 fprintf (1, 'Test problem: Fredholm integral equation of the first kind.\n');
 fprintf (1, '(regutools/baart)\n');
 if m ~= n
  error ('MMQ_TEST_L_CORNER: m ~= n');
 end
 
 % generate the problem using regutools
 [K, y, x0] = baart (n);
 % compute the SVD
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 3
 fprintf (1, 'Test problem: computation of the second derivative.\n');
 fprintf (1, '(regutools/deriv2)\n');
 if m ~= n
  error ('MMQ_TEST_L_CORNER: m ~= n');
 end
 
 [K, y, x0] = deriv2 (n, 1);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 4
 fprintf (1, 'Severely ill-posed test problem.\n');
 fprintf (1, '(regutools/foxgood)\n');
 if m ~= n
  error ('MMQ_TEST_L_CORNER: m ~= n');
 end
 
 [K, y, x0] = foxgood (n);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 5
 fprintf (1, 'Test problem: inverse heat equation.\n');
 fprintf (1, '(regutools/heat)\n');
 if m ~= n
  error ('MMQ_TEST_L_CORNER: m ~= n');
 end
 
 kappa = 1;
 [K, y, x0] = heat (n, kappa);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 6
 fprintf (1, 'Test problem: inverse Laplace transformation.\n');
 fprintf (1, '(regutools/ilaplace)\n');
 if m ~= n
  error ('MMQ_TEST_L_CORNER: m ~= n');
 end
 
 example = 1;
 [K, y, x0] = ilaplace (n, example);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 7
 fprintf (1, 'Stellar parallax problem with 28 fixed, real observations.\n');
 fprintf (1, '(regutools/parallax)\n');
 
 [K, y0] = parallax (n);
 % the exact solution x0 is unknown
 x0 = zeros (n, 1);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 
elseif gcase == 8
 fprintf (1, 'Phillips''s "famous" test problem.\n');
 fprintf (1, '(regutools/phillips)\n');
 if m ~= n
  error ('MMQ_TEST_L_CORNER: m ~= n');
 end
 
 [K, y, x0] = phillips (n);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 9
 fprintf (1, 'Test problem: one-dimensional image restoration model.\n');
 fprintf (1, '(regutools/shaw)\n');
 if m ~= n
  error ('MMQ_TEST_L_CORNER: m ~= n');
 end
 
 [K, y, x0] = shaw (n);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 10
 fprintf (1, 'Test problem with a "spiky" solution.\n');
 fprintf (1, '(regutools/spikes)\n');
 if m ~= n
  error ('MMQ_TEST_L_CORNER: m ~= n');
 end
 
 t_max = 5;
 [K, y, x0] = spikes (n, t_max);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 11
 fprintf (1, 'Test problem: integral equation with no square integrable solution.\n');
 fprintf (1, '(regutools/ursell)\n');
 if m ~= n
  error ('MMQ_TEST_L_CORNER: m ~= n');
 end
 
 [K, y0] = ursell (n);
 % there is no square integrable solution
 x0 = zeros (n, 1);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 
elseif gcase == 12
 fprintf (1, 'Test problem with a discontinuous solution.\n');
 fprintf (1, '(regutools/wing)\n');
 if m ~= n
  error ('MMQ_TEST_L_CORNER: m ~= n');
 end
 
 t1 = 1/3;
 t2 = 2/3;
 [K, y, x0] = wing (n, t1, t2);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
 
elseif gcase == 13
 fprintf (1, 'Test problem with a blurred image\n');
 fprintf (1, '(regutools/blur\n');
 if m ~= n
  error ('MMQ_TEST_L_CORNER: m ~= n');
 end
 
 [K, y, x0] = blur (n);
 K=full(K);
 [m,n]=size(K);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 r=rank(K);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
else
 error ('MMQ_TEST_L_CORNER: invalid value of gcase');
end

tmp=test_gcv_sigma;
ntmp=length(tmp);
tmp=sort(tmp);
test_gcv_sigma=tmp(ntmp:-1:1);

fprintf (1, 'm          = %5i\n', m);
fprintf (1, 'n          = %5i\n', n);
fprintf (1, 'sigma (1)  = %11.4e    sigma (%i) = %11.4e\n', ...
 test_gcv_sigma (1), r, test_gcv_sigma (r));
fprintf (1, 'cond (K)   = %11.4e\n', ...
 test_gcv_sigma (1) / test_gcv_sigma (r));
fprintf (1, 'noise      = %11.4e\n\n', noise);

pause

% generate the noise and the perturbed right hand side
y=mmq_noisy(y0,noise);
test_gcv_y = y;

if plotsol == 1
 figure
 plot(x0)
 title(['solution, noise = ' num2str(noise)])
 hold on
end

% compute the L-curve

[rho,eta,mu,err]=mmq_comp_l_curve(K,y,200,x0);

[tmp,ind]=min(err);
mu_opt=mu(ind)/m;
fprintf (1, '\n');
fprintf (1, 'Optimal l_curve: nu = %11.4e  mu = %11.4e\n\n', mu_opt,m*mu_opt);
fprintf (1, '\n');
% compute the regularized solution  x (lambda) using the SVD
if gcase == 1
 % large test problem
 x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
 x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * mu_opt);
 x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
else
 % small test problem
 x = test_gcv_KU (:, 1:r)' * y;
 x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * mu_opt);
 x = test_gcv_KV (:, 1:r) * x;
end
% compute the norm  of the residual and the error
fprintf (1, '|| y - K * x (lambda) ||_2 = %11.4e\n', ...
 norm (y - mmq_test_gcv_Kprod ('N', m, n, x)));
fprintf (1, '|| x (lambda) - x0 ||_2    = %11.4e\n', norm (x - x0, 2));
fprintf (1, '|| x (lambda) ||_2    = %11.4e\n', norm (x, 2));

[rho,eta,mu,err]=mmq_comp_l_curve(K,y,50,x0);

if lc0 == 1
 % compute the regularization parameter from the L-curve
 % old Regutools
 disp('-----------------------')
 if gcase == 1
  [regutools_l_curve, G, reg_param] = ...
   mmq_l_curve (test_gcv_u, test_gcv_sigma, test_gcv_y);
 else
  [regutools_l_curve, G, reg_param] = ...
   mmq_l_curve (test_gcv_KU, test_gcv_sigma, test_gcv_y);
 end
 regutools_l_curve = regutools_l_curve^2 / m;
 fprintf (1, '\n');
 fprintf (1, 'Old Regutools l_curve: nu = %11.4e  mu = %11.4e\n\n', regutools_l_curve,m*regutools_l_curve);
 
 if regutools_l_curve > 0
  % compute the regularized solution  x (lambda) using the SVD
  if gcase == 1
   % large test problem
   x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * regutools_l_curve);
   x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
  else
   % small test problem
   x = test_gcv_KU (:, 1:r)' * y;
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * regutools_l_curve);
   x = test_gcv_KV (:, 1:r) * x;
  end
  % compute the norm  of the residual and the error
  fprintf (1, '|| y - K * x (lambda) ||_2 = %11.4e\n', ...
   norm (y - mmq_test_gcv_Kprod ('N', m, n, x)));
  fprintf (1, '|| x (lambda) - x0 ||_2    = %11.4e\n', norm (x - x0, 2));
  fprintf (1, '|| x (lambda) ||_2    = %11.4e\n', norm (x, 2));
  
  if plotsol == 1
   plot(x,':+')
  end
 else
  fprintf (1, 'lambda <= 0\n');
 end
 if plotsol == 1
  pause
 end
end 

if lc == 1
 % compute the regularization parameter from the L-curve
 % from Regutools
 disp('-----------------------')
 if gcase == 1
 fprintf (1, '\n');
 fprintf (1, 'Regutools l_curve: cannot handle gcase=1\n\n');
 regutools_l_curve=0;
 else
  [regutools_l_curve, G, reg_param] = ...
   l_curve (test_gcv_KU, test_gcv_sigma, test_gcv_y);
 end
 regutools_l_curve = regutools_l_curve^2 / m;
 fprintf (1, '\n');
 fprintf (1, 'Regutools l_curve: nu = %11.4e  mu = %11.4e\n\n', regutools_l_curve,m*regutools_l_curve);
 
 if regutools_l_curve > 0
  % compute the regularized solution  x (lambda) using the SVD
  if gcase == 1
   % large test problem
   x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * regutools_l_curve);
   x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
  else
   % small test problem
   x = test_gcv_KU (:, 1:r)' * y;
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * regutools_l_curve);
   x = test_gcv_KV (:, 1:r) * x;
  end
  % compute the norm  of the residual and the error
  fprintf (1, '|| y - K * x (lambda) ||_2 = %11.4e\n', ...
   norm (y - mmq_test_gcv_Kprod ('N', m, n, x)));
  fprintf (1, '|| x (lambda) - x0 ||_2    = %11.4e\n', norm (x - x0, 2));
  fprintf (1, '|| x (lambda) ||_2    = %11.4e\n', norm (x, 2));
  
  if plotsol == 1
   plot(x,':+')
  end
 else
  fprintf (1, 'lambda <= 0\n');
 end
 if plotsol == 1
  pause
 end
end

if lp == 1
 % compute the regularization parameter from the L-curve
 % using the pruning algorithm of Hansen and Rodriguez
 disp('-----------------------')
 if gcase == 1
 fprintf (1, '\n');
 fprintf (1, 'MMQ_TEST_L_CORNER: Pruning l_curve: cannot handle gcase=1\n\n');
 regutools_l_curve=0;
 else
  % reverse rho and eta
  rh=rho(end:-1:1);
  et=eta(end:-1:1);
  fig=0;
  
  [k_corner, info] = mmq_corner(rh, et, fig);
  
  if info > 0
   info
  end
  % k_corner is relative to the reversed curves
  k_corner=length(rho)-k_corner+1;
  pruning_l_curve=mu(k_corner);
 end
 pruning_l_curve = pruning_l_curve / m;
 fprintf (1, '\n');
 fprintf (1, 'Pruning l_curve: nu = %11.4e  mu = %11.4e\n\n', pruning_l_curve,m*pruning_l_curve);
 
 if pruning_l_curve > 0
  % compute the regularized solution  x (lambda) using the SVD
  if gcase == 1
   % large test problem
   x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * pruning_l_curve);
   x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
  else
   % small test problem
   x = test_gcv_KU (:, 1:r)' * y;
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * pruning_l_curve);
   x = test_gcv_KV (:, 1:r) * x;
  end
  % compute the norm  of the residual and the error
  fprintf (1, '|| y - K * x (lambda) ||_2 = %11.4e\n', ...
   norm (y - mmq_test_gcv_Kprod ('N', m, n, x)));
  fprintf (1, '|| x (lambda) - x0 ||_2    = %11.4e\n', norm (x - x0, 2));
  fprintf (1, '|| x (lambda) ||_2    = %11.4e\n', norm (x, 2));
  
  if plotsol == 1
   plot(x,':+')
  end
 else
  fprintf (1, 'lambda <= 0\n');
 end
 if plotsol == 1
  pause
 end
end

if lc1 == 1
 % compute the regularization parameter from the L-curve
 % by algorithm lc1 rotating the L-curve
 disp('-----------------------')
 if gcase == 1
 fprintf (1, '\n');
 fprintf (1, 'MMQ_TEST_L_CORNER: lc1 l_curve, cannot handle gcase=1\n\n');
 reg_corner_rot=0;
 else
 
  reg_corner_rot=mmq_l_curve_rot(K,y);
 
 end
 reg_corner_rot = reg_corner_rot / m;
 fprintf (1, '\n');
 fprintf (1, 'lc1 l_curve: nu = %11.4e  mu = %11.4e\n\n', reg_corner_rot,m*reg_corner_rot);
 
 if reg_corner_rot > 0
  % compute the regularized solution  x (lambda) using the SVD
  if gcase == 1
   % large test problem
   x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * reg_corner_rot);
   x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
  else
   % small test problem
   x = test_gcv_KU (:, 1:r)' * y;
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * reg_corner_rot);
   x = test_gcv_KV (:, 1:r) * x;
  end
  % compute the norm  of the residual and the error
  fprintf (1, '|| y - K * x (lambda) ||_2 = %11.4e\n', ...
   norm (y - mmq_test_gcv_Kprod ('N', m, n, x)));
  fprintf (1, '|| x (lambda) - x0 ||_2    = %11.4e\n', norm (x - x0, 2));
  fprintf (1, '|| x (lambda) ||_2    = %11.4e\n', norm (x, 2));
  
  if plotsol == 1
   plot(x,':+')
  end
 else
  fprintf (1, 'lambda <= 0\n');
 end
 if plotsol == 1
  pause
 end
end

if lc2 == 1
 % compute intervals for the regularization parameter from the L-curve
 % by algorithm lc2 
 disp('-----------------------')
 if gcase == 1
  fprintf (1, '\n');
  fprintf (1, 'MMQ_TEST_L_CORNER: lc2 l_curve, cannot handle gcase=1\n\n');
  reg_corner_lc2=0;
  n_interval=0;
 else
 
  [reg_interval,n_interval]=mmq_l_interval(K,y,1e-2);
 
 end
 if n_interval > 0
  reg_interval=reg_interval/m;
  fprintf (1, '\n');
  fprintf (1, 'lc2 l_curve: nb of intervals = %5i\n\n',n_interval);
  fprintf (1, '\n');
  for i=1:n_interval
   fprintf (1, ' numin = %11.4e numax = %11.4e  mumin = %11.4e mumax = %11.4e\n\n', ...
    reg_interval(i,1),reg_interval(i,2),m*reg_interval(i,1),m*reg_interval(i,2));
  end
  
  if n_interval == 1 
   % compute the regularized solution  x (lambda) using the SVD
   % for the ends of the interval
   for i=1:2
    reg_i=reg_interval(1,i);
    if gcase == 1
     % large test problem
     x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
     x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * reg_i);
     x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
    else
     % small test problem
     x = test_gcv_KU (:, 1:r)' * y;
     x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * reg_i);
     x = test_gcv_KV (:, 1:r) * x;
    end
    % compute the norm  of the residual and the error
    fprintf (1, '|| y - K * x (lambda) ||_2 = %11.4e\n', ...
     norm (y - mmq_test_gcv_Kprod ('N', m, n, x)));
    fprintf (1, '|| x (lambda) - x0 ||_2    = %11.4e\n', norm (x - x0, 2));
    fprintf (1, '|| x (lambda) ||_2    = %11.4e\n', norm (x, 2));
    fprintf (1, '\n');
    
    if plotsol == 1
     plot(x,':+')
    end
   end
  end
 else
  fprintf (1, 'lambda <= 0\n');
 end
 if plotsol == 1
  pause
 end
end