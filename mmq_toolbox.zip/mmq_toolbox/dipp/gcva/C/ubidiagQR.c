/* ubidiagQR.c, MATLAB Version 6

   The calling syntax is:

       [Q, u, v] = ubidiagQR (gamma, delta, mu)

   This procedure computes the QR-decomposition of the (2n)-by-n
   matrix

       [  U   ]
       [      ]
       [ mu*I ]

   where U is an n-by-n upper bidiagonal matrix:

           [ gamma(1)  delta(1)                       ]
           [             ...     ...                  ]
       U = [                     ...  ...             ]
           [                          ...  delta(n-1) ]
           [                                gamma(n)  ]

   Urs von Matt, October 26, 1994 */
   /* modified by G. Meurant, Dec 06 */



#include <math.h>
#include "mex.h"
#include "blas.c"



static void ubidiagQR (n, gamma, delta, mu, Q, u, v)
  int    n;
  double *gamma, *delta, mu, *Q, *u, *v;

{ int    i, ldQ;
  double t, mutmp;

  ldQ = 2*n - 1;
  u [0] = gamma [0];
  mutmp = mu;
  rotg (&u [0], &mutmp, &Q [0], &Q [ldQ]);
  for (i = 1; i < n; i++) {
    v [i-1] = delta [i-1];
    t = 0.0;
    rot (&v [i-1], &t, Q [2*i-2], Q [2*i-2 + ldQ]);
    mutmp = mu;
    rotg (&mutmp, &t, &Q [2*i-1], &Q [2*i-1 + ldQ]);
    u [i] = gamma [i];
    rotg (&u [i], &mutmp, &Q [2*i], &Q [2*i + ldQ]);
  }
}



#define max(A, B)  ((A) > (B) ? (A) : (B))
#define min(A, B)  ((A) < (B) ? (A) : (B))

/* Input Arguments */
#define	gamma prhs[0]
#define	delta prhs[1]
#define	mu    prhs[2]

/* Output Arguments */
#define	Q plhs[0]
#define	u plhs[1]
#define	v plhs[2]

void mexFunction(
    int nlhs, mxArray *plhs[],
    int nrhs, const mxArray *prhs[])

{ int n;

  /* Check for proper number of arguments */
  if (nrhs != 3) {
    mexErrMsgTxt ("ubidiagQR requires three input arguments.");
  } else if (nlhs != 3) {
    mexErrMsgTxt ("ubidiagQR requires three output arguments.");
  }

  /* Check the dimensions of gamma. */
  n = max (mxGetM (gamma), mxGetN (gamma));
  if (min (mxGetM (gamma), mxGetN (gamma)) != 1) {
    mexErrMsgTxt ("gamma must be an n-by-1 or a 1-by-n matrix.");
  }

  /* Check the dimensions of delta. */
  if (n > 1) {
    if ((min (mxGetM (delta), mxGetN (delta)) != 1) ||
        (max (mxGetM (delta), mxGetN (delta)) != n-1)) {
      mexErrMsgTxt ("delta must be an (n-1)-by-1 or a 1-by-(n-1) matrix.");
    }
  }

  /* Check the dimensions of mu. */
  if ((mxGetM (mu) != 1) || (mxGetN (mu) != 1)) {
    mexErrMsgTxt ("mu must be a scalar.");
  }

  /* Create matrices for the return arguments. */
  /* Q = mxCreateFull (2*n-1, 2, REAL); */
  Q = mxCreateDoubleMatrix(2*n-1,2, mxREAL);
  
  /* u = mxCreateFull (n, 1, REAL); */
  u = mxCreateDoubleMatrix(n,1, mxREAL);
  
  /* v = mxCreateFull (n-1, 1, REAL); */
  v = mxCreateDoubleMatrix(n-1,1, mxREAL);

  /* Do the actual computations in a subroutine. */
  ubidiagQR (n, mxGetPr (gamma), mxGetPr (delta), *mxGetPr (mu),
             mxGetPr (Q), mxGetPr (u), mxGetPr (v));
}
