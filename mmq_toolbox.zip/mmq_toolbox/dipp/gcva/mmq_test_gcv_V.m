function [v, dv] = mmq_test_gcv_V (lambda)
%MMQ_TEST_GCV_V computes the GCV function and its derivative
%
% Author Urs von Matt
%
% The statement
%
%     [v, dv] = test_gcv_V (lambda)
%
% evaluates the function  V (lambda)  and its derivative:
%
%     v = V (lambda)
%
%             d
%     dv = ------- V (lambda)
%          dlambda
%
% the matrix is defined by the value of test_gcv_case

%
% communication among
% mmq_test_gcv, mmq_test_gcv_Kprod, mmq_test_gcv_V, mmq_test_gcv_Vt
%
global test_gcv_case test_gcv_sigma test_gcv_KU test_gcv_u ...
 test_gcv_KV test_gcv_v test_gcv_y;

[m_lambda, n_lambda] = size (lambda);
v = zeros (m_lambda, n_lambda);
dv = zeros (m_lambda, n_lambda);
N = m_lambda * n_lambda;

if test_gcv_case <= 1
 % sparse test matrix
 m = length (test_gcv_u);
 n = length (test_gcv_v);
 r = sum (test_gcv_sigma > 0);
 z = test_gcv_y - test_gcv_u * (test_gcv_u' * test_gcv_y);
else
 % full test matrix
 m = length (test_gcv_KU);
 n = length (test_gcv_KV);
 r = sum (test_gcv_sigma > 0);
 z = test_gcv_KU' * test_gcv_y;
end

if m > r
 for i = 1:N
  if lambda (i) < 0
   error ('MMQ_TEST_GCV_V: lambda (i) < 0');
  end
  mu = m * lambda (i);
  t = test_gcv_sigma (1:r).^2 + mu;
  num = mu^2 * sum ((z (1:r) ./ t).^2) + sum (z (r+1:m).^2);
  den = m - r + mu * sum (1 ./ t);
  v (i) = m * num / den^2;
  dv (i) = 2 * m^2 * mu * ...
   sum ((test_gcv_sigma (1:r) .* z (1:r)).^2 ./ t.^3) / den^2 - ...
   2 * m^2 * ...
   num * sum ((test_gcv_sigma (1:r) ./ t).^2) / den^3;
 end
else  % m == r
 for i = 1:N
  if lambda (i) < 0
   error ('MMQ_TEST_GCV_V: lambda (i) < 0');
  end
  mu = m * lambda (i);
  t = test_gcv_sigma.^2 + mu;
  v (i) = m * sum ((z ./ t).^2) / (sum (1 ./ t))^2;
  dv (i) = 2 * m^2 * ...
   (sum ((z ./ t).^2) * sum (1 ./ t.^2) - ...
   sum (z.^2 ./ t.^3) * sum (1 ./ t)) / ...
   (sum (1 ./ t))^3;
 end
end
