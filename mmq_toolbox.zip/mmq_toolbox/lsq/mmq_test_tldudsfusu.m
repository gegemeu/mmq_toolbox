function [n,sig,alpha,beta,d]=mmq_test_tldudsfusu(N,ix);
%MMQ_TEST_TLDUDSFUSU computes the solution by updating
%
% Author G. Meurant
% June 2007
%

[x,w,y,ier]=mmq_pwv(N,ix);
if ier == 1
 disp('MMQ_TEST_TLDUDSFUSU:  Unknown problem, abort')
 return
end

% recursively build the solution
sig=abs(w(1));
alpha(1)=x(1);
beta(1)=0;
d(1)=y(1)*sig;

n=1;
for i=1:N-1
 % update
 [n,sig,alpha,beta,d]=mmq_tldudsfus(i,alpha,beta,sig,d,x(i+1),w(i+1),y(i+1),1);
 %disp('update tldudsfus-----------------------')
 %n
 if n ~= i+1
  disp('MMQ_TEST_TLDUDSFUSU: pb in updating')
  [i n]
 end
end

