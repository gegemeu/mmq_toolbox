function mmq_plotsecul5(d,c);
%MMQ_PLOTSECUL5 plots figures of the TLS secular equation (other form)
% the function is defined in secul
%
% Author G. Meurant
% july 2007
%
warning off

km=length(d);
lmin=min(d(:));
lmax=max(d(:));
dta=sort(d);
lmm=lmax-lmin;
ymax=10;
ymin=-10;

k=km;
 
% we  need the components squared
xi=(c(:).^2);
figure
hold on

% plot the poles
for i=1:k
  plot([d(i) d(i)],[-ymax ymax],'--')
end

% plot the function between the k poles 
lamb=[lmin-3 d(:)' lmax+2];
for i=1:k+1
  epsi1=(lamb(i+1)-lamb(i))*1e-5;
  epsi2=epsi1;
  if i == 1
    epsi1=-lmin/2;
    epsii=epsi1;
  end
  if i == k+1
    epsi2=-lmin/2;
  end
  x=linspace(lamb(i)+epsi1,lamb(i+1)-epsi2,50);
  y=secul(xi,d,x);
  plot(x,y)
end

% plot( the x axis
plot([min(lamb) max(lamb)],[0 0],'-.')
axis([min(lamb) max(lamb) -ymax ymax])
title(['TLS secular function'])
hold off

warning on

end

function y=secul(xi,dts,x);
%SECUL function f
%
k=length(x);
kd=length(dts);
for i=1:k
  z=xi(1:kd).^2*x(i)^2./(dts(:).^2-x(i)^2);
  y(i)=(x(i)^2+sum(z)-sum(xi(kd+1:end).^2));
end

end
