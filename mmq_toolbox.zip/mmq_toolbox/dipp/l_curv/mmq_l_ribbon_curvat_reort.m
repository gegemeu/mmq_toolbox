function [mul,muu]=mmq_l_ribbon_curvat_reort(a,y,kmax);
%MMQ_L_RIBBON_CURVAT_REORT computes the curvatures of the L-ribbon approximations
% after kmax iterations with reorthogonalization
%
% Lanczos bidiagonalization to compute lower and upper bounds of the L-curve
%
% Author G. Meurant
% Feb 2007
%

ny=norm(y);
naty=norm(a'*y);

% compute the exact L-curve and the limits

np=50;
[rho,eta,mu,lambdamin,lambdamax]=mmq_comp_l_curve1(a,y,np);
lambdamin
lambdamax

aa=log10(lambdamin);
bb=log10(lambdamax);

% t refers to values of log(lambda)
n=50;
t=linspace(aa,bb,n);
mu=10.^t;

% start the Lanczos iterations
% similar to l_bidiagaat

k=kmax;
c=sparse(k+1,k+1);
uu=zeros(length(y),k+1);
vv=uu;

% init
u_old=y/norm(y);
w=a'*u_old;
c(1,1)=norm(w);
v_old=w/c(1,1);
uu(:,1)=u_old;
vv(:,1)=v_old;

for i=2:k+1
 w=a*v_old-c(i-1,i-1)*u_old;
 c(i,i-1)=norm(w);
 u=w/c(i,i-1);
 
 % reorthogonalization
 
 for j=1:i-1
  alpha=u'*uu(:,j);
  u=u-alpha*uu(:,j);
  u=u/norm(u);
 end
 
 w=a'*u-c(i,i-1)*v_old;
 c(i,i)=norm(w);
 v=w/c(i,i);
 
 % reorthogonalization
 
 for j=1:i-1
  alpha=v'*vv(:,j);
  v=v-alpha*vv(:,j);
  v=v/norm(v);
 end
 
 uu(:,i)=u;
 vv(:,i)=v;
 
 u_old=u;
 v_old=v;
 
end
% end of Lanczos iterations

i=k+1;

cc=c(1:i-1,1:i-1);
ccb=c(1:i,1:i-1);
[q,cch]=qr(full(ccb));
cch=cch(1:end-1,:);
if any(diag(cch) < 0)
 cch=-cch;
end
cch=cch';
% remove the last column
cchb=cch(:,1:end-1);

% compute the approximations using SVDs rather than
% solving least squares problems
[ucc,scc,vcc]=svd(full(cc));
scc=diag(scc);
[uccb,sccb,vccb]=svd(full(ccb));
sccb=diag(sccb);
[ucch,scch,vcch]=svd(full(cch));
scch=diag(scch);
[ucchb,scchb,vcchb]=svd(full(cchb));
scchb=diag(scchb);

gcc=mmq_comp_l_ribbon(mu,ucc,scc,vcc);
lbr=ny^2*mu.^2.*gcc;

gccb=mmq_comp_l_ribbon(mu,uccb,sccb,vccb);
ubr=ny^2*mu.^2.*gccb;

gcch=mmq_comp_l_ribbon(mu,ucch,scch,vcch);
lbx=naty^2*gcch;

gcchb=mmq_comp_l_ribbon(mu,ucchb,scchb,vcchb);
ubx=naty^2*gcchb;

pcch=mmq_comp_l_ribbon1(mu,ucch,scch,vcch);
ubxp=-4*(naty^2*pcch);

pcchb=mmq_comp_l_ribbon1(mu,ucchb,scchb,vcchb);
lbxp=-4*(naty^2*pcchb);

taul=2*(lbx.*lbr)./(mu.^2.*ubx.^2+ubr.^2).^(3/2);
tauu=2*(ubx.*ubr)./(mu.^2.*lbx.^2+lbr.^2).^(3/2);

xil=mu.*lbr+mu.^2.*lbx+2*ubr.*(ubx./ubxp);
xiu=mu.*ubr+mu.^2.*ubx+2*lbr.*(lbx./lbxp);

cl=zeros(length(mu),1);
cu=cl;
for j=1:length(mu)
 if xil(j) >= 0
  cl(j)=taul(j)*xil(j);
 else
  cl(j)=tauu(j)*xil(j);
 end
 if xiu(j) >= 0
  cu(j)=tauu(j)*xiu(j);
 else
  cu(j)=taul(j)*xiu(j);
 end
end

curl=-cu;
curu=-cl;

plots=0;
if plots
 semilogx(sqrt(mu),curl)
 hold on
 semilogx(sqrt(mu),curu,'r')
 hold off
end

[tmp,kl]=max(curl);
[tmp,ku]=max(curu);

[max(curl) max(curu)]

% the corner is given by the corresponding value of t
mul=mu(kl);
muu=mu(ku);

m=size(a,1);
[mul/m muu/m]





