%
% Contents of Tikh
%
% MMQ_DISCREP compute the regularization parameter from the discrepancy
% MMQ_DISCREP_F used by mmq_discrep in mmq_l_newton
% MMQ_GFRERER compute the regularization parameter from the Gfrerer/Raus
% MMQ_GFRERER_F used by mmq_gfrerer in mmq_l_newton
% MMQ_L_NEWTON Newton's iterations used by mmq_discrep
% MMQ_QUASIOPT Quasi-optimality criterion for choosing the regularization parameter

