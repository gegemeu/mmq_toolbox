function [mu,mux,mut]=mmq_backls(a,b,x,teta);
%MMQ_BACKLS computes the backward error of a least squares problem
% computes the "exact" parameter mu
% mut the approximation using the SVD 
% and mux the approximation using the secular equation
%
% x approximate solution
% teta = 0 corresponds to Data Least Squares
%
% it is better to use mmq_lanczos_bk to compute an approximation of mu when a is large
%
% Author G. Meurant
% Aug 2008
%

global lm;

nx=norm(x);
nx2=nx*nx;

if teta == 0
 % DLS
 nu=1;
else
 nu=(teta^2*nx2)/(1+teta^2*nx2);
end

% residual
r=b-a*x;

aa=a*a'-(nu/nx2)*r*r';

vpaa=eig(full(aa));
vpaa=sort(real(vpaa));
lm=min(vpaa);

% "exact" value
nur=nu*r'*r/nx2;
mu2=nur+ min(0,lm);
if mu2 > 0
 mu=sqrt(mu2);
else
 mu=0;
end

[m,n]=size(a);
d=sqrt(nu)*r/nx;
% full SVD
[U,S,V]=svd(a);
sig=diag(S);
sigg=sig;
[sig,ind]=sort(sig);
f=U'*d;
ru=U'*r;
y=sigg.*ru(1:n);
sig=sig.^2;
xi(1)=sum(f(n+1:m).^2);
xi(2:n+1)=f(ind).^2;
xi=sqrt(xi);

% solve the secular equation
[xf,it,xs]=mmq_solve_secul_bk(sig,f,1e-10,'b1');

mux2=nur+ min(0,xf);
if mux2 > 0
 mux=sqrt(mux2);
else
 mux=0;
end

rx=norm(r)^2/nx2;
mut2=sum(y.^2./(sigg.^2+rx))/nx2;
mut=sqrt(mut2);

