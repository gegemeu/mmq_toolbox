function [alpha,beta,w]=mmq_qlsweep(alpha,beta,sigma,w);
%MMQ_QLSWEEP one step of implicit shift QL with shift sigma
% from Laurie's paper
% w is a vector (weights)

% Author G. Meurant
% June 2007
%

n=length(alpha);
if n == 1
 return
end

x=alpha(n)-sigma;
z=beta(n-1);

% last rotation
 [c,s,c2,s2,cs]=mmq_givensu(x,z);
 csb=2*cs*beta(n-1);
 tkk=c2*alpha(n-1)-csb+s2*alpha(n);
 tk1k1=s2*alpha(n-1)+csb+c2*alpha(n);
 tk1k=beta(n-1)*(c2-s2)+cs*(alpha(n-1)-alpha(n));
 wn1=c*w(n-1)-s*w(n);
 wn=s*w(n-1)+c*w(n);
 
 alpha(n-1)=tkk;
 alpha(n)=tk1k1;
 beta(n-1)=tk1k;
 w(n-1)=wn1;
 w(n)=wn;
 
 if n > 2
  z=s*beta(n-2);
  beta(n-2)=c*beta(n-2);
 else
  return
 end

% chase the bulge z up the diagonal
for k=n-1:-1:3
 x=beta(k);
 [c,s,c2,s2,cs]=mmq_givensu(x,z);
 csb=2*cs*beta(k-1);
 tkk=c2*alpha(k-1)-csb+s2*alpha(k);
 tkkm1=c*beta(k)+s*z;
 tk1k1=s2*alpha(k-1)+csb+c2*alpha(k);
 tk1k=beta(k-1)*(c2-s2)+cs*(alpha(k-1)-alpha(k));
 z=s*beta(k-2);
 tk2k1=c*beta(k-2);
 wkm1=c*w(k-1)-s*w(k);
 wk=s*w(k-1)+c*w(k);
 
 alpha(k-1)=tkk;
 beta(k)=tkkm1;
 alpha(k)=tk1k1;
 beta(k-1)=tk1k;
 beta(k-2)=tk2k1;
 w(k-1)=wkm1;
 w(k)=wk;
end

x=beta(2);
[c,s,c2,s2,cs]=mmq_givensu(x,z);
csb=2*cs*beta(1);
t11=c2*alpha(1)-csb+s2*alpha(2);
t21=beta(1)*(c2-s2)+cs*(alpha(1)-alpha(2));
t22=s2*alpha(1)+csb+c2*alpha(2);
t32=c*beta(2)+s*z;
w1=c*w(1)-s*w(2);
w2=s*w(1)+c*w(2);

alpha(1)=t11;
beta(1)=t21;
alpha(2)=t22;
beta(2)=t32;
w(1)=w1;
w(2)=w2;
 

 
 
