%
% Contents of Traces
%
% computation of the trace of the inverse and/or the determinant 
% of a symmetric matrix
%
% MMQ_BOUNDS_TRDET Golub and Bai bounds for the determinant of a
% MMQ_BOUNDS_TRIA Golub and Bai bounds for the trace of the inverse of a
% MMQ_CHEBYSHIFT coefficients of the shifted Chebyshev polynomials
% MMQ_EST_TRDET estimate of the determinant of a using moments
% MMQ_EST_TRDETZ_RAND estimate of the determinant of a using logm
% MMQ_EST_TRDET_MOD estimate of the determinant of a using modified moments
% MMQ_EST_TRDET_RAND estimate of the determinant of a (symmetric) with Monte Carlo and Lanczos
% MMQ_EST_TRIA estimate of the trace of the inverse of a using moments
% MMQ_EST_TRIA_MOD estimate of the trace of the inverse of a using modified moments
% MMQ_EST_TRIA_MOD_RAND estimate of the trace of the inverse of a (mod moments + Monte Carlo)
% MMQ_EST_TRIA_RAND estimate of the trace of the inverse of a with moments + Monte Carlo
% MMQ_EST_TRPS_MOD estimate of the partial sums of the eigenvalues of a (< mu)
% MMQ_GENORTHOPOL coefficients of the recurrence of orthogonal polynomials
% MMQ_MODIFCHEB modified Chebyshev algorithm for general orthogonal polynomials
% MMQ_RANDN_PMONE generate a vector with components 1 and -1 with equal probability
% MMQ_RAND_PMONE generate a vector with components 1 and -1 with equal probability
% MMQ_TRACE_CHEBYSHIFT traces of the matrices given by the shifted Chebyshev recurrence
% MMQ_TRACE_CHEBYSHIFTZ product z' C_l z given by the shifted Chebyshev recurrence