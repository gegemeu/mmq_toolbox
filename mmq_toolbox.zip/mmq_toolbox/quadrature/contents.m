%
% Contents of Quadrature
%
% computation of Gauss quadrature rules
%
% MMQ_AGAUSSQUAD anti-Gauss quadrature for 1/(2+x) and the Jacobi matrix tt
% MMQ_AGAUSSQUADK computes the anti-Gauss of  the integral of 1/x approximation for k=1,...
% MMQ_ANTIGAUSSQUADRULE_M computes nodes and weights of the anti-Gauss rule
% MMQ_CLASSICORTHOPOLY supplies the coefficients a,b of the normalized
% MMQ_CLASSICORTHOPOLYVP supplies the coefficients a,b of the normalized
% MMQ_CORTHOPOLAG computes the Jacobi matrix for classical orthogonal
% MMQ_CORTHOPOLGL computes the Jacobi matrix for classical orthogonal
% MMQ_CORTHOPOLGR computes the Jacobi matrix for classical orthogonal
% MMQ_GAUSSKRONQUADRULE_M computes nodes and weights of the Gauss-Kronrod rule using the Matlab QR algorithm
% MMQ_GAUSSLOBQUADRULE_M computes nodes and weights of the Gauss-Lobatto rule using the Matlab QR algorithm
% MMQ_GAUSSQUAD Gauss quadrature for the integral of 1/(2+x) and the Jacobi matrix tt
% MMQ_GAUSSQUADK computes the Gauss approximation of the integral of 1/x for k=1,...
% MMQ_GAUSSQUADRULE Golub and Welsch algorithm
% MMQ_GAUSSQUADRULEVP Golub and Welsch algorithm, variable precision
% MMQ_GAUSSQUADRULE_M computes nodes and weights of the Gauss rule using the Matlab QR algorithm
% MMQ_GAUSSQUADRULE_MVP computes nodes and weights using the Matlab QR algorithm
% MMQ_GAUSSRADQUADRULE_M computes nodes and weights of the Gauss-Radau rule using the Matlab QR algorithm
% MMQ_GENORTHOPOLY given the 2n+1 moments mu of the weight function 
% MMQ_JACOBI Jacobi matrix [b a b]
% MMQ_LAGUERRE_MVP computes nodes and weights using the Matlab QR algorithm for Laguerre
% MMQ_MOD_DIV_LIN computation of the Jacobi matrix for the division of w by a linear factor r = x - beta
% MMQ_MOD_LIN computation of the Jacobi matrix for a multiplication of w by a linear factor r = x - beta
% MMQ_MOD_POL computation of the Jacobi matrix for a multiplication of w by a polynomial r 
% MMQ_QUADANTIGAUSSEX examples of computations of integrals with Anti-Gauss quadrature
% MMQ_QUADGAUSSEX examples of computations of integrals with Gauss quadrature
% MMQ_QUADGAUSSLOBEX examples of computations of integrals with Gauss-Lobatto quadrature
% MMQ_QUADGAUSSRADEX examples of computations of integrals with Gauss-Radau quadrature
% MMQ_TEST_GAUSSQUADRULE test program for mmq_gaussquadrule
% MMQ_TEST_GAUSSQUADRULE_M test program for mmq_gaussquadrule_m
% MMQ_TEST_QUADRULE test program for Gauss quadrature rules
% MMQ_TEST_QUADRULE_GW test program for Gauss quadrature rules