function [xf,fxf,it]=mmq_solve_secul_tls_gr1(d,c,rho,beta,xs,epss);
%MMQ_SOLVE_SECUL_TLS_GR1 solves the Total Least Squares secular equation for Gauss-Radau
% rational approximation 
% xs: Melman starting point  (comes from the Gauss rule)
% rho > 0
%
% Author G. Meurant
% august 2007
%

%warning off

k=length(d);
if length(c) ~= k
  error('MMQ_SOLVE_SECUL_TLS_GR1: c does not have the right length')
end
if length(find(d<0)) ~= 0
  error('MMQ_SOLVE_SECUL_TLS_GR1: d has negative components')
end

% put the first pole to zero
dmin=min(d);
del=(d(:)-dmin)/rho;
d_old=d;
d=del;
alpha=dmin-beta;

% we  need the components squared
xi=(c(:).^2);

itmax=50;
it=0;
sc=1;
x_old=(xs-dmin)/rho;

while it <=itmax & sc > epss
  it=it+1;
  % compute the interpolants
  % function and derivative at the interpolation point x_old
  
  [yx,yxp]=seculgr(xi,d,alpha,rho,x_old);
  
  % rational approximation to first order
  b=-yxp*x_old^2;
  a=yx+yxp*x_old;
  % interpolant is alpha+ rho x + a + b/x
  % quadratic equation 
  aa=rho;
  bb=-alpha-a;
  cc=b;
  
  % solution of the quadratic equation
  delta=bb^2-4*aa*cc;
  if delta < 0
    disp('MMQ_SOLVE_SECUL_TLS_GR1: quadratic equation has no real solution')
    return
  end
  delta=sqrt(delta);
  xm=(bb-delta)/(2*aa);
  xp=(bb+delta)/(2*aa);

  % select the negative root 
  x_new=xm;
  if xp < 0 
    x_new=xp;
  end
  
  sc=abs(x_new-x_old)/abs(x_old);
  x_old=x_new;
end
% translate back
xf=dmin+rho*x_new;
[yx,yxp]=seculgr(xi,d,alpha,rho,x_new);
fxf=yx;

warning on

function [y,yp]=seculgr(xi,dts,alpha,rho,x);
%SECULGR function f and f'
%
k=length(x);
for i=1:k
  z=xi(:)./(dts(:)-x(i));
  y(i)=sum(z(1:end));
  zp=xi(:)./(dts(:)-x(i)).^2;
  yp(i)=sum(zp(1:end));
end

