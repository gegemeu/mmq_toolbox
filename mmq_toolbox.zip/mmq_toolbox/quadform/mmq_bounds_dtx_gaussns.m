function [bg,bgrl,bgru,bgl]=mmq_bounds_dtx_gaussns(a,d,c,kmax,lmin,lmax);
%MMQ_BOUNDS_DTX_GAUSSNS computation of bounds for d^T x with a x=c i.e. d^T inv(a)c
% a symmetric
% nonsymmetric Lanczos algorithm
% kmax iterations
%
% lmin and lmax are the lower and upper bounds for the smallest and largest eigenvalues
%
%  bg :         Gauss
%  bgrl, bgru : Gauss-Radau
%  bgl :        Gauss-Lobatto
%
% Author G. Meurant
% March 2008
%

bg=zeros(kmax,1);
bgrl=zeros(kmax,1);
bgru=zeros(kmax,1);
bgl=zeros(kmax,1);

n=size(a,1);
x1=zeros(n,1);
xt1=zeros(n,1);
utv=d'*c;
sutv=sqrt(abs(utv));
if utv == 0
 error('MMQ_BOUNDS_DTX_GAUSSNS: utv = 0')
end
x=d/sutv;
xt=c/sutv;
if utv < 0
 xt=-xt;
end
gam=0;
bet=0;
ax=a*x;
axt=a*xt;
om=xt'*ax;
b1=1/om;
bg(1)=utv*b1;
d=om;
dbar=om-lmax;
dhat=om-lmin;
c=1;
e=1;
r=ax-om*x;
rt=axt-om*xt;
gamb=rt'*r;
gabet=sqrt(abs(gamb));
gam=gabet;
bet=gabet;
if gamb < 0
 bet=-gabet;
end
x1=x;
xt1=xt;
x=r/gam;
xt=rt/bet;

% Non symmetric Lanczos iterations
if kmax > 1
 for k=2:kmax
  gam1=gam;
  bet1=bet;
  gamb1=gamb;
  ax=a*x;
  axt=a*xt;
  om=xt'*ax;
  r=ax-om*x-bet*x1;
  rt=axt-om*xt-gam*xt1;
  gamb=rt'*r;
  gabet=sqrt(abs(gamb));
  gam=gabet;
  bet=gabet;
  if gamb < 0
   bet=-gabet;
  end
  x1=x;
  xt1=xt;
  if gabet == 0
   error('MMQ_BOUNDS_DTX_GAUSSNS: breakdown')
  end
  x=r/gam;
  xt=rt/bet;
  b1=b1+(gamb1*c*e)/(d*(om*d-gamb1));
  if d == 0
   error('MMQ_BOUNDS_DTX_GAUSSNS: breakdown')
  end
  c=c*gam1/d;
  e=e*bet1/d;
  d=om-gamb1/d;
  dbar=om-lmax-gamb1/dbar;
  dhat=om-lmin-gamb1/dhat;
  ombar=lmax+gamb/dbar;
  omhat=lmin+gamb/dhat;
  bbar=b1+(gamb*c*e)/(d*(ombar*d-gamb));
  bhat=b1+(gamb*c*e)/(d*(omhat*d-gamb));
  dd=dhat*dbar/(dbar-dhat);
  omt=dd*(lmax/dhat-lmin/dbar);
  gamt2=dd*(lmax-lmin);
  btch=b1+(gamt2*c*e)/(d*(omt*d-gamt2));
  bg(k)=utv*b1;
  bgru(k)=utv*bhat;
  bgrl(k)=utv*bbar;
  bgl(k)=utv*btch;
  
 end
end





