function int=mmq_gaussquad(tt,mu0);
%MMQ_GAUSSQUAD Gauss quadrature for the integral of 1/(2+x) and the Jacobi matrix tt
%
% Author G. Meurant
% April 2008
%

a=diag(tt);
b=diag(tt,-1);

% nodes and weights by Golub and Welsch
[t,w]=mmq_gaussquadrule(a,b,0,mu0,0);

% computation of the integral
ft=1./(2+t);
int=sum(w.*ft);