%MMQ_RUN_TEST_GCV_SMALL_SMALL run GCV for the very small von Matt problem
%
% Author G. Meurant Dec 2006
%

warning off

% Small-small test problem with exponential singular value distribution

gcase = 1;
m = 200;
n = 100;
c = -0.03;
%c=-0.3;

noise = 1E0;
mmq_test_gcv;

pause

noise = 1E1;
mmq_test_gcv;

pause

noise = 1E2;
mmq_test_gcv;


warning on