function [c,s,c2,s2,cs]=mmq_givensu(a,b);
%MMQ_GIVENSU Givens rotation for chasing up
%
% Author G. Meurant
% June 2007

[c,s,c2,s2,cs]=mmq_givens(a,b);
s=-s;
cs=-cs;
