function tr=mmq_est_trdet(a,k);
%MMQ_EST_TRDET estimate of the determinant of a using moments
% computes 2k+1 moments and uses the Golub and Welsch algorithm
%
% Author G. Meurant
% March 2008
%

km=2*k+1;
mom=zeros(km,1);
% computes the 2k+1 moments of a
n=size(a,1);
am=speye(n,n);
for i=1:km
  mom(i)=trace(am);
  am=am*a;
end

% compute the Jacobi matrix using moments
[aa,b]=mmq_genorthopoly(k,mom);

% compute the nodes and weights
[t,w]=mmq_gaussquadrule_m(aa,b,mom(1));

% compute the integral of log(x) and thake the exponential
tr=exp(sum(w.*log(t)));

