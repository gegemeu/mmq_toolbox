function k=mmq_rt(t,u,s,v,y);
%MMQ_RT locates the l-corner by the Rodriguez and Theis algorithm
%
% Author G. Meurant
% Jan 2007
%
p=length(t);

% compute the points on the L-curve
[x,r] = mmq_flcurve (t,u,s,v,y);

iplot=0;
if iplot == 1
 plot(t,x)
 hold on
 plot(t,r,'r')
 hold off
 pause
 figure
 x=x(p:-1:1);
 r=r(p:-1:1);
 plot(r,x,'o-')
 hold on
 pause
end

tau3=sqrt((x(p)-x(1))^2+(r(p)-r(1))^2)/(2*p);
tau3=0;
tau4=-1/2;
q=0;

for i=1:p-1
 v=[r(i+1)-r(i);x(i+1)-x(i)];
 nv=norm(v);
 if nv > tau3
  q=q+1;
  vq(:,q)=v/nv;
  inum(q)=p-i+1;
  in(q)=i;
 else
  ii=i
 end
end
 
for i=1:q-1
 w(i)=det([vq(:,i) vq(:,i+1)]);
end
[mw,kk]=min(w);
tau4=1;
if mw < tau4
 kk
 k=inum(kk)
else
 if abs(log10(x(p))-log10(x(1))) < 10
  k=1;
 else
  disp('MMQ_RT: corner not found')
  k=0;
 end
end

if iplot == 1
 plot(r(in(kk)),x(in(kk)),'ro')
 hold off
end