function [a,b]=mmq_genorthopol(n,mu);
%MMQ_GENORTHOPOL coefficients of the recurrence of orthogonal polynomials
% given the 2n+1 moments mu of the weight function 
% generate the recursion coefficients a and b of the normalized orthogonal
% polynomials
%
% From Golub and Welsch but use the Matlab Cholesky factorization of the moment matrix
%
% Author G. Meurant
% March 2008
%

nmu=length(mu);
if nmu ~= 2*n+1
 error('MMQ_GENORTHOPOL: the number of moments is wrong')
end

% moment matrix
mom=zeros(n+1,n+1);
for i=1:n+1
 for j=1:n+1
  mom(i,j)=mu(i+j-1);
 end
end

eig_mom = eig(mom);

if any(eig_mom<0)
 disp('negative eigenvalues')
 eig_mom'
 a = 0;
 b = 0;
 return
end

% Cholesky factorization of the moment matrix
r=chol(mom);

% compute the recursion coefficients from r
a=zeros(1,n);
if n == 1
 a(n)=r(n,n+1)/r(n,n);
 b=0;
 return
end
b=zeros(1,n-1);
a(n)=r(n,n+1)/r(n,n)-r(n-1,n)/r(n-1,n-1);
for j=n-1:-1:2
 b(j)=r(j+1,j+1)/r(j,j);
 a(j)=r(j,j+1)/r(j,j)-r(j-1,j)/r(j-1,j-1);
end
b(1)=r(2,2)/r(1,1);
a(1)=r(1,2)/r(1,1);
