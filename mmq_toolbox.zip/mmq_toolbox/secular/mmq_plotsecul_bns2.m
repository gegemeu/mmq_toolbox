function xf=mmq_plotsecul_bns2(d,c);
%MMQ_PLOTSECUL_BNS2 find the zero xf of f
% algorithm BNS2
%
% Author G. Meurant
% july 2007
%

warning off

km=length(d);
% ii is the interval in which we are looking
ii=1;
%ii=2;
del=d(:)-d(1);
d_old=d;
d=del;
lmin=min(d(:));
lmax=max(d(:));
dta=sort(d);
lmin=-0.1;
lmax=1.1*d(1);
lmm=lmax-lmin;
ymax=10;
ymin=-10;

k=km;
 
% we  need the components squared
xi=(c(:).^2);
% plot f in ]0, del[
figure
hold on

% plot the poles
for i=1:2
  plot([d(i) d(i)],[-ymax ymax],'--')
end

% plot the functions between the k poles 
lamb=[lmin-2 d(1) d(2) lmax+2];
k=2;
for i=1:k+1
  epsi1=(lamb(i+1)-lamb(i))*1e-5;
  epsi2=epsi1;
  if i == 1
    epsi1=-lmin/2;
    epsii=epsi1;
  end
  if i == k+1
    epsi2=-lmin/2;
  end
  x=linspace(lamb(i)+epsi1,lamb(i+1)-epsi2,100);
  [y,yp]=secul1(xi,d,x,ii);
  [yy,yyp]=secul2(xi,d,x,ii);
  plot(x,1+y+yy)
end

% plot( the x axis
plot([min(lamb) max(lamb)],[0 0],'-.')
axis([min(lamb) max(lamb) -ymax ymax])
title(['Translated f'])

% find the starting point (Melman)

% find an approximation of tf(t)
h0=ht(xi,d,0,ii);
del=d(2);
hd=ht(xi,d,del,ii);
q=del*hd/(hd-h0);
p=h0*q;

% find the zero of the interpolant i.e. the starting point
[xs,fs]=fzero(@tft,[0 del-1e-10],[],xi(1),xi(2),del,p,q);
plot(xs,fs,'bo')

% value of f at start
fxs=1+secul1(xi,d,xs,ii)+secul2(xi,d,xs,ii);

itmax=10;
it=0;
epss=1e-10;
sc=1;
x_old=xs;

while it <=itmax & sc > epss
  it=it+1;
  % compute the interpolants
  % function and derivative of phi at the interpolation point x_old
  [yx,yxp]=secul2(xi,d,x_old,ii);
  % parameters of BNS2
  q=x_old+yx/yxp;
  p=yx^2/yxp;
  % interpolant is p/(q-x)
  
  % function and derivative of psi at the interpolation point x_old
  [yx,yxp]=secul1(xi,d,x_old,ii);
  % parameters of BNS2
  r=yx-(-x_old)*yxp;
  s=(-x_old)^2*yxp;
  % interpolant is r+s/(d-x)
  
  % solve the quadratic equation 1+p/(q-x)+r+s/(-x)
  aa=r+1;
  del=0;
  bb=aa*(q+del)+p+s;
  cc=aa*q*del+p*del+s*q;
  delta=bb^2-4*aa*cc;
  if delta < 0
    error('MMQ_PLOTSECUL_BNS2: quadratic equation has no real solution')
  end
  delta=sqrt(delta);
  xm=(bb-delta)/(2*aa);
  xp=(bb+delta)/(2*aa);
  % select the root between 0 and del
  x_new=xm;
  if xp >= 0 & xp <= del
    x_new=xp;
  end
  %x_new
  sc=abs(x_new-x_old)/abs(x_old);
  x_old=x_new;
end
 
xf=x_new;
fxf=1+secul1(xi,d,xf,ii)+secul2(xi,d,xf,ii);
plot(xf,fxf,'ro')
hold off

xf=xf+d_old(1);

function y=tft(x,xi1,xi2,del,p,q);
%TFT function x f(x)
%
y=x-(xi1+xi2)+(del*xi2)./(del-x)+(p*x)./(q-x);

function y=ht(xi,dts,x,ii);
%HT function for starting point
%
k=length(x);
for i=1:k
  z=xi(:)./(dts(:)-x(i));
  y=sum(z(ii+2:end));
end

function [y,yp]=secul1(xi,dts,x,ii);
%SECUL1 function f and f'
%
k=length(x);
for i=1:k
  z=xi(:)./(dts(:)-x(i));
  y(i)=sum(z(1:ii));
  zp=xi(:)./(dts(:)-x(i)).^2;
  yp(i)=sum(zp(1:ii));
end

function [y,yp]=secul2(xi,dts,x,ii);
%SECUL2 function f and f'
%
k=length(x);
for i=1:k
  z=xi(:)./(dts(:)-x(i));
  y(i)=sum(z(ii+1:end));
  zp=xi(:)./(dts(:)-x(i)).^2;
  yp(i)=sum(zp(ii+1:end));
end