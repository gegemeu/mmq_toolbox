function x = mmq_solshaw(n); 
%MMQ_SOLSHAW Test problem: one-dimensional image restoration model 
% solution of the Shaw problem 
% 
% Discretization of a first kind Fredholm integral equation with 
% [-pi/2,pi/2] as both integration intervals.  The kernel K and 
% the solution f, which are given by 
%    K(s,t) = (cos(s) + cos(t))*(sin(u)/u)^2 
%    u = pi*(sin(s) + sin(t)) 
%    f(t) = a1*exp(-c1*(t - t1)^2) + a2*exp(-c2*(t - t2)^2) , 
% are discretized by simple quadrature to produce A and x
% Then the discrete right-hand b side is produced as b = A*x
% 
% The order n must be even.

% Reference: C. B. Shaw, Jr., "Improvements of the resolution of 
% an instrument by numerical solution of an integral equation", 
% J. Math. Anal. Appl. 37 (1972), 83-112. 

% From Per Christian Hansen, IMM, 08/20/91

% Check input
if (rem(n,2)~=0), error('MMQ_SOLSHAW: The order n must be even'), end 

% Initialization
h = pi/n;  

% Compute the vectors x  
a1 = 2; c1 = 6; t1 =  .8; 
a2 = 1; c2 = 2; t2 = -.5; 
x =   a1*exp(-c1*(-pi/2 + [.5:n-.5]'*h - t1).^2) ... 
 + a2*exp(-c2*(-pi/2 + [.5:n-.5]'*h - t2).^2); 
