function [spb,checka,checkb,checkt]=mmq_inv_problem2(nmax);
%MMQ_INV_PROBLEM2 check exactness of methods for the inverse problem
% reconstruction of the Jacobi matrix from the nodes and weights
% Strakos problem
%

% Author G. Meurant
% July 2008
%

warning off

u=eps/2;
aex=zeros(nmax,1);
bex=aex;
spb=aex;

m=0;
for n=0:5:nmax
  if n == 0
    n=1;
  end
  m=m+1;
  spb(m)=n;
  
  % Strakos matrix of size n
  A=mmq_strakos(n,0.1,100,0.9);
  A0=A;
  ts=full(mmq_tridiag(n));
  [V,D]=eig(ts);
  A=V*A*V';
  [VA,DA]=eig(full(A));
  t=diag(DA);
  w=VA(1,:)';
  w0=w;
  w=w.^2;
  tex=sort(t);
  
  
  % compute the exact solution using Lanczos with reorth
  rhs=sqrt(w);
  x0=zeros(n,1);
  %[q,tt]=lanczdor(A,rhs,x0,n);
  [q,tt,vts,dts,rvec,nv,ww]=mmq_lanczdor(DA,rhs,x0,n);
  % round to double
  %aex=diag(double(tt));
  aex=diag(tt);
  aex=full(aex);
  %bex=diag(double(tt),-1);
  bex=diag(tt,-1);
  bex=full(bex);

  % Lanczos with reorth
  [a,b]=mmq_ab_lanczos(t,w,'or');
  % relative error
  checka(m,1)=max(abs(1-a./aex(1:n)))/u;
  if n ~= 1
    checkb(m,1)=max(abs(1-b./bex(1:n-1)))/u;
  else
    checkb(m,1)=0;
  end
  J=diag(a)+diag(b,-1)+diag(b,1);
  vpJ=sort(eig(full(J)));
  checkt(m,1)=max(abs(1-vpJ./tex))/u;
  
  
   % Lanczos Paige
  [a,b]=mmq_ab_lanczos(t,w,'no');
  % relative error
  checka(m,2)=max(abs(1-a./aex(1:n)))/u;
  if n ~= 1
    checkb(m,2)=max(abs(1-b./bex(1:n-1)))/u;
  else
    checkb(m,2)=0;
  end
  J=diag(a)+diag(b,-1)+diag(b,1);
  vpJ=sort(eig(full(J)));
  checkt(m,2)=max(abs(1-vpJ./tex))/u;
  
   % Lanczos standard
  [a,b]=mmq_ab_lanczos(t,w,'st');
  % relative error
  checka(m,3)=max(abs(1-a./aex(1:n)))/u;
  if n ~= 1
    checkb(m,3)=max(abs(1-b./bex(1:n-1)))/u;
  else
    checkb(m,3)=0;
  end
  J=diag(a)+diag(b,-1)+diag(b,1);
  vpJ=sort(eig(full(J)));
  checkt(m,3)=max(abs(1-vpJ./tex))/u;
  
  % CONVQR
  [a,b]=mmq_convqr(t,w);
  % relative error
  checka(m,4)=max(abs(1-a./aex(1:n)))/u;
  if n ~= 1
    checkb(m,4)=max(abs(1-b./bex(1:n-1)))/u;
  else
    checkb(m,4)=0;
  end
  J=diag(a(:))+diag(b(:),-1)+diag(b(:),1);
  vpJ=sort(eig(full(J)));
  checkt(m,4)=max(abs(1-vpJ./tex))/u;
  
  % Lanczos OPQ = RKPW
  xw(1:n,1)=t;
  xw(1:n,2)=w;
  ab=mmq_lanczosopq(n,xw);
  a=ab(:,1);
  b=sqrt(ab(2:n,2));
  % relative error
  checka(m,5)=max(abs(1-a./aex(1:n)))/u;
  if n ~= 1
    checkb(m,5)=max(abs(1-b./bex(1:n-1)))/u;
  else
    checkb(m,5)=0;
  end
  J=diag(a)+diag(b,-1)+diag(b,1);
  vpJ=sort(eig(full(J)));
  checkt(m,5)=max(abs(1-vpJ./tex))/u;
  
  % PFTOQD
  [q,e,e0,a,b]=mmq_pftoqd(t,w);
  a=a';
  b=b';
  % relative error
  checka(m,6)=max(abs(1-a./aex(1:n)))/u;
  if n ~= 1
    checkb(m,6)=max(abs(1-b./bex(1:n-1)))/u;
  else
    checkb(m,6)=0;
  end
  J=diag(a(:))+diag(b(:),-1)+diag(b(:),1);
  vpJ=sort(eig(full(J)));
  checkt(m,6)=max(abs(1-vpJ./tex))/u;
  
  % Stieltjes
  [a,b]=mmq_stieltj(t,w);
  % relative error
  checka(m,7)=max(abs(1-a./aex(1:n)))/u;
  if n ~= 1
    checkb(m,7)=max(abs(1-b./bex(1:n-1)))/u;
  else
    checkb(m,7)=0;
  end
  J=diag(a(:))+diag(b(:),-1)+diag(b(:),1);
  vpJ=sort(eig(full(J)));
  checkt(m,7)=max(abs(1-vpJ./tex))/u;
  
  % Rational Lanczos 
  [a,b]=mmq_lanczos_rat(t,sqrt(w));
  % relative error
  checka(m,8)=max(abs(1-a./aex(1:n)))/u;
  if n ~= 1
    checkb(m,8)=max(abs(1-b./bex(1:n-1)))/u;
  else
    checkb(m,8)=0;
  end
  J=diag(a(:))+diag(b(:),-1)+diag(b(:),1);
  vpJ=sort(eig(full(J)));
  checkt(m,8)=max(abs(1-vpJ./tex))/u;
  
end
checka=checka(1:m,:);
checkb=checkb(1:m,:);
spb=spb(1:m);

warning on
  