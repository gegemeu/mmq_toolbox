%MMQ_RUN_TEST_GCV_PARALLAX run GCV for the parallax problem
%
% Author G. Meurant Dec 2006
%

warning off

% Stellar parallax problem with 28 fixed, real observations
% (regutools/parallax)

gcase = 7;
m = 26;  % the number of rows is fixed
n = 20;
noise = 1E-1;
mmq_test_gcv;

pause

warning on