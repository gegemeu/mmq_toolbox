function [reg_corner,rho,eta,reg_param] = mmq_l_curve(U,sm,b);
%MMQ_L_CURVE Plot the L-curve and find its "corner"
%
% Plots the L-shaped curve of eta, the solution norm || x || or
% semi-norm || L x ||, as a function of rho, the residual norm
% || A x - b ||, for  Tikhonov regularization   (solid line )
%
% If any output arguments are specified, then the corner of the L-curve
% is identified and the corresponding reg. parameter reg_corner is
% returned.  Use routine l_corner if an upper bound on eta is required
%

% Reference: P. C. Hansen & D. P. O'Leary, "The use of the L-curve in
% the regularization of discrete ill-posed problems", Report UMIACS-
% TR-91-142, Dept. of Computer Science, Univ. of Maryland, 1991;
% to appear in SIAM J. Sci. Comp

% From Per Christian Hansen, UNI-C, 03/17/93

% modified by Urs von Matt, June 9, 1995

% modified by G. Meurant Dec 2006

plots=0;

% Set defaults
npoints = 100;  % Number of points on the L-curve
smin_ratio = 16*eps;  % Smallest regularization parameter

% Initialization
[m,n] = size(U); 
[p,ps] = size(sm);
if norm(U(:,1),2) > 1.2
 % U represents a Householder transformation
 n = p;
end
if (nargout > 0)
 locate = 1; 
else 
 locate = 0; 
end

if norm(U(:,1),2) > 1.2
 % U represents a Householder transformation
 beta = b - U*(U'*b);
 beta = beta (1:p);
else
 beta = U'*b;
end
beta2 = b'*b - beta'*beta;
if (ps==1)
 s = sm; beta = beta(1:p);
else
 s = sm(p:-1:1,1)./sm(p:-1:1,2); 
 beta = beta(p:-1:1);
end
xi = beta(1:p)./s;

eta = zeros(npoints,1); 
rho = eta; 
reg_param = eta; 
s2 = s.^2;
reg_param(npoints) = max([s(p),s(1)*smin_ratio]);
ratio = (s(1)/reg_param(npoints))^(1/(npoints-1));
ratio = (s(1)/reg_param(npoints))^(1/(npoints-1));
for i=npoints-1:-1:1
 reg_param(i) = ratio*reg_param(i+1); 
end
for i=1:npoints
 f = s2./(s2 + reg_param(i)^2);
 eta(i) = norm(f.*xi);
 rho(i) = norm((1-f).*beta(1:p));
end
if (m > n & beta2 > 0)
 rho = sqrt(rho.^2 + beta2); 
end
marker = '-'; 
pos = .8; 
txt = 'Tikh.';

% Locate the "corner" of the L-curve, if required.  If the Spline
% Toolbox is not available, return NaN for reg_corner.
if (locate)
 [reg_corner,rho_c,eta_c] = l_corner(rho,eta,reg_param,U,sm,b,'Tikh');
end

if plots == 1
 % Make plot
 figure
 plot_lc(rho,eta,marker,ps);
 if (locate)
  HoldState = ishold; 
  hold on;
  loglog([min(rho)/100,rho_c],[eta_c,eta_c],'--',...
   [rho_c,rho_c],[min(eta)/100,eta_c],'--')
  title(['L-curve, ',txt,' corner at ',num2str(reg_corner^2)]);
  if (~HoldState)
   hold off; 
  end
 end

 end
end


