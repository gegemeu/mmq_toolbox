function tr=mmq_est_trdetz_rand(a,p);
%MMQ_EST_TRDETZ_RAND estimate of the determinant of a using logm
% computation of z' log(a) z, z is a random vector with components 1 or -1
% then we take the exponential
% average of the p results

%
% Author G. Meurant
% March 2008
%

% initialize the random number generator
% this can be removed to obtain different bounds at each call of the function
rand('state',0)
randn('state',0)

la=logm(full(a));

n=size(a,1);
% generate p random vectors
zz=zeros(p,1);
for i=1:p
  z=mmq_rand_pmone(n);
  %z=mmq_randn_pmone(n);
  zz(i)=z'*la*z;
end

% average of the results
tr=sum(zz)/p;

tr=exp(tr);

