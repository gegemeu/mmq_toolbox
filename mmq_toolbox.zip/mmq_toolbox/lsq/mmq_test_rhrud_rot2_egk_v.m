function [n,sig,alpha,beta,d]=mmq_test_rhrud_rot2_egk_v(N,M,ns,ix);
%MMQ_TEST_RHRUD_ROT2_EGK_V test for the function mmq_rhrud_rot2d as in Elhay, Golub and Kautsky
% sliding window through the data
% check at every step and plot
%
% Author G. Meurant
% June 2007
%

warning off
if ns > M
 disp('MMQ_TEST_RHRUD_ROT2_EGK_V: ns is larger than M')
 ns=M;
end
[x,w,y,ier]=mmq_pwv(N,ix);
if ier == 1
 disp('MMQ_TEST_RHRUD_ROT2_EGK_V: Unknown problem, abort')
 return
end

% recursively build the solution up to M
sig=abs(w(1));
alpha(1)=x(1);
beta(1)=0;
d(1)=y(1)*sig;
eigvec=zeros(N,N);
eigvec(1,1)=1;
eigval=zeros(N,1);
eigval(1)=x(1);
cc=zeros(N,N);
ss=zeros(N,N);
n=1;
for i=1:M-1
 % update
 [n,sig,alpha,beta,d,cc,ss,eigvec,eigval]=mmq_rhrud_rot1(n,alpha,beta,sig,d,x(i+1),w(i+1),y(i+1),cc,ss,eigvec,eigval);
 disp('update init rhrud_rot1-----------------------')
 n
end

for k=1:N-M
 disp('*********************************')
 k
 % add a point k+M by updating
 [n,sig,alpha,beta,d,cc,ss,eigvec,eigval]=mmq_rhrud_rot1(length(alpha),alpha,beta,sig,d,x(k+M),w(k+M),y(k+M),cc,ss,eigvec,eigval);
 disp('update k+M rhrud_rot1-----------------------')
 n
 % delete the point k by downdating
 [n,sig,alpha,beta,d,eigvec,eigval]=mmq_rhrud_rot2d(length(alpha),alpha,beta,sig,d,x(k),w(k),y(k),eigvec,eigval,1);
 disp('downdate k rhrud_rot2d-----------------------')
 n
 if n ~= M
  error('MMQ_TEST_RHRUD_ROT2_EGK_V: cannot downdate correctly, abort')
 end
 
 %generate directly the solution by updating
 sigr=abs(w(k+1));
 alphar(1)=x(k+1);
 betar(1)=0;
 dr(1)=y(k+1)*sigr;
 eigvecr=zeros(N,N);
 eigvecr(1,1)=1;
 eigvalr=zeros(N,1);
 eigvalr(1)=x(k+1);
 ccr=zeros(N,N);
 ssr=zeros(N,N);
 for i=1:M-1
  % update
  [nout,sigr,alphar,betar,dr,ccr,ssr,eigvecr,eigvalr]=mmq_rhrud_rot1(i,alphar,betar,sigr,dr,x(k+i+1),w(k+i+1),y(k+i+1),ccr,ssr,eigvecr,eigvalr);
 end
 alphar=alphar(1:ns);
 betar=betar(1:ns-1);
 dr=dr(1:ns);
 % differences
 err_sig(k)=abs(sig-sigr)/abs(sigr);
 if norm(alphar) > 100*eps
  err_alpha(k)=norm(alpha(1:ns)-alphar)/norm(alphar);
 else
  err_alpha(k)=0;
 end
 if norm(betar) > 100*eps
  err_beta(k)=norm(beta(1:ns-1)-betar)/norm(betar);
 else
  err_beta(k)=0;
 end
 err_d(k)=norm(d(1:ns)-dr)/norm(dr);
 disp(' err_sig err_alpha err_beta err_d:')
 [err_sig(k) err_alpha(k) err_beta(k) err_d(k)]
end
alpha=alpha(1:ns);
beta=beta(1:ns-1);
d=d(1:ns);

% plot
figure
plot(log10(err_sig))
hold on
plot(log10(err_alpha),'--')
plot(log10(err_beta),'-.')
plot(log10(err_d),':')
legend('err sig','err alpha','err beta','err d')
title('Rhrud-Rot1-2d: relative errors in sliding')
hold off
warning on


disp('MMQ_TEST_RHRUD_ROT2_EGK_V: end test')



