function [ut0, dut0,nn,dd] = mmq_gcv_l_Ut0_meqn (lambda);
%MMQ_GCV_L_UT0_MEQN computes the upper bound of the GCV function when m=n
% computes the log of the function
%
% Author G. Meurant, Jan 2007
%
% The statement
%
%     [ut0, dut0] = gcv_l_Ut0_meqn (lambda)
%
% evaluates the function  Ut0 (lambda)  and its derivative:
%
%     ut0 = Ut0 (lambda)
%
%               d
%     dut0 = ------- Ut0 (lambda)
%            dlambda
%

%
% communication among
% mmq_gcv_lanczos, mmq_gcv_l_Bounds, mmq_gcv_l_Lt0, mmq_gcv_l_Lt1,
% mmq_gcv_l_Ut0, mmq_gcv_l_Ut1, mmq_test_gcv_Vt
%
global gcv_l_m gcv_l_n gcv_l_normy gcv_l_normK gcv_l_normKTy ...
 gcv_l_u gcv_l_normu gcv_l_y ...
gcv_l_gamma_y gcv_l_delta_y gcv_l_gamma_u gcv_l_delta_u;

global by bu;

n_y = length (gcv_l_gamma_y);
if (n_y > 1) & (length (gcv_l_delta_y) ~= n_y - 1)
 error ('MMQ_GCV_L_UT0_MEQN: length (gcv_l_delta_y) ~= n_y - 1');
end

n_u = length (gcv_l_gamma_u);
if (n_u > 1) & (length (gcv_l_delta_u) ~= n_u - 1)
 error ('MMQ_GCV_L_UT0_MEQN: length (gcv_l_delta_u) ~= n_u - 1');
end

[m_lambda, n_lambda] = size (lambda);
ut0 = zeros (m_lambda, n_lambda);
dut0 = zeros (m_lambda, n_lambda);
N = m_lambda * n_lambda;

m = gcv_l_m;
n = gcv_l_n;

lambda=10.^lambda;

for i = 1:N
 if lambda (i) < 0
  error ('MMQ_GCV_L_UT0_MEQN: lambda (i) < 0');
 end
 mu = m * lambda (i);
 
 % numerator
 %tmp = gcv_l_gamma_y (n_y);
 %gcv_l_gamma_y (n_y) = 0;
 %[Q, u, v] = lbidiagQR (gcv_l_gamma_y, [gcv_l_delta_y(:); 0], sqrt (mu));
 %b = [zeros(n_y+1,1); eye(n_y,1)];
 %b = lbidiagQTx (Q, b);
 %xi = ubidiagSolve (u, v, b (1:n_y));
 %num = gcv_l_normy^2   * xi' * xi;
 %[Q, u, v] = lbidiagQR (gcv_l_gamma_y, [gcv_l_delta_y(:); 0], sqrt (mu));
 %b = lbidiagQTx (Q, eye (2*n_y+1, 1));
 %eta = ubidiagSolve (u, v, b (1:n_y));
 %gcv_l_gamma_y (n_y) = tmp;
 
 % for an upper bound next line
 %[u,s,v]=svd(full(by(:,1:end-1)));
 % for an approximation next line
 [u,s,v]=svd(full(by));
 s=diag(s);
 gr=mmq_comp_l_ribbon(mu,u,s,v);
 num=gcv_l_normy^2*gr;
 %num=mu^2*num;
 gr=mmq_comp_l_ribbon1(mu,u,s,v);
 nump=-2*m*gcv_l_normy^2*gr;
 %nump=mu^2*nump;
 
 % denominator
 %[Q, u, v] = ubidiagQR (gcv_l_gamma_u, gcv_l_delta_u, sqrt (mu));
 %b = [zeros(n_u,1); eye(n_u,1)/sqrt(mu)];
 %b = ubidiagQTx (Q, b);
 %xi = ubidiagSolve (u, v, b (1:n_u));
 %den = gcv_l_normu^2 * mu * xi (1);
 %[Q, u, v] = lbidiagQR (gcv_l_gamma_u, [gcv_l_delta_u(:); 0], sqrt (mu));
 %b = lbidiagQTx (Q, eye (2*n_u+1, 1));
 %eta = ubidiagSolve (u, v, b (1:n_u));
 %denp = m * (gcv_l_normu * norm (eta, 2))^2;
 
 [u,s,v]=svd(full(bu));
 nu=size(v,1);
 s=diag(s);
 d=v'*eye(nu,1);
 t = s.^2 + mu;
 den= gcv_l_normu^2 * sum (d(1:nu).^2 ./ t);
 denp= -m*gcv_l_normu^2 * sum (d(1:nu).^2 ./ t.^2);
 
 nn(i)=num;
 dd(i)=den;
 ut0i = m * num / den^2;
 ut0(i)=log10(ut0i);
 dut0i = m * (nump / den^2 - 2 * num * denp / den^3);
 dtu0(i)=dut0i/ut0i;
end
