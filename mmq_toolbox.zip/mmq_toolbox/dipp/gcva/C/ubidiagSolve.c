/* ubidiagSolve.c, MATLAB Version 4

   The calling syntax is:

       x = ubidiagSolve (gamma, delta, b)

   This procedure solves the linear system  U * x = b,
   where U is an n-by-n upper bidiagonal matrix:

           [ gamma(1)  delta(1)                       ]
           [             ...     ...                  ]
       U = [                     ...  ...             ]
           [                          ...  delta(n-1) ]
           [                                gamma(n)  ]

   Urs von Matt, October 26, 1994 */



#include <math.h>
#include "mex.h"



static void ubidiagSolve (n, gamma, delta, b, x)
  int    n;
  double *gamma, *delta, *b, *x;

{ int i;

  x [n-1] = b [n-1] / gamma [n-1];
  for (i = n-2; i >= 0; i--) {
    x [i] = (b [i] - delta [i] * x [i+1]) / gamma [i];
  }
}



#define max(A, B)  ((A) > (B) ? (A) : (B))
#define min(A, B)  ((A) < (B) ? (A) : (B))

/* Input Arguments */
#define	gamma prhs[0]
#define	delta prhs[1]
#define	b     prhs[2]

/* Output Arguments */
#define	x plhs[0]

void mexFunction(
    int nlhs, mxArray *plhs[],
    int nrhs, const mxArray *prhs[])

{ int n;

  /* Check for proper number of arguments */
  if (nrhs != 3) {
    mexErrMsgTxt ("ubidiagSolve requires three input arguments.");
  } else if (nlhs != 1) {
    mexErrMsgTxt ("ubidiagSolve requires one output argument.");
  }

  /* Check the dimensions of gamma. */
  n = max (mxGetM (gamma), mxGetN (gamma));
  if (min (mxGetM (gamma), mxGetN (gamma)) != 1) {
    mexErrMsgTxt ("gamma must be an n-by-1 or a 1-by-n matrix.");
  }

  /* Check the dimensions of delta. */
  if (n > 1) {
    if ((min (mxGetM (delta), mxGetN (delta)) != 1) ||
        (max (mxGetM (delta), mxGetN (delta)) != n-1)) {
      mexErrMsgTxt ("delta must be an (n-1)-by-1 or a 1-by-(n-1) matrix.");
    }
  }

  /* Check the dimensions of b. */
  if ((mxGetM (b) != n) || (mxGetN (b) != 1)) {
    mexErrMsgTxt ("b must be an n-by-1 matrix.");
  }

  /* Create vector for the return arguments. */
  /* x = mxCreateFull (n, 1, REAL); */
  x = mxCreateDoubleMatrix(n,1, mxREAL);

  /* Do the actual computations in a subroutine. */
  ubidiagSolve (n, mxGetPr (gamma), mxGetPr (delta), mxGetPr (b),
                mxGetPr (x));
}
