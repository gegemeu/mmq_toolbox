function int=mmq_quadgaussradex(iex,n);
%MMQ_QUADGAUSSRADEX examples of computations of integrals with Gauss-Radau quadrature
%
% the prescribed node is node
%
% Author G. Meurant
% March 2008
%

node=-1;

switch(iex)
 case 1
  % Legendre weight function, f(x)=x^20
  [a,b,mu0]=mmq_corthopolgr('le',n,0,0,node);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=t.^(20);
  %ft=t.^(5);
  
 case 2
  % Legendre weight function, f(x)=exp(x)
  [a,b,mu0]=mmq_corthopolgr('le',n,0,0,node);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=exp(t);
  
 case 3
  % Legendre weight function, f(x)=1/(1+10 x^2)
  [a,b,mu0]=mmq_corthopolgr('le',n,0,0,node);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=1./(1+10*t.^2);
  
 case 4
  % Legendre weight function, f(x)=exp(-1/x^2)
  [a,b,mu0]=mmq_corthopolgr('le',n,0,0,node);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=exp(-1./t.^2);
  
 case 5
  % Legendre weight function, f(x)=(1-x^2)^(-1/2)
  [a,b,mu0]=mmq_corthopolgr('le',n,0,0,node);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=1./sqrt(1-t.^2);
  
 case 6
  % Chebyshev weight function, f(x)=(1-x^2)^(-1/2)
  [a,b,mu0]=mmq_corthopolgr('c1',n,0,0,node);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=ones(1,n);
  
 case 7
  % Legendre weight function, f(x)=(1-x^2)^(1/2)/(2+x)^(1/2)
  [a,b,mu0]=mmq_corthopolgr('le',n,0,0,node);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=sqrt(1-t.^2)./sqrt(2+t);
  
   case 8
  % Chebyshev second kind weight function, f(x)=1/(2+x)^(1/2)
  [a,b,mu0]=mmq_corthopolgr('c2',n,0,0,node);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=1./sqrt(2+t);
  
 otherwise
  error('MMQ_QUADGAUSSRADEX: Unknown example')
  int=0;
  return
  
end

int=sum(w.*ft);