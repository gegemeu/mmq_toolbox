function [t,w]=mmq_gaussql(a,b,muzero);
%MMQ_GAUSSQL  QL algorithm to compute the eigenvalues of a tridiagonal matrix
% given the coefficients (a,b) of the orthogonal polynomials
% p(k)=(a(k) x + b(k)) p(k-1) - c(k) p(k-2)
% computes the abscissas t and the weights w of the Gauss type quadrature
% associated with orthogonal polynomials by QR iteration with shift
%

% Author G. Meurant
% June 2007
%

n=length(a);

a_old=a;
b_old=b;
% find the maximum row sum norm
 ni=n;
 J=spdiags([[b(1:ni-1)'; 0] a(1:ni)' [0; b(1:ni-1)']], -1:1, ni,ni);
 J=abs(J);
 nJ=J*ones(n,1);
 normJ=max(nJ);
 
 w=zeros(1,n);
 w(1)=1;
 % relative zero tolerance
 epss=eps*normJ;
 lambda=normJ; lambda1=lambda; lambda2=lambda; rho=lambda;
 m=n;
 k=1;
 % we go from k to m
 
 inspect=1;
 
 while inspect == 1
  
  if k == n
   % sort the abscissas
   [t,ind]=sort(t);
   w=w(ind);
   inspect=0;
   continue
  end
  
  i=m; m1=k;
  if m1 <= n-1
   if abs(b(m1)) <= epss
    t(k)=a(k);
    w(k)=muzero*w(k)^2;
    rho=min(lambda1,lambda2);
    k=k+1;
    if m1 == n-1
     t(n)=a(n);
     w(n)=muzero*w(n)^2;
     % sort the abscissas
     [t,ind]=sort(t);
     w=w(ind);
     k=n;
     continue
    end
    continue
   end
  end
  
  % small off diagonal element means the matrix can be split
  for j=i+1:m-1
   if abs(b(j)) <= epss 
    i=j;
    break
   else
    i=n;
   end
  end
  
  % find the shift with the eigenvalues of upper 2x2 block
  if k < n
   kl=k;
   b2=b(kl)^2;
   det=sqrt((a(k+1)-a(k))^2+4*b2);
   aa=a(k+1)+a(k);
   if aa > 0
    lambda2=(aa+det)/2;
   else
    lambda2=(aa-det)/2;
   end
   lambda1=(a(k+1)*a(k)-b2)/lambda2;
   eigmax=max(lambda1,lambda2);
   if abs(eigmax-rho) <= abs(eigmax)/8
    lambda=eigmax;
    rho=eigmax;
   else
    rho=eigmax;
   end
  else 
   lambda=0;
  end
  
  [a(k:i),b(k:i-1),w(k:i)]=mmq_qlsweep(a(k:i),b(k:i-1),lambda,w(k:i));
  
 end
 
 % eventually recompute the weights by QL with perfect shifts
 % but this is not much better!
 
 %w=mmq_qlgauss(t,a_old,b_old,muzero);
 
 % streamline algorithm (cheaper)
 %w=mmq_sqlgauss(t,a_old,b_old,muzero);

 