function [mul,muu,iter]=mmq_l_ribbon_corner_reort_it_g(ur,s,vr,y,kmax);
%MMQ_L_RIBBON_CORNER_REORT_IT_G computes the corners of the L-ribbon approximations
% at each iteration with reorthogonalization
% works when the matrix is defined by ur, s, vr
%
% Lanczos bidiagonalization to compute lower and upper bounds of the L-curve
%
% Author G. Meurant
% Feb 2007
%

ny=norm(y);
naty=norm(mmq_pmatat(ur,s,vr,y));
m=size(ur,1);

% compute the exact L-curve and the limits

np=50;
normK=max(s);
lambdamax = normK^2;
lambdamin = (eps * normK);

mul_old=realmin;
muu_old=realmax;

% start the Lanczos iterations
% similar to l_bidiagaat

k=kmax;
c=sparse(k+1,k+1);
uu=zeros(length(ur),1);
vv=zeros(length(vr),1);

epsd=1e-2;

% init
u_old=y/norm(y);
%w=a'*u_old;
w=mmq_pmatat(ur,s,vr,u_old);
c(1,1)=norm(w);
v_old=w/c(1,1);
uu(:,1)=u_old;
vv(:,1)=v_old;

for i=2:k+1
 %w=a*v_old-c(i-1,i-1)*u_old;
 w=mmq_pmata(ur,s,vr,v_old)-c(i-1,i-1)*u_old;
 c(i,i-1)=norm(w);
 u=w/c(i,i-1);
 
 % reorthogonalization
 
 for j=1:i-1
  alpha=u'*uu(:,j);
  u=u-alpha*uu(:,j);
  u=u/norm(u);
 end
 
 %w=a'*u-c(i,i-1)*v_old;
 w=mmq_pmatat(ur,s,vr,u)-c(i,i-1)*v_old;
 c(i,i)=norm(w);
 v=w/c(i,i);
 
 % reorthogonalization
 
 for j=1:i-1
  alpha=v'*vv(:,j);
  v=v-alpha*vv(:,j);
  v=v/norm(v);
 end
 uu(:,i)=u;
 vv(:,i)=v;
 
 u_old=u;
 v_old=v;
 
 if i > 3
  
  cc=c(1:i-1,1:i-1);
  ccb=c(1:i,1:i-1);
  [q,cch]=qr(full(ccb),0);
  if any(diag(cch) < 0)
   cch=-cch;
  end
  cch=cch';
  % remove the last column
  cchb=cch(:,1:end-1);
  
  % compute the approximations using SVDs rather than
  % solving least squares problems
  [ucc,scc,vcc]=svd(full(cc));
  scc=diag(scc);
  [uccb,sccb,vccb]=svd(full(ccb));
  sccb=diag(sccb);
  [ucch,scch,vcch]=svd(full(cch));
  scch=diag(scch);
  [ucchb,scchb,vcchb]=svd(full(cchb));
  scchb=diag(scchb);
  
  al=log10(lambdamin);
  bl=log10(lambdamax);
  au=al;
  bu=bl;
  
  % locate the minimums by rotation in a few passes
  
  % t refers to values of log(lambda)
  n=25;
  ipass=3;
  iter=0;
  fail=0;
  
  while ipass > 0
   iter=iter+1;
   ipass=ipass-1;
   if n <= 0
    disp('MMQ_L_RIBBON_CORNER_REORT_IT_G: failure, n=0')
    fail=1;
    break
   end
   tl=linspace(al,bl,n);
   tu=linspace(au,bu,n);
   tll=10.^tl;
   tuu=10.^tu;
   
   gcc=mmq_comp_l_ribbon(tll,ucc,scc,vcc);
   lbr=ny^2*tll.^2.*gcc;
   
   gccb=mmq_comp_l_ribbon(tuu,uccb,sccb,vccb);
   ubr=ny^2*tuu.^2.*gccb;
   
   gcch=mmq_comp_l_ribbon(tll,ucch,scch,vcch);
   lbx=naty^2*gcch;
   
   gcchb=mmq_comp_l_ribbon(tuu,ucchb,scchb,vcchb);
   ubx=naty^2*gcchb;
   
   lbr=log10(sqrt(lbr));
   ubr=log10(sqrt(ubr));
   lbx=log10(sqrt(lbx));
   ubx=log10(sqrt(ubx));
   
   % locate the origins (in log scale)
   
   originl=mmq_l_origin(lbr,lbx);
   originu=mmq_l_origin(ubr,ubx);
   
   % change the origin
   
   lbr=lbr-originl(1);
   lbx=lbx-originl(2);
   ubr=ubr-originu(1);
   ubx=ubx-originu(2);
   
   % rotate by -pi/4
   
   [lnr,lnx]=mmq_rotat(lbr,lbx,-pi/4);
   [unr,unx]=mmq_rotat(ubr,ubx,-pi/4);
   
   [tmp, kl] = min (lnx);
   [tmp, ku] = min (unx);
   
   if kl == 1
    % the min is on the boundary
    kkl=mmq_angled(lbr,lbx);
    if kkl == 0
     error('MMQ_L_RIBBON_CORNER_REORT_IT_G: unable to find the corner')
    end
    if kkl == 1
     bl=tl(2);
    elseif kkl == n
     al=tl(n-1);
    else
     al=tl(kkl-1);
     bl=tl(kkl+1);
    end
    
   elseif kl == n
    % the min is on the boundary
    kkl=mmq_angled(lbr,lbx);
    if kkl == 0
     error('MMQ_L_RIBBON_CORNER_REORT_IT_G: unable to find the corner')
    end
    if kkl == 1
     bl=tl(2);
    elseif kkl == n
     al=tl(n-1);
    else
     al=tl(kkl-1);
     bl=tl(kkl+1);
    end
    
   else
    % for the next pass look in the interval enclosing the min
    al=tl(kl-1);
    bl=tl(kl+1);
   end
   
   if ku == 1
    % the min is on the boundary
    kku=mmq_angled(ubr,ubx);
    if kku == 0
     error('MMQ_L_RIBBON_CORNER_REORT_IT_G: unable to find the corner')
    end
    if kku == 1
     bu=tu(2);
    elseif kku == n
     au=tu(n-1);
    else
     au=tu(kkl-1);
     bu=tu(kkl+1);
    end
    
   elseif ku == n
    % the min is on the boundary
    kku=mmq_angled(ubr,ubx);
    if kku == 0
     error('MMQ_L_RIBBON_CORNER_REORT_IT_G: unable to find the corner')
    end
    if kku == 1
     bu=tu(2);
    elseif kku == n
     au=tu(n-1);
    else
     au=tu(kku-1);
     bu=tu(kku+1);
    end
    
   else
    % for the next pass look in the interval enclosing the min
    au=tu(ku-1);
    bu=tu(ku+1);
   end
  end
  
  if fail == 1
   mul=0;
   muu=0;
  else
   % the corner is given by the corresponding value of t
   mul=tl(kl);
   mul=10^mul;
   muu=tu(ku);
   muu=10^muu;
  end
  
  dmul=abs(mul-mul_old)/mul;
  dmuu=abs(muu-muu_old)/muu;
   
  if dmul+dmuu <= 2*epsd & abs(mul-muu)/muu <= epsd
   iter=i;
   return
  else
   mul_old=mul;
   muu_old=muu;
  end
  
 end
 
end % of Lanczos iterations





