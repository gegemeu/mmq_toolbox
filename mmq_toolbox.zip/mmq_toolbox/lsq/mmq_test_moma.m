function [alpha,beta]=mmq_test_moma(N,ix);
%MMQ_TEST_MOMA test using the moment matrix 
% to compute the orthogonal polynomials
%
% Author G. Meurant
% June 2007
%

[x,w,y,ier]=mmq_pwv(N,ix);
if ier == 1
 error('MMQ_MOMA: Unknown problem, abort')
end

[m,r]=mmq_moma(x,w);

%eigm=eig(m);
%condm=max(eigm)/min(eigm);
%disp(' Condition number of moment matrix')
%condm

% compute the tridiagonal matrix from r
alpha(1)=r(1,2);
old_rap=r(1,2)/r(1,1);
for i=2:N-1
 new_rap=r(i,i+1)/r(i,i);
 alpha(i)=new_rap-old_rap;
 old_rap=new_rap;
end
for i=1:N-1
 beta(i)=r(i+1,i+1)/r(i,i);
end


