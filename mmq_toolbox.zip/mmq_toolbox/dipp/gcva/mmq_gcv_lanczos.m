function [lambda, success] = mmq_gcv_lanczos (Kprod, m, n, normK, y);
%MMQ_GCV_LANCZOS find the GCV reg param by Lanczos bidiagonalization
% from the Golub and von Matt paper
% this routine is the closest one to the original implementation of Von Matt
%
% Author Urs von Matt
% modified by G. Meurant Dec 2006
%
% The call 
%
%     p = feval (Kprod, 'N', m, n, q)
%
% must evaluate the matrix-vector product
%
%     p = K * q.
%
% Similarly, the statement
%
%     p = feval (Kprod, 'T', m, n, q)
%
% must evaluate the matrix-vector product
%
%     p = K' * q.
%
% The parameter  normK  represents an estimate of the 2-norm
% or Frobenius norm of K.
%
% use the SVD for matrix product

%
% communication among
% mmq_gcv_lanczos, mmq_gcv_l_Bounds, mmq_gcv_l_Lt0, mmq_gcv_l_Lt1,
% mmq_gcv_l_Ut0, mmq_gcv_l_Ut1, mmq_test_gcv_Vt
%
global gcv_l_m gcv_l_n gcv_l_normy gcv_l_normK gcv_l_normKTy ...
 gcv_l_u gcv_l_normu ...
gcv_l_gamma_y gcv_l_delta_y gcv_l_gamma_u gcv_l_delta_u;

global gcv_func_min gcv_func_max;

if m < n
 error ('MMQ_GCV_LANCZOS: The case  m < n  is not covered.');
end

% produce plots?
plots = 0;

lambda = 0;
success = 0;

gcv_l_m = m;
gcv_l_n = n;
gcv_func_min=0;
gcv_func_max=0;
[m_y, n_y] = size (y);
if (m_y ~= m) | (n_y ~= 1)
 error ('MMQ_GCV_LANCZOS: y is not an mx1-vector.');
end
gcv_l_normy = norm (y, 2);
if gcv_l_normy == 0
 error ('MMQ_GCV_LANCZOS: y = 0');
end
gcv_l_normK = normK;
gcv_l_u = [];
gcv_l_gamma_y = [];
gcv_l_delta_y = [];
gcv_l_gamma_u = [];
gcv_l_delta_u = [];

% initialize Hutchinson's trace estimator
% nu = number of random vectors u
nu = 1;
% initialize Matlab 4 random numbers (to be consistent
% with the Golub and Von Matt paper
rand ('seed', 0);
% initialize Matlab 6,... random numbers
%rand('state',0);

gcv_l_u = rand (nu * n, 1);
gcv_l_u = 2 * (gcv_l_u > 0.5) - 1;
gcv_l_u = gcv_l_u / sqrt (nu);
gcv_l_normu = sqrt (n);

% initialize bidiagonalizations
bidiag_u = 1;
bidiag_y = 1;
k_u = 0;
k_y = 0;
% minimum number of Lanczos iterations
kmin = ceil (3 * log (min (m, n)));
 
% maximum number of iterations
%kmax = 2 * min (m, n); % this can be too large
kmax=1000;
bidiag_tol = 10 * max (m, n) * eps * normK;

% useful range for lambda
lambdamax = (normK / eps)^2 / m;
if isinf (lambdamax)
 error ('MMQ_GCV_LANCZOS: (normK / eps)^2 / m == Inf');
end
lambdamin = (eps * normK)^2 / m;
if lambdamin <= 0
 error ('MMQ_GCV_LANCZOS: (eps * normK)^2 / m == 0');
end

% initialize plots
if plots == 1
 %find min of the V (G) function
 lambdaopt = gcv_l_GlobalMin ('mmq_test_gcv_V', 0, lambdamax);
 % compute the value at min
 [vlambdaopt, dvlambdaopt] = mmq_test_gcv_V (lambdaopt);
 % find min of the tilde V (G) function
 lambdatopt = gcv_l_GlobalMin ('mmq_test_gcv_Vt', 0, lambdamax);
 % compute the value at min
 [vtlambdatopt, dvtlambdatopt] = mmq_test_gcv_Vt (lambdatopt);
 samples = 300;
 c = log (lambdamax / lambdamin) / (samples - 1);
 lambdas = zeros (samples, 1);
 lambdas (1) = lambdamin;
 lambdas (2:samples-1) = lambdamin * exp (c * [1:samples-2]');
 lambdas (samples) = lambdamax;
 % compute both functions at samples points
 [vlambdas, dvlambdas] = mmq_test_gcv_V (lambdas);
 [vtlambdas, dvtlambdas] = mmq_test_gcv_Vt (lambdas);
 
 % compare  V (lambda)  and  Vt (lambda)
 loglog (lambdas, vlambdas, '-', ...
  lambdaopt, vlambdaopt, 'x', ...
  lambdas, vtlambdas, ':', ...
  lambdatopt, vtlambdatopt, 'o');
 title (['G (nu),  Gt (nu)']);
 hold on
 drawnow
 pause
end

end_of_Lanczos = 0;

% start Lanczos iterations

while ~(end_of_Lanczos | success)
 %fprintf (1, 'k_u = %4i,   k_y = %4i\r', k_u, k_y);
 
 % update bidiagonalizations
 if bidiag_u
  % bidiagonalization with u as starting vector
  if k_u == 0
   q_u = gcv_l_u / gcv_l_normu;
   % p_u = K * q_u;
   p_u = zeros (nu*m, 1);
   for j = 1:nu
    p_u (1+(j-1)*m:j*m) = feval (Kprod, 'N', m, n, q_u (1+(j-1)*n:j*n));
   end
   gcv_l_gamma_u (1) = norm (p_u, 2);
   if abs (gcv_l_gamma_u (1)) <= bidiag_tol
    bidiag_u = 0;
    fprintf (1, 'MMQ_GCV_LANCZOS: bidiag_u = 0\n');
   else
    p_u = p_u / gcv_l_gamma_u (1);
   end
   k_u = 1;
  else
   % q_u = K' * p_u - gcv_l_gamma_u (k_u) * q_u;
   tmp = zeros (nu*n, 1);
   for j = 1:nu
    tmp (1+(j-1)*n:j*n) = feval (Kprod, 'T', m, n, p_u (1+(j-1)*m:j*m));
   end
   q_u = tmp - gcv_l_gamma_u (k_u) * q_u;
   gcv_l_delta_u (k_u) = norm (q_u, 2);
   if abs (gcv_l_delta_u (k_u)) <= bidiag_tol
    gcv_l_delta_u = gcv_l_delta_u (1:k_u-1);
    bidiag_u = 0;
    fprintf (1, 'MMQ_GCV_LANCZOS: bidiag_u = 0\n');
   else
    k_u = k_u + 1;
    q_u = q_u / gcv_l_delta_u (k_u-1);
    % p_u = K * q_u - gcv_l_delta_u (k_u-1) * p_u;
    tmp = zeros (nu*m, 1);
    for j = 1:nu
     tmp (1+(j-1)*m:j*m) = feval (Kprod, 'N', m, n, q_u (1+(j-1)*n:j*n));
    end
    p_u = tmp - gcv_l_delta_u (k_u-1) * p_u;
    gcv_l_gamma_u (k_u) = norm (p_u, 2);
    if abs (gcv_l_gamma_u (k_u)) <= bidiag_tol
     bidiag_u = 0;
     fprintf (1, 'MMQ_GCV_LANCZOS: bidiag_u = 0\n');
    else
     p_u = p_u / gcv_l_gamma_u (k_u);
    end
   end
  end
 end
 
 if bidiag_y
  % bidiagonalization with y as starting vector
  if k_y == 0
   p_y = y / gcv_l_normy;
   % q_y = K' * p_y;
   q_y = feval (Kprod, 'T', m, n, p_y);
   gcv_l_gamma_y (1) = norm (q_y, 2);
   gcv_l_normKTy = gcv_l_gamma_y (1) * gcv_l_normy;
   if abs (gcv_l_gamma_y (1)) <= bidiag_tol
    % set x = 0
    fprintf (1, 'MMQ_GCV_LANCZOS: || K'' y || <= c * eps * || y ||\n');
    lambda = lambdamax;
    success = 1;
    return;
   else
    q_y = q_y / gcv_l_gamma_y (1);
    % p_y = K * q_y - gcv_l_gamma_y (1) * p_y;
    p_y = feval (Kprod, 'N', m, n, q_y) - gcv_l_gamma_y (1) * p_y;
    gcv_l_delta_y (1) = norm (p_y, 2);
    if abs (gcv_l_delta_y (1)) <= bidiag_tol
     bidiag_y = 0;
     fprintf (1, 'MMQ_GCV_LANCZOS: bidiag_y = 0\n');
    else
     p_y = p_y / gcv_l_delta_y (1);
    end
    k_y = 1;
   end
  else
   % q_y = K' * p_y - gcv_l_delta_y (k_y) * q_y;
   q_y = feval (Kprod, 'T', m, n, p_y) - gcv_l_delta_y (k_y) * q_y;
   gcv_l_gamma_y (k_y+1) = norm (q_y, 2);
   if abs (gcv_l_gamma_y (k_y+1)) <= bidiag_tol
    gcv_l_gamma_y = gcv_l_gamma_y (1:k_y);
    bidiag_y = 0;
    fprintf (1, 'MMQ_GCV_LANCZOS: bidiag_y = 0\n');
   else
    k_y = k_y + 1;
    q_y = q_y / gcv_l_gamma_y (k_y);
    % p_y = K * q_y - gcv_l_gamma_y (k_y) * p_y;
    p_y = feval (Kprod, 'N', m, n, q_y) - gcv_l_gamma_y (k_y) * p_y;
    gcv_l_delta_y (k_y) = norm (p_y, 2);
    if abs (gcv_l_delta_y (k_y)) <= bidiag_tol
     bidiag_y = 0;
     fprintf (1, 'MMQ_GCV_LANCZOS: bidiag_y = 0\n');
    else
     p_y = p_y / gcv_l_delta_y (k_y);
    end
   end
  end
 end
 
 end_of_Lanczos = (~bidiag_u & ~bidiag_y) | (max (k_u, k_y) >= kmax);
 
 if end_of_Lanczos | (max (k_u, k_y) >= kmin)
  % the minimum number of iterations has been done
  % evaluate termination criterion
  % determine smallest local minimizer of Ut0 (lambda)
  
  lambda = mmq_gcv_l_GlobalMin ('mmq_gcv_l_Ut0', lambdamin, lambdamax); 

  if lambda <= lambdamin
   success = 1;
  else
   lambda1 = mmq_gcv_l_GlobalMax ('mmq_gcv_l_Lt0', lambdamin, lambda);
   success = (mmq_gcv_l_Lt0 (lambda1) > mmq_gcv_l_Lt0 (lambda));
  end
  
  % plot frequency
  %freq=10;
  freq=1;
  if plots & ((rem (max (k_u, k_y), freq) == 0) | success)
   % compute the bounds
   [lt0, dlt0] = mmq_gcv_l_Lt0 (lambdas);
   [ut0, dut0] = mmq_gcv_l_Ut0 (lambdas);
   loglog(lambdas,ut0,'--')
   [ut0lambda, dut0lambda] = gcv_l_Ut0 (lambda);
   [lt0lambda, dlt0lambda] = gcv_l_Lt0 (lambda1);
   % plot the mins
   %  loglog (lambda, ut0lambda, 'o', lambda1, lt0lambda, 's');
   %  hold off;
   axis([0.1*lambdas(1) 10*lambdas(end) 0.9*min(vlambdas) 1.1*max(vlambdas)])
   if success
    hold on;
    [ut0lambda, dut0lambda] = gcv_l_Ut0 (lambda);
    [lt0lambda, dlt0lambda] = gcv_l_Lt0 (lambda1);
    % plot the mins
    %loglog (lambda, ut0lambda, 'o', lambda1, lt0lambda, 's');
    hold off;
   end
   title (['Lt0 (nu),  Gt (nu),  Ut0 (nu),  ' ...
     'k_u = ' int2str(k_u) ',  k_y = ' int2str(k_y)]);
  end
 end
end

if success
 % display results
 if plots == 1
  fprintf (1, '\n');
  fprintf (1, 'MMQ_GCV_LANCZOS\n\n');
  fprintf (1, 'nuopt  = %11.4e  muopt = %11.4e\n', lambdaopt,m*lambdaopt);
  fprintf (1, 'nutopt = %11.4e  mutopt = %11.4e\n', lambdatopt,m*lambdatopt);
 end
 fprintf (1, '\n');
 fprintf (1, 'MMQ_GCV_LANCZOS\n\n');
 fprintf (1, 'nu     = %11.4e  mu = %11.4e\n', lambda,m*lambda);
 fprintf (1, '%4i Lanczos iterations\n\n', max (k_u, k_y));
end
