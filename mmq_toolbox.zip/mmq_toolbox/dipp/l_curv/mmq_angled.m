function k=mmq_angled(r,x);
%MMQ_ANGLED locates the l-corner by computing the angles
%
% r and x norm of the residual and solution
%
% Author G. Meurant
% Feb 2007
%

q=0;
p=length(r);

for i=1:p-1
 v=[r(i+1)-r(i);x(i+1)-x(i)];
 nv=norm(v);
 q=q+1;
 vq(:,q)=v/nv;
end
for i=1:q-1
 v1=vq(:,i);
 v2=vq(:,i+1);
 ac=acos(v1'*v2);
 dv=v2-v1;
 if dv(1) < 0 | dv(2) < 0
  w(i)=pi+ac;
 else
  w(i)=pi-ac;
 end
end
 
[mw,k]=min(w);
 
k=k+1;