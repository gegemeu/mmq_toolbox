function w=mmq_qrgauss(t,alpha,beta,mu0);
%MMQ_QRGAUSS given the nodes t and the Jacobi matrix 
% (alpha, beta) computes the weights w
% mu0 is the zero-th moment
% from Laurie's paper
%

% Author G. Meurant
% June 2007
%

n=length(alpha);
ww=eye(n,1);

for j=n:-1:3
 [alpha,beta,ww]=mmq_qrsweep(alpha,beta,t(j),ww);
 w(j)=ww(j);
 % deflation
 alpha=alpha(1:j-1);
 beta=beta(1:j-2);
 ww=ww(1:j-1);
end

% we are left with a 2 x 2 matrix J
[alpha,beta,ww]=mmq_qrsweep(alpha,beta,t(2),ww);
w(2)=ww(2);

% first element
w(1)=ww(1);

% the weights are mu0 times the squares of the first components
w=mu0*w.^2;




 