function [q,e,e0,alpha,beta]=mmq_pftoqd(t,w);
%MMQ_PFTOQD computes the augmented QD row of a partial fraction
% given by the points t and the weights w
% from Laurie's paper

% Author G. Meurant
% June 2007
%

n=length(t);

mu=w(n);
alpha(1)=t(n);
beta=[];
if n == 1
  q=0;
  e=0;
  e0=0;
 return
end

% sort the points and compute the differences
[t,ind]=sort(t);
w=w(ind);
if size(t,1) ~= 1
 t=t';
end
t=[0 t];
sig=t(2:end)-t(1:end-1);

if size(w,1) ~= 1
 w=w';
end
Q=[w zeros(1,n)];
k=n+1;
Q(k)=sig(n);

for j=n-1:-1:1
 [Q(j:2:k),Q(j+1:2:k)]=mmq_dqds(Q(j:2:k),Q(j+1:2:k),0);
 if j > 1
  [Q(j+1:2:k+1),Q(j+2:2:k+1)]=mmq_dstqd(Q(j+1:2:k+1),Q(j+2:2:k+1),-sig(j));
 else
  %[Q(j+1:2:k+1),Q(j+2:2:k+1)]=mmq_dstqd(Q(j+1:2:k+1),Q(j+2:2:k+1),-sig(j));
 end
 k=k+1;
end

q=Q(2:2:2*n);
e=Q(3:2:2*n-1);
e0=Q(1);
alpha(1)=q(1);
alpha(2:n)=q(2:n)+e(1:n-1);
% we have to use t_2 instead of t_1 because we put a 0 in front of t
alpha=alpha+t(2);
beta(1:n-1)=sqrt(q(1:n-1).*e(1:n-1));
