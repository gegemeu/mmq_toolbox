function [ut0, dut0, nn, dd] = mmq_gcv_l_Ut0nd (lambda);
%MMQ_GCV_L_UT0ND computes the upper bound of the GCV function
% returns also the numerator and denominator of the function
%
% Author Urs von Matt
% G. Meurant, Jan 2007
%
% The statement
%
%     [ut0, dut0] = gcv_l_Ut0 (lambda)
%
% evaluates the function  Ut0 (lambda)  and its derivative:
%
%     ut0 = Ut0 (lambda)
%
%               d
%     dut0 = ------- Ut0 (lambda)
%            dlambda
%

%
% communication among
% mmq_gcv_lanczos, mmq_gcv_l_Bounds, mmq_gcv_l_Lt0, mmq_gcv_l_Lt1,
% mmq_gcv_l_Ut0, mmq_gcv_l_Ut1, mmq_test_gcv_Vt
%
global gcv_l_m gcv_l_n gcv_l_normy gcv_l_normK gcv_l_normKTy ...
 gcv_l_u gcv_l_normu ...
gcv_l_gamma_y gcv_l_delta_y gcv_l_gamma_u gcv_l_delta_u;

n_y = length (gcv_l_gamma_y);
if length (gcv_l_delta_y) ~= n_y
 error ('MMQ_GCV_L_UT0ND: length (gcv_l_delta_y) ~= n_y');
end

n_u = length (gcv_l_gamma_u);
if (n_u > 1) & (length (gcv_l_delta_u) ~= n_u - 1)
 error ('MMQ_GCV_L_UT0ND: length (gcv_l_delta_u) ~= n_u - 1');
end

[m_lambda, n_lambda] = size (lambda);
ut0 = zeros (m_lambda, n_lambda);
dut0 = zeros (m_lambda, n_lambda);
N = m_lambda * n_lambda;

m = gcv_l_m;
n = gcv_l_n;

for i = 1:N
 if lambda (i) < 0
  error ('MMQ_GCV_L_UT0ND: lambda (i) < 0');
 end
 mu = m * lambda (i);
 
 Bk = sparse (1:n_y, 1:n_y, gcv_l_gamma_y, n_y+1, n_y) + ...
  sparse (2:n_y+1, 1:n_y, gcv_l_delta_y, n_y+1, n_y);
 [Q, u, v] = lbidiagQR (gcv_l_gamma_y, gcv_l_delta_y, sqrt (mu));
 b = lbidiagQTx (Q, eye (2*n_y+1, 1));
 xi = ubidiagSolve (u, v, b (1:n_y));
 res = eye (n_y+1, 1) - Bk * xi;
 num = (gcv_l_normy * norm (res, 2))^2;
 b = [zeros(n_y+1,1); xi];
 b = lbidiagQTx (Q, b);
 eta = ubidiagSolve (u, v, b (1:n_y));
 nump = 2 * gcv_l_normy^2 * m * sqrt (mu) * (eta' * xi);
 
 [Q, u, v] = ubidiagQR (gcv_l_gamma_u, gcv_l_delta_u, sqrt (mu));
 b = [zeros(n_u,1); eye(n_u,1)];
 b = ubidiagQTx (Q, b);
 xi = ubidiagSolve (u, v, b (1:n_u));
 den = (m - n) + gcv_l_normu^2 * sqrt (mu) * xi (1);
 [Q, u, v] = lbidiagQR (gcv_l_gamma_u, [gcv_l_delta_u(:); 0], sqrt (mu));
 b = lbidiagQTx (Q, eye (2*n_u+1, 1));
 eta = ubidiagSolve (u, v, b (1:n_u));
 denp = m * (gcv_l_normu * norm (eta, 2))^2;
 
 ut0 (i) = m * num / den^2;
 nn(i)=m*num;
 dd(i)=den^2;
 dut0 (i) = m * (nump / den^2 - 2 * num * denp / den^3);
end
