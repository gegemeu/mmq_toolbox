function [d,l,d1,ld,ldd]=mmq_initprec(a,precond,param);
%MMQ_INITPREC computes some preconditioners for CG
% a symmetric matrix
%
% precond - type of preconditioning
%  ='no' M=I
%  ='sc' diagonal
%  ='ic' IC(0)
%  ='ch' IC(epsilon)
%  ='ss' SSOR with omega=1 
% param - parameter needed by some preconditioners
%  = nothing for 'no', 'ss' and 'ic'
%  = epsilon for 'ch
%
% output (depends on precond)
%  for incomplete factorizations 
%   l - lower triangular factor
%   d - inverse of the diagonal matrix (to multiply the rhs)
%   d1 - square root of the diagonal (or its inverse) for accuracy estimates
%   ld - l sqrt(d) or l sqrt(1/d)
%   ldd - inf norm of the inverse of l sqrt(d)
%

% Author G. Meurant
% Feb 2001
%

n=size(a,1);
ee=ones(n,1);

switch precond
 
case 'no'
 % no preconditioning
 d=ones(n,1);
 d1=d;
 l=speye(n);
 ld=1;
 ldd=1;
 
case 'sc'
 % diagonal preconditioning
 d=diag(a);
 d1=d;
 l=speye(n);
 ld=1;
 ldd=max(1./sqrt(d));
 
case 'ss'
 %  SSOR = L D^{-1} L^T with D diag of a
 l=tril(a);
 d=diag(a);
 d1=sqrt(1./d);
 ls=l*spdiags(d1,0,n,n);
 ld=normest(ls);
 w=ls\ee;
 ldd=max(abs(w));
 
case 'ic'
 % Incomplete Cholesky with the same structure as a
 % computes L D L^T with diag(L)=1
 % send back D^{-1}
 b=a;
 for k=1:n-1
  m=size(b,1);
  b1=1/b(1,1);
  i=find(a(k:n,k));
  sl=sparse(i,1,b(i,1)*b1,m,1);
  l(k:n,k)=sl;
  l(k,k)=1;
  d(k)=b(1,1);
  ind=i(2:end)-1;
  sl=sl(2:m);
  bb=b(2:m,2:m);
  % do not take care of symmetry (faster)
  for i=ind
   bb(i,ind)=bb(i,ind)-b(1,1)*sl(i)*sl(ind)';
  end
  b=bb;
 end
 l(n,n)=1;
 d(n)=b(1,1);
 ind=find(d<=0);
 if length(ind) > 0
  error('MMQ_INITPREC: pb with the incomplete factorization')
 end
 d=d';
 d1=sqrt(d);
 ls=l*spdiags(d1,0,n,n);
 ld=normest(ls);
 w=ls\ee;
 ldd=max(abs(w));
 d=1./d;
 
case 'ch'
 % Incomplete Cholesky keeping some fill-in
 % same factorization as the previous one
 epsdrop=param;
 b=a;
 %
 % norm of each row of a
 for i=1:n
  anorm(i)=norm(a(i,:), inf);
 end
 for k=1:n-1
  m=size(b,1);
  b1=1/b(1,1);
  ii=find(b(:,1));
  sl=sparse(ii,1,b(ii,1)*b1,m,1);
  l(k:n,k)=sl;
   
  % dropping strategy
  i=find(abs(l(k+1:n,k))./anorm(k+1:n)'<=epsdrop);
  l(i+k,k)=zeros(length(i),1);
  l(k,k)=1;
  d(k)=b(1,1);
  %
  % Schur complement
  ind=find(l(k+1:n,k))';
  sl=sl(2:m);
  bb=b(2:m,2:m);
  for i=ind
   bb(i,ind)=bb(i,ind)-b(1,1)*sl(i)*sl(ind)';
  end
  b=bb;
 end
 l(n,n)=1;
 d(n)=b(1,1);
 ind=find(d<=0);
 if length(ind) > 0
  error('MMQ_INITPREC: pb with the incomplete factorization')
 end
 d=d';
 d1=sqrt(d);
 ls=l*spdiags(d1,0,n,n);
 ld=normest(ls);
 w=ls\ee;
 ldd=max(abs(w));
 d=1./d;

otherwise
 error('MMQ_INITPREC: error, this preconditioner does not exist')
end
