%MMQ_RUN_TEST_GCV_ILAPLACE run GCV for the Inverse Laplace problem
%
% Author G. Meurant Dec 2006
%

warning off

% Test problem: inverse Laplace transformation
% (regutools/ilaplace)

gcase = 6;
m=100;
n=100;

noise = 1E-7;
mmq_test_gcv;

pause

noise = 1E-5;
mmq_test_gcv;

pause

noise = 1E-3;
mmq_test_gcv;

pause

noise = 1E-1;
mmq_test_gcv;

pause

noise = 10;
mmq_test_gcv;


warning on