function mmq_plot_l_curve(a,y,x0);
%MMQ_PLOT_L_CURVE plot the l-curve computed by using the SVD of a
% also plots the angles and errors
%
% Author G. Meurant
% Feb 2007
%

% compute the SVD

[u,s,v]=svd(a);
size(s)
s=diag(s);
size(s)
maxs=max(s);
m=size(a,1);

normK=norm(a,'fro');
% useful range for lambda
lambdamax = maxs^2
lambdamin = (eps * normK)

aa=log10(m*lambdamin);
bb=log10(m*lambdamax);

n=50;
tt=linspace(aa,bb,n);

d=u'*y;

for i = 1:n
 
 mu = 10^tt (i);
 
 % compute the norm of c-Ax using the  singular values of A
 
 t = s.^2 + mu;
 num=  sum ((mu*d ./ t).^2);
 
 % norm of x
 
 den=sum((s .* d ./ t).^2);
 % absolute value of the derivative
 dden=2*sum((s.^2 .* d.^2) ./ t.^3);
 dden=dden;
  % derivative
 dnum=mu*dden;
 
 nri=sqrt(num);
 nxi=sqrt(den);
 
 r(i)=nri;
 x(i)=nxi;
 dr(i)=mu*dnum/(2*nri);
 dx(i)=mu*dden/(2*nxi);
 
 sol=mmq_solipp(mu,u,s,v,y);
 err(i)=norm(sol-x0);
end

tte=10.^tt;

plot(tt,log10(x))
hold on
plot(tt,log10(r),'r--')
title('||x|| (solid) and ||c-Ax|| (dashed)')
hold off

figure
plot(tt,log10(dx))
hold on
plot(tt,log10(dr),'r--')
title('Log_{10} of derivatives of ||x|| (solid) and ||c-Ax|| (dashed)')
hold off

delx=abs(x(2:end)-x(1:end-1));
delr=abs(r(2:end)-r(1:end-1));

figure
plot(tt(2:end),log10(delx))
hold on
plot(tt(2:end),log10(delr),'r--')
title('Log_{10} of differences of ||x|| (solid) and ||c-Ax|| (dashed)')
hold off
delx=abs(x(2:end)-x(1:end-1));
delr=abs(r(2:end)-r(1:end-1));

delx=abs(log10(x(2:end))-log10(x(1:end-1)));
delr=abs(log10(r(2:end))-log10(r(1:end-1)));

figure
plot(tt(2:end),log10(delx))
hold on
plot(tt(2:end),log10(delr),'r--')
title('log_{10} of differences of log_{10} ||x|| (solid) and ||c-Ax|| (dashed)')
hold off

figure
loglog(r,x,'o-')
title('L-curve')

figure
ddr=(r(2:end)-r(1:end-1)).^2;
ddx=(x(2:end)-x(1:end-1)).^2;
dist2=ddr+ddx;
dist=sqrt(dist2);
plot(tt(2:end),log10(dist),'-')
title('Distances on the L-curve')

p=length(r);
q=0;
for i=1:p-1
 v=[r(i+1)-r(i);x(i+1)-x(i)];
 nv=norm(v);
 q=q+1;
 vq(:,q)=v/nv;
end
for i=1:q-1
 v1=vq(:,i);
 v2=vq(:,i+1);
 ac=acos(min(v1'*v2,1));
 dv=v2-v1;
 if dv(1) < 0 | dv(2) < 0
  w(i)=pi+ac;
 else
  w(i)=pi-ac;
 end
end
w=w*180/pi;
figure
plot(tt(2:end-1),w)
axis([tt(2)-1 tt(end-1)+1 min(w)-5 max(w)+5])
title('Angles')

figure
pr=r.*x;
[tmp,mpr]=min(pr);
plot(tt,log10(pr))
hold on
title('Product')
plot(tt(mpr),log10(pr(mpr)),'o')
hold off

figure
plot(tt,log10(err))
hold on
[tmp,te]=min(err);
plot(tt(te),log10(err(te)),'o')
title('Log_{10}(error)')
hold off