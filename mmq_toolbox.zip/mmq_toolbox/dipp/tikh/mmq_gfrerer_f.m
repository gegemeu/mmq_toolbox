function [f, df] = mmq_gfrerer_f (lambda)
%MMQ_GFRERER_F used by Gfrerer in mmq_l_newton
%
% From Urs von Matt
%
global discrep_c discrep_s discrep_z

f = lambda^3 * sum (discrep_z.^2 ./ (discrep_s.^2 + lambda).^3) + discrep_c;
df = 3 * lambda.^2 * ...
     sum ((discrep_s .* discrep_z).^2 ./ (discrep_s.^2 + lambda).^4);
