function origin=mmq_l_origin(rho,eta);
%MMQ_L_ORIGIN finds the "origin" of an L-curve
% this is used to rotate the L-curve defined by rho and eta
% which are the logs of the norms
%
% Author G. Meurant
% Feb 2007
% derived from a code by Hansen and Rodriguez
%

sr=size(rho);
if sr(1,1) == 1
 rho=rho';
end
se=size(eta);
if se(1,1) == 1
 eta=eta';
end
rho=rho(end:-1:1);
eta=eta(end:-1:1);

nP = length(rho);           % Number of points
%P = log10([rho eta]);      % Coordinates of the loglog L-curve
P = [rho eta];              % the inputs are logs already
V = P(2:nP,:)-P(1:nP-1,:);  % The vectors defined by these coordinates
v = sqrt(sum(V.^2,2));      % The length of the vectors
W = V./repmat(v,1,2);       % Normalized vectors

% Sort the vectors according to the length, the longest first
[Y,I] = sort(v);
I = flipud(I);

elmts=sort(I);
vects=W(elmts,:);

hwedge = abs(vects(:,2));  % Abs of wedge products between
% normalized vectors and horizontal
% i.e., angle of vectors with horizontal
[An, In] = sort(hwedge);   % Sort angles in increasing order

% Locate vectors for describing horizontal and vertical part of L-curve
count = 1;
ln = length(In);
mn = In(1);
mx = In(ln);
while(mn>=mx)
 mx = max([mx In(ln-count)]);
 count = count + 1;
 mn = min([mn In(count)]);
end
if count > 1
 I = 0; J = 0;
 for i=1:count
  for j=ln:-1:ln-count+1
   if(In(i) < In(j))
    I = In(i); J = In(j); break
   end
  end
  if I>0, break; end
 end
else
 I = In(1); J = In(ln);
end

% Find intersection that describes the "origin"
x3 = P(elmts(J)+1,1)+(P(elmts(I),2)-P(elmts(J)+1,2))/(P(elmts(J)+1,2) ...
 -P(elmts(J),2))*(P(elmts(J)+1,1)-P(elmts(J),1));
origin = [x3 P(elmts(I),2)];