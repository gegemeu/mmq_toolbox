function [reg_min,Q,reg_param] = mmq_quasiopt(U,s,b); 
%MMQ_QUASIOPT Quasi-optimality criterion for choosing the regularization parameter
%
% Needs the Regularization Toolbox Regutools (quasifun)
% 
% Plots the quasi-optimality function Q 
% Tikhonov regularization   (solid line ) 
% 
% If any output arguments are specified, then the minimum of Q is 
% identified and the corresponding reg. parameter reg_min is returned.

% From Per Christian Hansen, IMM, Feb. 21, 2001


plots=0;
find_min=1;

% Set defaults
npoints = 200;  % Number of points for 'Tikh' 

% Initialization
[m,n] = size(U); [p,ps] = size(s); 
if (ps==2), s = s(p:-1:1,1)./s(p:-1:1,2); U = U(:,p:-1:1); end 
xi = (U'*b)./s; 

% Compute the quasioptimality function Q

% Compute a vector of Q-values
Q = zeros(npoints,1); reg_param = Q; 
reg_param(npoints) = s(p); 
ratio = (s(1)/s(p))^(1/(npoints-1)); 
for i=npoints-1:-1:1, reg_param(i) = ratio*reg_param(i+1); end 
for i=1:npoints 
 Q(i) = quasifun(reg_param(i),s,xi); 
end 

% Find the minimum, if requested
if (find_min) 
 [minQ,minQi] = min(Q); % Initial guess
 reg_min = fminbnd('quasifun',... 
  reg_param(min(minQi+1,npoints)),reg_param(max(minQi-1,1)),... 
  optimset('Display','off'),s,xi); % Minimizer
 minQ = quasifun(reg_min,s,xi); % Minimum of function
end 

if plots == 1
 
 % Plot the function
 
 loglog(reg_param,Q), xlabel('\lambda'), ylabel('Q(\lambda)') 
 title('Quasi-optimality function') 
 if (find_min) 
  ax = axis; 
  HoldState = ishold; hold on; 
  loglog([reg_min,reg_min],[minQ,minQ/1000],'--') 
  axis(ax) 
  if (~HoldState), hold off; end 
  title(['Quasi-optimality function, minimum at ',num2str(reg_min)]) 
 end 
end 



