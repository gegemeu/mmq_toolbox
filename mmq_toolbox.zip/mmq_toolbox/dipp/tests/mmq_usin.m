function y=mmq_usin(n);
%MMQ_USIN computes a sine vector
%
% Author G. Meurant
% Feb 2007
%

x=pi*[1:n]'/(n+1);
k=2;
y=sin(k*x);
