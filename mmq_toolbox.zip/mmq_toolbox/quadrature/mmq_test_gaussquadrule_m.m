function mmq_test_gaussquadrule_m
%MMQ_TEST_GAUSSQUADRULE_M test program for mmq_gaussquadrule_m
% compare with results of tables
% 

% Author G. Meurant
% June 2007
%

tic
n=10;
% Legendre polynomials
disp(' ')
disp('------ Legendre quadrature')
[a,b,mu0]=mmq_classicorthopoly('le',n,0,0);
[t,w]=mmq_gaussquadrule_m(a,b,mu0);
disp(' ')
disp('          Abscissas                   Weights ')
[t' w']

% Laguerre polynomials
disp('  ')
disp('----- Laguerre quadrature with alpha = -0.75')
[a,b,mu0]=mmq_classicorthopoly('gl',n,-0.75,0);
str=sprintf('mu0 = %25.16e',mu0);
disp(str)
[t,w]=mmq_gaussquadrule_m(a,b,mu0);
disp(' ')
disp('          Abscissas                  Weights ')
[t' w']  
tc(1)=2.76665586707972e-2;
tc(2)=4.54784422605949e-1;
tc(3)=1.382425761158599;
tc(4)=2.833980012092697;
tc(5)=4.850971448764914;
tc(6)=7.500010942642825;
tc(7)=1.0888408023834404e1;
tc(8)=1.5199478044237603e1;
tc(9)=2.0789214621070107e1;
tc(10)=2.8573060164922106e1;

wc(1)=2.566765557790772;
wc(2)=7.73347970344341e-1;
wc(3)=2.33132834973219e-1;
wc(4)=4.64367470895670e-2;
wc(5)=5.54912350203625e-3;
wc(6)=3.65646662677638e-4;
wc(7)=1.18687985710245e-5;
wc(8)=1.58441094205678e-7;
wc(9)=6.19326672679684e-10;
wc(10)=3.03775992651750e-13;

disp(' ')
disp(' Relative errors on abscissas / Concus and al')
abs(t'-tc')./abs(tc')
disp(' ')
disp(' Relative errors on weights / Concus and al')
abs(w'-wc')./abs(wc')

% Laguerre using moments
disp('  ')
disp('----- Laguerre quadrature using moments with alpha = -0.75')
mu0=3.62560990822190820;
mm=mu0;
for i=1:20
 mu(i)=(i-3/4)*mm;
 mm=mu(i);
end
mu=[mu0 mu];
[a,b]=mmq_genorthopoly(n,mu);
mu0
a
b
[t,w]=mmq_gaussquadrule_m(a,b,mu0);
disp(' ')
disp('          Abscissas                  Weights ')
[t' w']  

disp(' ')
disp(' Relative errors on abscissas / Concus and al')
abs(t'-tc')./abs(tc')
disp(' ')
disp(' Relative errors on weights / Concus and al')
abs(w'-wc')./abs(wc')
disp(' ')
toc