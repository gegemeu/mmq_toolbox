function [nt,sigt,alphat,betat,dt]=mmq_rhrud_rot3d(n,alpha,beta,sig,d,x,w,y);
%MMQ_RHRUD_ROT3D least squares downdating using eigenvectors
% 
% x is the eigenvalue to be downdated
% the eigenvector is computed using mmq_teigv (MRRR)
%
%
% Author G. Meurant
% June 2007
%

if length(x) ~= 1 | length(w) ~= 1 | length(y) ~= 1
 error('MMQ_RHRUD_ROT3D: must add one point at a time')
end

nt=n-1;
d_old=d;

% q  eigenvector corresponding to x
q=mmq_teigv(n,alpha,beta,x,0);

[nt,sigt,alphat,betat,dt,cd,sd]=mmq_rev_eig1(n,alpha,beta,sig,d,x,w,y,q);
