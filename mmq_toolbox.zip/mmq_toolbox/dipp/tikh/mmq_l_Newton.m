function x = mmq_l_Newton (F, a, b);
%MMQ_L_NEWTON Newton's iterations used by discrep
%
% Author Urs von Matt
%
% The statement  x = mmq_l_Newton (F, a, b)  determines a zero of f (x)
% in the interval  [a, b].
%
% It is assumed that
%
%     [f, df] = feval (F, x)
%
% evaluates the values
%
%     f = f (x)
%     df = f' (x)
%
% It is also assumed that  f (x)  is a continuous differentiable
% function with  f (a) * f (b) <= 0.
%

% check input
if a > b
 error ('MMQ_L_NEWTON: a > b');
end

[fa, dfa] = feval (F, a);
[fb, dfb] = feval (F, b);
if sign (fa) * sign (fb) == 1
 disp ('MMQ_L_NEWTON: f (a) * f (b) > 0');
 x=0;
 return
end

if a == b
 x = a;
 return;
end

if fa == 0
 x = a;
 return;
end
if fb == 0
 x = b;
 return;
end

while 1
 % a < b,  sign (fa) * sign (fb) < 1
 
 m = (a + b) / 2;
 if (m <= a) | (m >= b)
  x = m;
  break;
 end
 
 % quadratic interpolation
 c0 = fa;
 c2 = 0.5 * (b - a) * (dfb - dfa);
 c1 = (fb - fa) - c2;
 if c1 == 0
  t = sqrt (abs (fa / (fb - fa)));
 elseif c2 == 0
  t = - c0 / c1;
 else
  discr = ((fa + fb) - c2)^2 - 4 * fa * fb;
  if c1 > 0
   t2 = (-c1 - sqrt (discr)) / (2 * c2);
   t1 = c0 / (c2 * t2);
  else
   t2 = (-c1 + sqrt (discr)) / (2 * c2);
   t1 = c0 / (c2 * t2);
  end
  if (t1 > 0) & (t1 < 1)
   t = t1;
  elseif (t2 > 0) & (t2 < 1)
   t = t2;
  else
   % t1 and t2 are out of range due to rounding errors
   t = 0.5;
  end
 end
 x = a + t * (b - a);
 if (x <= a) | (x >= b)
  % x is out of range due to rounding errors
  x = m;
 end
 
 [fx, dfx] = feval (F, x);
 if fx == 0
  break;
 end
 if x < m
  if sign (fx) == sign (fb)
   b = x;
   fb = fx;
   dfb = dfx;
   bisection = 0;
  else
   a = x;
   fa = fx;
   dfa = dfx;
   bisection = 1;
  end
 else
  if sign (fx) == sign (fa)
   a = x;
   fa = fx;
   dfa = dfx;
   bisection = 0;
  else
   b = x;
   fb = fx;
   dfb = dfx;
   bisection = 1;
  end
 end
 
 if bisection
  % progress by Newton's iteration was insufficient
  m = (a + b) / 2;
  if (m <= a) | (m >= b)
   x = m;
   break;
  end
  [fm, dfm] = feval (F, m);
  if sign (fm) == sign (fb)
   b = m;
   fb = fm;
   dfb = dfm;
  else
   a = m;
   fa = fm;
   dfa = dfm;
  end
 end
end
