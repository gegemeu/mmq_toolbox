function mmq_plotsecul4b(d,c);
%MMQ_PLOTSECUL4 plots figures of the TLS secular equation
% as a function of sigma^2
% the function is defined in secul
%
% Author G. Meurant
% july 2007
%

warning off

km=length(d);
lmin=min(d(:).^2);
lmax=max(d(:).^2);
dta=sort(d);
lmm=lmax-lmin;
ymax=10;
ymin=-10;

k=km;
 
% we  need the components squared
xi=(c(:).^2);
figure
hold on

% plot the poles
for i=1:k
  plot([d(i)^2 d(i)^2],[-ymax ymax],'--')
end

% plot the pole at 0
plot([0 0],[-ymax ymax],'--')

% plot the function  between the k poles 
lamb=[lmin-9 0 d(:).^2' lmax+2];
for i=1:k+2
  epsi1=(lamb(i+1)-lamb(i))*1e-2;
  epsi2=epsi1;
  if i == 1
    epsi1=-lmin/2;
    epsii=epsi1;
  end
  if i == k+2
    epsi2=-lmin/2;
  end
  x=linspace(lamb(i)+epsi1,lamb(i+1)-epsi2,50);
  y=secul(xi,d,x);
  plot(x,y)
end

% plot( the x axis
plot([min(lamb) max(lamb)],[0 0],'-.')
axis([min(lamb) max(lamb) -ymax ymax])
title(['TLS secular function as a function of \sigma^2'])
hold off

warning on

end

function y=secul(xi,dts,x);
%SECUL function f
%
k=length(x);
kd=length(dts);
for i=1:k
  z=xi(1:kd).^2./(dts(:).^2-x(i));
  y(i)=(1+sum(z)-sum(xi(kd+1:end).^2)/x(i));
end

end
