function [nt,sigt,alphat,betat,dt,eigvec,eigval]=mmq_rhrud_rot2d(n,alpha,beta,sig,d,x,w,y,eigvec,eigval,idown);
%MMQ_RHRUD_ROT2D least squares downdating using eigenvectors
%
% use the stored rotations to compute the eigenvectors of downdated J 
% idown index of the eigenvalue to be downdated: eigval(idown) must be x
%
%
% Author G. Meurant
% May 2007
%

if length(x) ~= 1 | length(w) ~= 1 | length(y) ~= 1
 error('MMQ_RHRUD_ROT2D: must remove one point at a time')
end

nt=n-1;
d_old=d;

% q  eigenvector corresponding to idown
q=eigvec(:,idown);

[nt,sigt,alphat,betat,dt,cd,sd]=mmq_rev_eig(n,alpha,beta,sig,d,x,w,y,q);

eigval=[eigval(1:idown-1); eigval(idown+1:n)];

% computation of the new eigenvectors 
ww=eigvec(1:n,1:n);
ww_old=ww;
for i=n-1:-1:1
 r=speye(n,n);
 r(i,i)=cd(i);
 r(n,n)=cd(i);
 r(n,i)=-sd(i);
 r(i,n)=sd(i);
 ww=r*ww;
end
% positive first elements
for i=1:n
  if ww(1,i) < 0 & i ~= idown
    ww(:,i)=-ww(:,i);
  end
end

% deflate the last row and a column
z=[ww(1:n-1,1:idown-1) ww(1:n-1,idown+1:n)];
%eigvec(1:n-1,1:n-1)=z;
eigvec=z;

% recomputing alpha and beta is better but not by much
%J_new=z*diag(eigval(1:n-1))*z';
%alphat=diag(J_new)';
%betat=diag(J_new,-1)';
sigt=sqrt(sig^2-w^2);

% downdate d
dd=ww*ww_old'*d_old';
dt=dd(1:n-1)';
