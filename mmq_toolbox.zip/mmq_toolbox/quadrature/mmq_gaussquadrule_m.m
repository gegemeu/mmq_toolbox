function [t,w]=mmq_gaussquadrule_m(a,b,mu0);
%MMQ_GAUSSQUADRULE_M computes nodes and weights of the Gauss rule using the Matlab QR algorithm
% a and b are the elements of the diagonal and subdiagonal of the Jacobi
% matrix for the orthonormal polynomials associated with the measure
% mu0 is the moment of order zero
%

% Author G. Meurant
% June 2007
%
if length(a) == 1
  t=a(1);
  w=mu0;
  return
end

J=diag(a)+diag(b,-1)+diag(b,1); 
J=full(J);
[V,D]=eig(J);
t=diag(D);
[t,i]=sort(t);
w=mu0*V(1,i).^2;
t=t';