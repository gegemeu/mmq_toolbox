%
% Contents of L_CURV
%
% MMQ_ANGLE locates the l-corner by computing the angles
% MMQ_ANGLED locates the l-corner by computing the angles
% MMQ_COMP_L_CURVE computes the l-curve 
% MMQ_COMP_L_CURVE1 computes the l-curve 
% MMQ_COMP_L_CURVE2 computes the l-curve using the SVD of a
% MMQ_COMP_L_RIBBON computes one point of the L-ribbon 
% MMQ_COMP_L_RIBBON1 computes the function for the curvature of the L-curve
% MMQ_COMP_L_RIBBONC computes the function for the curvature of the L-curve
% MMQ_CORNER find corner of discrete L-curve via adaptive pruning algorithm
% MMQ_FCORNER computes the rotated values of the l-curve
% MMQ_FLCURVE computes the values of the l-curve
% MMQ_L_CORNER locates the corner of the l-curve by rotating it
% MMQ_L_CURVE Plot the L-curve and find its "corner"
% MMQ_L_CURVE_ROT locates the corner of the l-curve by rotation
% MMQ_L_CURVE_RT locates the corner of the L-curve by RT algoritm
% MMQ_L_INTERVAL locates intervals where the differences of the norms of x and r are
% MMQ_L_ORIGIN finds the "origin" of an L-curve
% MMQ_L_RIBBON computes the L-ribbon from the paper by Calvetti, Hansen and
% MMQ_L_RIBBON_CORNER computes the corners of the L-ribbon approximations
% MMQ_L_RIBBON_CORNER_IT computes the corners of the L-ribbon approximations
% MMQ_L_RIBBON_CORNER_IT_G computes the corners of the L-ribbon approximations
% MMQ_L_RIBBON_CORNER_REORT computes the corners of the L-ribbon approximations
% MMQ_L_RIBBON_CORNER_REORT_IT computes the corners of the L-ribbon approximations
% MMQ_L_RIBBON_CORNER_REORT_IT_G computes the corners of the L-ribbon approximations
% MMQ_L_RIBBON_CURVAT computes the curvatures of the L-ribbon approximations
% MMQ_L_RIBBON_CURVAT_REORT_IT computes the curvatures of the L-ribbon approximations
% MMQ_L_RIBBON_CURVAT_IT_G computes the curvatures of the L-ribbon
% MMQ_L_RIBBON_CURVAT_REORT computes the curvatures of the L-ribbon approximations
% MMQ_L_RIBBON_CURVAT_REORTR computes the curvatures of the L-ribbon approximations
% MMQ_L_RIBBON_CURVAT_REORT_IT computes the curvatures of the L-ribbon approximations
% MMQ_L_RIBBON_CURVAT_REORT_IT_G computes the curvatures of the L-ribbon approximations
% MMQ_L_RIBBON_REORT computes the L-ribbon from the paper by Calvetti, Hansen and Reichel
% MMQ_PLOT_LC_L plot the L-curve, linear scale
% MMQ_PLOT_L_CURVE plot the l-curve computed by using the SVD of a
% MMQ_PLOT_L_CURVE1 plot the l-curve when the matrix is defined by (u, s, v)
% MMQ_PLOT_L_CURVE2 plot the l-curve for gcase=0
% MMQ_ROTAT clowkwise rotation of angle tet
% MMQ_RT locates the l-corner by the Rodriguez and Theis algorithm
% MMQ_SOLIPP1 solution of an ill-posed problem for gcase = 1