function [alpha,beta]=mmq_test_lanczos(N,ix,orth);
%MMQ_TEST_Lanczos test using the Lanczos algorithm 
% to compute the orthogonal polynomials
%
% Author G. Meurant
% June 2007
%

[x,w,y,ier,mu0]=mmq_pwv(N,ix);
if ier == 1
 error('MMQ_TEST_LANCZOS: Unknown problem, abort')
end

if size(x,1) == 1
 x=x';
end

a=spdiags(x,0,N,N);
x0=zeros(N,1);
if size(w,1) == 1
 w=w';
end
b=w;
kmax=N;

if orth == 'or'
 [q,t,vts,dts]=mmq_lanczdor(a,b,x0,kmax);
 alpha=diag(t);
 beta=diag(t,-1);
else
 [q,t,vts,dts]=mmq_lanczo(a,b,x0,kmax);
 alpha=diag(t);
 beta=diag(t,-1);
end
alpha=full(alpha);
beta=full(beta);

% orthogonality of the Lanczos vectors
qqt=q'*q-speye(N,N);
or=max(max(abs(qqt)));
disp('MMQ_TEST_LANCZOS: Level of orthogonality')
or

% errors on the points
% eigenvalues of t in dts
errp=norm(x-dts)/norm(x);
disp('MMQ_TEST_LANCZOS: Error in the eigenvalues')
errp

% errors on the first elements of the eigenvectors
% eigenvectors in vts
vts=abs(vts)*sqrt(mu0);
errw=norm(w'-abs(vts(1,:)))/norm(w);
disp('MMQ_TEST_LANCZOS: Error in the 1rst components')
errw

