function int=mmq_agaussquad(tt,mu0);
%MMQ_AGAUSSQUAD anti-Gauss quadrature for 1/(2+x) and the Jacobi matrix tt
%
% Author G. Meurant
% April 2008
%

a=diag(tt);
b=diag(tt,-1);
n=size(a,1);

% modification for anti-Gauss
b(n-1)=sqrt(2)*b(n-1);

% nodes and weights by Golub and Welsch
[t,w]=mmq_gaussquadrule(a,b,0,mu0,0);

% computation of the integral
ft=1./(2+t);
int=sum(w.*ft);