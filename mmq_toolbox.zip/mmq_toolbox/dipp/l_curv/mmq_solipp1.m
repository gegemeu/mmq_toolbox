function x=mmq_solipp1(mu,u,s,v,y);
%MMQ_SOLIPP1 solution of an ill-posed problem for gcase = 1
% mu is the regularization parameter as in (A^T A+mu I)x=y
%
% Author G. Meurant
% Feb 2007
%
 
 m=size(u,1);
 n=size(v,1);
 r=min(m,n);
 x = y (1:r) - u (1:r) * (u' * y);
 x = (s .* x) ./ (s.^2 + mu);
 x = [x; zeros(n-r,1)] - v * (v (1:r)' * x);