function [S_min,it]=mmq_solve_secul_rat(s_min,Jk,y,ny2,nay2,epss);
%MMQ_SOLVE_SECUL_RAT solves the tridiagonal secular equation for the Gauss approximation of the TLS parameter
% we use tridiagonal systems
% x - ny2 + ny2 y^T inv(Jk-xI) y = 0
% rational approximation 
% s_min is the leftmost pole
%
% Author G. Meurant
% august 2007
%

%warning off

k=size(Jk,1);

x_old=0.99*s_min;
xs=x_old;

itmax=50;
it=0;
sc=1;
err=0;


while it <=itmax & sc > epss
  it=it+1;
  % compute the interpolants
  % function and derivative at the interpolation point x_old
  
  [yx,yxp,yxpp]=secultr(Jk,y,ny2,nay2,x_old);
  
  % rational approximation to third order
  smx=s_min-x_old;
  c=yxpp*smx^3/2;
  b=yxp-yxpp*smx/2;
  a=yx-b*x_old-yxpp*smx^2/2;

  % interpolant is a + b x + c / (s_min - x)
  % quadratic equation 
  aa=b;
  bb=b*s_min-a;
  cc=-(c+a*s_min);
  
  % solution of the quadratic equation
  delta=bb^2-4*aa*cc;
  
  if delta < 0
   disp('MMQ_SOLVE_SECUL_RAT: quadratic equation has no real solution')
   err=1;
  end
  if err == 1
   it=itmax;
   break
  end
  delta=sqrt(delta);
  xm=(bb-delta)/(2*aa);
  xp=(bb+delta)/(2*aa);
  % select the negative root 
  x_new=xm;
  if xp > 0 & xp < s_min 
    x_new=xp;
  end
  
  % eventually try Newton
  %x_new=x_old-yx/yxp;
  
  sc=abs(x_new-x_old)/abs(x_old);
  x_old=x_new;
end

if it >= itmax
 disp('MMQ_SOLVE_SECUL_RAT: itmax iterations, switch to dichotomy')
 [xs,itdich]=mmq_solve_dich_trid1(s_min,Jk,y,ny2,nay2,epss);
 S_min=xs;
 it=it+itdich;
else
 S_min=x_new;
end
[yx,yxp,yxpp]=secultr(Jk,y,ny2,nay2,x_new);
fxf=yx;

%warning on

function [yx,yxp,yxpp]=secultr(Jk,yy,ny2,nay2,x);
%SECULTR function f, f' and f''
%
k=size(Jk,1);

% solve (Jk - xI) y = yy
y=(Jk-x*speye(k,k))\yy;
y2=(Jk-x*speye(k,k))\y;
y3=(Jk-x*speye(k,k))\y2;

yk1=yy'*y;
yk2=yy'*y2;
yk3=yy'*y3;
yx=x-ny2+nay2*yk1;
yxp=1+nay2*yk2;
yxpp=2*nay2*yk3;


