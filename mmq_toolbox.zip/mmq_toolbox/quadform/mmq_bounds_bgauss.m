function [bg,bgrl,bgru,bgl]=mmq_bounds_bgauss(a,j,l,kmax,lmin,lmax);
%MMQ_BOUNDS_BGAUSS computation of estimates using Gauss block quadrature rules (inverse) 
% for the element (j,l) of the inverse of a symmetric matrix a using block Lanczos
% kmax iterations
% lmin, lmax : estimates of the smallest and largest eigenvalues of a

% the computation of the inverse of the block tridiagonal matrix may be too
% costly, see mmq_bounds_bgaussbrec
%
% bg :         Gauss
% bgrl, bgru : Gauss-Radau
% bgl :        Gauss_Lobatto
%
%
% Author G. Meurant
% March 2008
%

rand('state',0);

bg=zeros(2,2,kmax);
bgrl=zeros(2,2,kmax);
bgru=zeros(2,2,kmax);
bgl=zeros(2,2,kmax);

n=size(a,1);
jj=eye(2*kmax);
ej=zeros(n,1);
ej(j)=1;
el=zeros(n,1);
el(l)=1;
x1=zeros(n,2);
x=[ej el];
gam=zeros(2,2);
om=x'*a*x;
jj(1:2,1:2)=om;

% block Lanczos iterations
if kmax > 1
 for k=2:kmax
  r=a*x-x*om-x1*gam';
  x1=x;
  [xa,gama]=qr(r);
  x=[xa(:,1) xa(:,2)];
  gam=gama(1:2,1:2);
  dgam=det(gam);
  if abs(dgam) < 1.e-6
   dgam
   nr=sqrt(r(:,1)'*r(:,1));
   if nr == 0
    break
   end
   r1= r(:,1)/nr;
   y=[x1 r1];
   z=(eye(n)-y*y')*rand(n,1);
   x=[r1 z/sqrt(z'*z)];
  end
  om=x'*a*x;
  jj(2*k-1:2*k,2*k-1:2*k)=om;
  jj(2*k-1:2*k,2*k-3:2*k-2)=gam;
  jj(2*k-3:2*k-2,2*k-1:2*k)=gam';
  r=a*x-x*om-x1*gam';
  [xa,gama]=qr(r);
  gamm=gama(1:2,1:2);
  
  % Gauss
  invjj=inv(jj(1:2*k,1:2*k));
  bg(:,:,k)=invjj(1:2,1:2);
  clear invjj
  
  % Gauss-Radau
  b=zeros(2*k,2);
  b(2*k-1:2*k,1:2)=gamm';
  dmax=inv(jj(1:2*k,1:2*k)-lmin*eye(2*k))*b;
  omm=lmin*eye(2)+dmax(2*k-1:2*k,1:2)'*gamm';
  del=zeros(2,2*k);
  del(1:2,2*k-1:2*k)=gamm;
  jt=zeros(2*k+2,2*k+2);
  jt=[jj(1:2*k,1:2*k) del';del omm];
  invjj=inv(jt);
  bgru(:,:,k)=invjj(1:2,1:2);
  dmin=inv(jj(1:2*k,1:2*k)-lmax*eye(2*k))*b;
  omm=lmax*eye(2)+dmin(2*k-1:2*k,1:2)'*gamm';
  jt=[jj(1:2*k,1:2*k) del';del omm];
  invjj=inv(jt);
  bgrl(:,:,k)=invjj(1:2,1:2);
  clear invjj
  
  % Gauss-Lobatto
  b=zeros(2*k,2);
  i2=eye(2);
  b(2*k-1:2*k,1:2)=i2;
  dmax=inv(jj(1:2*k,1:2*k)-lmin*eye(2*k))*b;
  dn=dmax(2*k-1:2*k,1:2)';
  dmin=inv(jj(1:2*k,1:2*k)-lmax*eye(2*k))*b;
  mn=dmin(2*k-1:2*k,1:2)';
  y=(lmax-lmin)*inv(dn-mn);
  vpy=eig(y);
  if(min(vpy) > 0)
   gamm=chol(y);
  else
   gamm=0;
  end
  omm=lmin*i2+gamm*dn*gamm';
  del=zeros(2,2*k);
  del(1:2,2*k-1:2*k)=gamm;
  jt=zeros(2*k+2,2*k+2);
  jt=[jj(1:2*k,1:2*k) del';del omm];
  invjj=inv(jt);
  bgl(:,:,k)=invjj(1:2,1:2);
  if(min(vpy) <= 0)
   bgl(:,:,k)=zeros(2,2);
  end
  clear invjj
  
 end
end


