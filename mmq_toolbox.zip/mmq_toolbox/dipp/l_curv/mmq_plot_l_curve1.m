function mmq_plot_l_curve1(m,n,noise);
%MMQ_PLOT_L_CURVE1 plot the l-curve when the matrix is defined by (u, s, v)
% computed by using the SVD of a
% as well as the angles and errors
%
% Author G. Meurant
% Feb 2007
%

% Matlab 4 random number generator
rand ('seed', 0);
% Matlab 6,... random number generator
%rand('state',0);
randn ('seed', 0);
%randn('state',0);

% construct the matrix 
r = min (m, n);
c=-0.05;
% generate the singular values using c
s = exp (-abs (c) * [1:r]');
% generate random vectors
u = randn (m, 1);
u = (sqrt (2) / norm (u, 2)) * u;
v = randn (n, 1);
v = (sqrt (2) / norm (v, 2)) * v;
% use the solution of the Shaw problem (need Regutools)
[Ks, ys, x0] = shaw (n);
y0 = mmq_pmata(u,s,v,x0);
y=noisy(y0,noise);

maxs=max(s);

normK=maxs;
% useful range for lambda
lambdamax = maxs^2*m
lambdamin = (eps * normK)

a=log10(lambdamin);
b=log10(lambdamax);

n=50;
tt=linspace(a,b,n);

%d=u'*y;
d=mmq_pmatat(u,s,v,y);

for i = 1:n
 
 mu = 10^tt (i);
 
 % compute the norm of c-Ax using the  singular values of A
 
 t = s.^2 + mu;
 num=  sum ((mu*d ./ t).^2);
 
 % norm of x
 
 den=sum((s .* d ./ t).^2);
 % absolute value of the derivative
 dden=2*sum((s.^2 .* d.^2) ./ t.^3);
 dden=dden;
  % derivative
 dnum=mu*dden;
 
 nri=sqrt(num);
 nxi=sqrt(den);
 
 r(i)=nri;
 x(i)=nxi;
 dr(i)=mu*dnum/(2*nri);
 dx(i)=mu*dden/(2*nxi);
 
 sol=mmq_solipp1(mu,u,s,v,y);
 err(i)=norm(sol-x0);
end

tte=10.^tt;

plot(tt,log10(x))
hold on
plot(tt,log10(r),'r--')
title('||x|| (solid) and ||c-Ax|| (dashed)')
hold off

figure
plot(tt,log10(dx))
hold on
plot(tt,log10(dr),'r--')
title('Log_{10} of derivatives of ||x|| (solid) and ||c-Ax|| (dashed)')
hold off

delx=abs(x(2:end)-x(1:end-1));
delr=abs(r(2:end)-r(1:end-1));

figure
plot(tt(2:end),log10(delx))
hold on
plot(tt(2:end),log10(delr),'r--')
title('Log_{10} of differences of ||x|| (solid) and ||c-Ax|| (dashed)')
hold off
delx=abs(x(2:end)-x(1:end-1));
delr=abs(r(2:end)-r(1:end-1));

delx=abs(log10(x(2:end))-log10(x(1:end-1)));
delr=abs(log10(r(2:end))-log10(r(1:end-1)));

figure
plot(tt(2:end),log10(delx))
hold on
plot(tt(2:end),log10(delr),'r--')
title('log_{10} of differences of log_{10} ||x|| (solid) and ||c-Ax|| (dashed)')
hold off

figure
loglog(r,x,'o-')
title('L-curve')

figure
ddr=(r(2:end)-r(1:end-1)).^2;
ddx=(x(2:end)-x(1:end-1)).^2;
dist2=ddr+ddx;
dist=sqrt(dist2);
plot(tt(2:end),log10(dist),'-')
title('Distances on the L-curve')

p=length(r);
q=0;
for i=1:p-1
 v=[r(i+1)-r(i);x(i+1)-x(i)];
 nv=norm(v);
 q=q+1;
 vq(:,q)=v/nv;
end
for i=1:q-1
 v1=vq(:,i);
 v2=vq(:,i+1);
 ac=acos(min(v1'*v2,1));
 dv=v2-v1;
 if dv(1) < 0 | dv(2) < 0
  w(i)=pi+ac;
 else
  w(i)=pi-ac;
 end
end
w=w*180/pi;
figure
plot(tt(2:end-1),w)
axis([tt(2)-1 tt(end-1)+1 min(w)-5 max(w)+5])
title('Angles')

figure
pr=r.*x;
[tmp,mpr]=min(pr);
plot(tt,log10(pr))
hold on
title('Product')
plot(tt(mpr),log10(pr(mpr)),'o')
hold off

figure
plot(tt,log10(err))
hold on
[tmp,te]=min(err);
plot(tt(te),log10(err(te)),'o')
title('Log_{10}(error)')
hold off