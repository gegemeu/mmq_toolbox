%
% Contents of LSQ
%
% Least Squares data fitting, updating and downdating
%
% MMQ_CHOL1PR1 computes diagonals of the Cholesky decomposition of I + u u^T
% MMQ_GIVENSA computes Givens rotation to zero b, E. Anderson version
% MMQ_GIVENSAF computes Givens rotation to zero b, E. Anderson version
% MMQ_GIVENSHA computes hyperbolic Givens rotation to zero b, E. Anderson version
% MMQ_GIVENSHAF computes hyperbolic Givens rotation to zero b, E. Anderson version
% MMQ_LSLR least squares updating 
% MMQ_MOMA moment matrix for a diagonal matrix and a vector 
% MMQ_PLSLR polynomial least squares approximation 
% MMQ_PLSLR1 polynomial least squares approximation 
% MMQ_PWV computes the points, weights and values for examples in
% MMQ_REV least squares downdating with the Rev algorithm
% MMQ_REV_EIG least squares downdating using an eigenvector
% MMQ_REV_EIG1 least squares downdating with an eigenvector
% MMQ_RHRUD least squares updating or downdating
% MMQ_RHRUD_D least squares downdating
% MMQ_RHRUD_GIV least squares updating or downdating
% MMQ_RHRUD_GIVF least squares updating or downdating
% MMQ_RHRUD_ROT1 least squares updating 
% MMQ_RHRUD_ROT2D least squares downdating using eigenvectors
% MMQ_RHRUD_ROT3D least squares downdating using eigenvectors
% MMQ_RHRUP recursively computes the ls solution with N points using RHRud
% MMQ_TEIGV computes an eigenvector of the symmetric tridiagonal matrix T
% MMQ_TEST_LSLR_LS test for the function mmq_lslr, least squares
% MMQ_TEST_MOMA test using the moment matrix 
% MMQ_TEST_PLSLR use the Reichel procedure to compute the Jacobi matrix
% MMQ_TEST_REV test for the function mmq_rev
% MMQ_TEST_REV_EGK_V test for the function rev as in Elhay, Golub and Kautsky
% MMQ_TEST_RHRU compute the solution with N points using RHRud
% MMQ_TEST_RHRUD test for the function mmq_rhrud
% MMQ_TEST_RHRUD_d test for the function mmq_rhrud_d
% MMQ_TEST_RHRUD_EGK test for the function mmq_rhrud as in Elhay, Golub and Kautsky
% MMQ_TEST_RHRUD_EGK1 test for the function rhrud as in Elhay, Golub and Kautsky
% MMQ_TEST_RHRUD_EGK_V test for the function mmq_rhrud as in Elhay, Golub and Kautsky
% MMQ_TEST_RHRUD_GIV test for the function rhrud_giv
% MMQ_TEST_RHRUD_GIVF test for the function rhrud_givf
% MMQ_TEST_RHRUD_LS test for the function mmq_rhrud (updating mode), least squares
% MMQ_TEST_RHRUD_ROT2 test for the function mmq_rhrud_rot2
% MMQ_TEST_RHRUD_ROT2_EGK test for the function mmq_rhrud_rot2d as in Elhay, Golub and Kautsky
% MMQ_TEST_RHRUD_ROT2_EGK_V test for the function mmq_rhrud_rot2d as in Elhay, Golub and Kautsky
% MMQ_TEST_RHRUD_ROT3 test for the function mmq_rhrud for updating and mmq_rhrud_rot3d for
% MMQ_TEST_RHRUD_ROT3_EGK_V test for the function mmq_rhrud_rot3d as in Elhay, Golub and Kautsky
% MMQ_TEST_RHRUD_ROT4_EGK_V test for the function mmq_rhrud_rot3 as in Elhay, Golub and Kautsky
% MMQ_TEST_TLDUDSFUS test for the function mmq_tldudsfus
% MMQ_TEST_TLDUDSFUS1 test for the function mmq_tldudsfus1
% MMQ_TEST_TLDUDSFUSU computes the solution by updating
% MMQ_TEST_TLDUDSFUS_EGK test for the function mmq_tldudsfus as in Elhay, Golub and Kautsky
% MMQ_TEST_TLDUDSFUS_LS test for the function mmq_tldudsfus, least squares
% MMQ_TEST_TLDUDUS test for the function tldudus
% MMQ_TEST_TLDUDUSU computes the solution by updating with mmq_tldudus
% MMQ_TEST_TLDUDUS_EGK test for the function tldudus as in Elhay, Golub and Kautsky
% MMQ_TEST_TLDUDUS_LS test for the function tldudus, least squares
% MMQ_TLDUDSFUS least squares updating or downdating
% MMQ_TLDUDUS least squares updating or downdating

