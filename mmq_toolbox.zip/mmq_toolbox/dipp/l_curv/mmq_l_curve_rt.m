function reg_corner=mmq_l_curve_rt(a,y);
%MMQ_L_CURVE_RT locates the corner of the L-curve by RT algoritm
%
% Author G. Meurant
% Jan 2007
%
% compute the SVD

[u,s,v]=svd(a);
size(s)
s=diag(s);
maxs=max(s);
m=size(a,1);

normK=norm(a,'fro');
% useful range for lambda
lambdamax = maxs^2;
lambdamin = (eps * normK);

a=log10(m*lambdamin);
b=log10(m*lambdamax);

n=50;
t=linspace(a,b,n);

k=mmq_rt(t,u,s,v,y);

reg_corner=10^t(k);