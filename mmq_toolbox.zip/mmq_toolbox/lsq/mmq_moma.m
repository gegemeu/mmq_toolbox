function [m,r]=mmq_moma(x,w);
%MMQ_MOMA moment matrix for a diagonal matrix and a vector 
% x vector of the diagonal, vector v = w
%
% Author G. Meurant
% June 2007
%

v=w;
if size(v,1) == 1
 v=v';
end
if size(x,1) == 1
 x=x';
end
k=length(v);
m=zeros(k,k);

% first column
fc=zeros(k,1);
fc(1)=1;
y=x.*v;
for j=1:k-1
 fc(j+1)=v'*y;
 y=x.*y;
end
fc(find(abs(fc) < eps))=0;

% last row
lr=zeros(1,k);
lr(1)=fc(k);
y=x.^k.*v;
for i=1:k-1
 lr(i+1)=v'*y;
 y=x.*y;
end
lr(find(abs(lr) < eps))=0;

m=hankel(fc,lr);

% Cholesky decomposition
[r,p]=chol(m);

if p ~= 0
 disp('MMQ_MOMA: Cholesky factorization, matrix not positive definite')
 p
end


