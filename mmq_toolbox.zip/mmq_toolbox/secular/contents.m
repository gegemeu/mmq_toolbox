%
% Contents of Secular
%
% computation of solutions of secular equations
% and plots of secular functions
%
% MMQ_PLOTSECUL plot figures of a secular equation
% MMQ_PLOTSECUL4 plots figures of the TLS secular equation
% MMQ_PLOTSECUL4 plots figures of the TLS secular equation
% MMQ_PLOTSECUL5 plots figures of the TLS secular equation (other form)
% MMQ_PLOTSECUL5b plots figures of the TLS secular equation (other form)
% MMQ_PLOTSECUL_BNS1 find the zero xf of f
% MMQ_PLOTSECUL_BNS2 find the zero xf of f
% MMQ_PLOTSECUL_FW1 find the zero xf of f
% MMQ_PLOTSECUL_FW2 find the zero xf of f
% MMQ_PLOTSECUL_GR find the zero xf of f
% MMQ_PLOTSECUL_MW find the zero xf of f
% MMQ_PLOTSECUL_NWT find the zero xf of f