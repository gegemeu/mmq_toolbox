function [xo,yo]=mmq_rotat(xi,yi,tet);
%MMQ_ROTAT clowkwise rotation of angle tet
%
% Author G. Meurant
% Jan 2007
%
sx=size(xi);
if sx(1,1) == 1
 xi=xi';
end
sy=size(yi);
if sy(1,1) == 1
 yi=yi';
end

c=cos(tet);
s=sin(tet);
rot=[c s; -s c];
out=rot*[xi';yi'];
xo=out(1,:)';
yo=out(2,:)';
