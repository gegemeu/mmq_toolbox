% 
% Contents of Back_error
%
% computation of estimates of the backward error of least squares solutions
%
% MMQ_BACKLS computes the backward error of a least squares problem
% MMQ_LANCZOS_BK estimate of backward error of a least squares solution
% MMQ_PLOTSECULBK plots figures of the Backward Error secular equation
% MMQ_SOLVE_SECUL_BK solves the Backward Error secular equation