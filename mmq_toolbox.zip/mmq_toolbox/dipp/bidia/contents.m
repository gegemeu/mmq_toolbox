%
% Contents of bidia
%
% MMQ_BIDIAG1A Lanczos bidiagonalization algorithm
% MMQ_L_BIDIAG2 compute the Lanczos bidiagonalization on A' A and a right hand side A'y
% MMQ_L_BIDIAG2_REORT compute the Lanczos bidiagonalization (with reorthogonalization)
% MMQ_L_BIDIAGAAT compute the Lanczos bidiagonalizations on A A' and a right hand side y
% MMQ_L_BIDIAGATA compute the Lanczos bidiagonalization on A' A and a right hand side A'y