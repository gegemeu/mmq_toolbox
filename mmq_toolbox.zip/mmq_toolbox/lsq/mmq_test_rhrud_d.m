function [n,sig,alpha,beta,d]=mmq_test_rhrud_d(N,ix);
%MMQ_TEST_RHRUD_d test for the function mmq_rhrud_d
% other way for downdating
% update from 1 to N and then downdate one point at a time
%
% Author G. Meurant
% May 2007
%

[x,w,y,ier]=mmq_pwv(N,ix);
if ier == 1
 error('MMQ_TEST_RHRUD_D: Unknown problem, abort')
end

% recursively build the solution
sig=abs(w(1));
alpha(1)=x(1);
beta(1)=0;
d(1)=y(1)*sig;
n=1;
sigup=zeros(1,N);
alphaup=zeros(N,N);
betaup=zeros(N,N-1);
dup=zeros(N,N);
sigup(1)=sig;
alphaup(1,1)=alpha(1);
dup(1)=d(1);
nup(1)=1;
n=1;
for i=1:N-1
 % update
 [n,sig,alpha,beta,d]=mmq_rhrud(i,alpha,beta,sig,d,x(i+1),w(i+1),y(i+1),1);
 if n ~= i+1
  disp('rhrud: pb in updating')
  [i n]
 end
 nup(n)=n;
 sigup(n)=sig;
 alphaup(n,:)=[alpha zeros(1,N-i-1)];
 betaup(n,:)=[beta zeros(1,N-i-1)];
 dup(n,:)=[d zeros(1,N-i-1)];
 disp('update rhrud-----------------------')
 n
 ni=n;
 J=spdiags([[beta(1:ni-1)'; 0] alpha(1:ni)' [0; beta(1:ni-1)']], -1:1, ni,ni);
 eigJ=sort(eig(full(J)));
 errJ=abs(x(1:ni)-eigJ)./abs(x(1:ni));
 errJ'
 pause
end
 
format long e

n=N;
for i=N:-1:2
 % downdate using always the same length
 [nout,sig,alpha,beta,d]=mmq_rhrud_d(N,alpha,beta,sig,d,x(n),sqrt(-1)*w(n),y(n));
 disp('downdate rhrud_d-----------------------')
 J=spdiags([[betaup(i-1,1:i-2)'; 0] alphaup(i-1,1:i-1)' [0; betaup(i-1,1:i-2)']], -1:1, i-1,i-1);
 nout
 if nout ~= N
  disp('MMQ_TEST_RHRUD_D: cannot downdate correctly')
  [N nout]
  return
 else
  n=nout;
 end
 ni=n;
 J=spdiags([[beta(1:ni-1)'; 0] alpha(1:ni)' [0; beta(1:ni-1)']], -1:1, ni,ni);
 eigJ=sort(eig(full(J)));
 errJ=abs(x(1:ni)-eigJ)./abs(x(1:ni));
 errJ'
 ii=i-1;
 err_sig=abs(sig-sigup(ii))/sigup(ii);
 err_sigi(ii)=err_sig;
 err_alpha=norm(alpha(1:ii)-alphaup(ii,1:ii))/norm(alphaup(ii,1:ii));
 err_alphai(ii)=err_alpha;
 if i > 2
  if norm(betaup(ii,1:ii-1)) > 0
   err_beta=norm(beta(1:ii-1)-betaup(ii,1:ii-1))/norm(betaup(ii,1:ii-1));
  else
   err_beta=0;
  end
 else
  err_beta=0;
 end
 err_betai(ii)=err_beta;
 err_d=norm(d(1:ii)-dup(ii,1:ii))/norm(dup(ii,1:ii));
 err_di(ii)=err_d;
 disp(' err_sig err_alpha err_beta err_d:')
 [err_sig err_alpha err_beta err_d]
 pause
end % for i

% plot
figure
plot(log10(err_sigi))
hold on
plot(log10(err_alphai),'r')
plot(log10(err_betai),'g')
plot(log10(err_di),'m')
legend('err sig','err alpha','err beta','err d')
title('Rhrud-d: relative errors in downdating')
hold off
