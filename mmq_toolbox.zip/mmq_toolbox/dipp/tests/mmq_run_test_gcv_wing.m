%MMQ_RUN_TEST_GCV_WING run GCV for the Wing problem
%
% Author G. Meurant Dec 2006
%

warning off

% Test problem with a discontinuous solution
% (regutools/wing)

gcase = 12;
m = 64;
n = 64;

noise = 1E-7;
mmq_test_gcv;

pause

noise = 1E-5;
mmq_test_gcv;

pause

noise = 1E-3;
mmq_test_gcv;

pause

noise = 1E-1;
mmq_test_gcv;

pause

noise = 1;
mmq_test_gcv;

warning on