function mmq_plotgcv(gcase,m,n,lambdamin,lambdamax,noise);
%MMQ_PLOTGCV plot the GCV function and its approximation
% from the Golub and von Matt paper
%
% gcase defines the test problem

% Needs Regutools
%
% Author G. Meurant Jan 2007
%

%
% communication among
% mmq_gcv_lanczos, mmq_gcv_l_Bounds, mmq_gcv_l_Lt0, mmq_gcv_l_Lt1,
% mmq_gcv_l_Ut0, mmq_cv_l_Ut1, mmq_test_gcv_Vt
%
global gcv_l_m gcv_l_n gcv_l_normy gcv_l_normK gcv_l_normKTy ...
 gcv_l_u gcv_l_normu ...
gcv_l_gamma_y gcv_l_delta_y gcv_l_gamma_u gcv_l_delta_u;

global test_gcv_case test_gcv_sigma test_gcv_KU test_gcv_u ...
 test_gcv_KV test_gcv_v test_gcv_y;

global gcv_func_min gcv_func_max;

if gcase > 12
 error ('MMQ_PLOTGCV: invalid value of gcase.');
end

lambda = 0;
success = 0;

test_gcv_case=gcase;
gcv_l_m = m;
gcv_l_n = n;
gcv_func_min=0;
gcv_func_max=0;

% initialize Hutchinson's trace estimator
% nu = number of random vectors u
nu = 1;
% initialize Matlab 4 random numbers
rand ('seed', 0);
randn ('seed', 0);
% initialize Matlab 6,... random numbers
%rand('state',0);
%randn('state',0);

gcv_l_u = rand (nu * n, 1);
gcv_l_u = 2 * (gcv_l_u > 0.5) - 1;
gcv_l_u = gcv_l_u / sqrt (nu);
gcv_l_normu = sqrt (n);

% clear all figures
close all

r=min(m,n);

if gcase == 0
 fprintf (1, 'MMQ_PLOTGCV: Test problem with linear singular value distribution.\n');
 
 % generate the singular values 
 aa=(1000*eps-1)/(r-1);
 % linear distribution
 test_gcv_sigma=aa*([1:r]'-1)+1;
 % generate random vectors
 test_gcv_u = usin (m);
 test_gcv_u = (sqrt (2) / norm (test_gcv_u, 2)) * test_gcv_u;
 test_gcv_v = usin (n);
 test_gcv_v = (sqrt (2) / norm (test_gcv_v, 2)) * test_gcv_v;
 normK = max (test_gcv_sigma);
 
 %x0 = randn (n, 1);
 % use the solution of the Shaw problem instead
 %
 x0 = mmq_solshaw (n);
 % matrix vector product using the SVD
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 1
 %c=-0.03;
 c=-20*3/m;
 fprintf (1, 'MMQ_PLOTGCV: Test problem with exponential singular value distribution.\n');
 fprintf (1, '(c = %11.4e)\n', c);
 
 % generate the singular values using c (set in run_test_gcv...)
 test_gcv_sigma = exp (-abs (c) * [1:r]');
 % generate random vectors
 test_gcv_u = randn (m, 1);
 test_gcv_u = (sqrt (2) / norm (test_gcv_u, 2)) * test_gcv_u;
 test_gcv_v = randn (n, 1);
 test_gcv_v = (sqrt (2) / norm (test_gcv_v, 2)) * test_gcv_v;
 normK = max (test_gcv_sigma);
 
 x0 = randn (n, 1);
 % matrix vector product using the SVD
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 2
 fprintf (1, 'MMQ_PLOTGCV: Test problem: Fredholm integral equation of the first kind.\n');
 fprintf (1, '(regutools/baart)\n');
 if m ~= n
  error ('MMQ_PLOTGCV: Baart, must not have m ~= n');
 end
 
 % generate the problem using regutools
 [K, y, x0] = baart (n);
 % compute the SVD
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 3
 fprintf (1, 'MMQ_PLOTGCV: Test problem: computation of the second derivative.\n');
 fprintf (1, '(regutools/deriv2)\n');
 if m ~= n
  error ('m ~= n');
 end
 
 [K, y, x0] = deriv2 (n, 1);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 4
 fprintf (1, 'MMQ_PLOTGCV: Severely ill-posed test problem.\n');
 fprintf (1, '(regutools/foxgood)\n');
 if m ~= n
  error ('MMQ_PLOTGCV: Foxgood, must not have m ~= n');
 end
 
 [K, y, x0] = foxgood (n);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 5
 fprintf (1, 'MMQ_PLOTGCV: Test problem: inverse heat equation.\n');
 fprintf (1, '(regutools/heat)\n');
 if m ~= n
  error ('MMQ_PLOTGCV: Heat, must not have m ~= n');
 end
 
 kappa = 1;
 [K, y, x0] = heat (n, kappa);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 6
 fprintf (1, 'MMQ_PLOTGCV: Test problem: inverse Laplace transformation.\n');
 fprintf (1, '(regutools/ilaplace)\n');
 if m ~= n
  error ('MMQ_PLOTGCV: ILaplace, must not have m ~= n');
 end
 
 example = 1;
 [K, y, x0] = ilaplace (n, example);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 7
 fprintf (1, 'MMQ_PLOTGCV: Stellar parallax problem with 28 fixed, real observations.\n');
 fprintf (1, '(regutools/parallax)\n');
 
 error('MMQ_PLOTGCV: This value of gcase is not supported in this function')
 
 [K, y0] = parallax (n);
 % the exact solution x0 is unknown
 x0 = zeros (n, 1);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 
elseif gcase == 8
 fprintf (1, 'MMQ_PLOTGCV: Phillips''s "famous" test problem.\n');
 fprintf (1, '(regutools/phillips)\n');
 if m ~= n
  error ('MMQ_PLOTGCV: Phillips, must not have m ~= n');
 end
 
 [K, y, x0] = phillips (n);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 9
 fprintf (1, 'MMQ_PLOTGCV: Test problem: one-dimensional image restoration model.\n');
 fprintf (1, '(regutools/shaw)\n');
 if m ~= n
  error ('MMQ_PLOTGCV: Shaw, must not have m ~= n');
 end
 
 [K, y, x0] = shaw (n);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 10
 fprintf (1, 'MMQ_PLOTGCV; Test problem with a "spiky" solution.\n');
 fprintf (1, '(regutools/spikes)\n');
 if m ~= n
  error ('MMQ_PLOTGCV: Spikes, must not havem ~= n');
 end
 
 t_max = 5;
 [K, y, x0] = spikes (n, t_max);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 11
 fprintf (1, 'MMQ_PLOTGCV: Test problem: integral equation with no square integrable solution.\n');
 fprintf (1, '(regutools/ursell)\n');
 if m ~= n
  error ('MMQ_PLOTGCV: Ursell, must not have m ~= n');
 end
 
 [K, y0] = ursell (n);
 % there is no square integrable solution
 x0 = zeros (n, 1);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 
elseif gcase == 12
 fprintf (1, 'MMQ_PLOTGCV: Test problem with a discontinuous solution.\n');
 fprintf (1, '(regutools/wing)\n');
 if m ~= n
  error ('MMQ_PLOTGCV: Wing, must not have m ~= n');
 end
 
 t1 = 1/3;
 t2 = 2/3;
 [K, y, x0] = wing (n, t1, t2);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
else
 error ('MMQ_PLOTGCV: invalid value of gcase');
end

tmp=test_gcv_sigma;
ntmp=length(tmp);
tmp=sort(tmp);
test_gcv_sigma=tmp(ntmp:-1:1);

symb=['-.' '-' '--' ':'];
inoise=1;
minv=realmax;
maxv=0;

nn=noise;
inoise=inoise+1;
switch inoise
 case 1
  str1=num2str(noise);
  symb='-.';
 case 2
  str2=num2str(noise);
  symb='-';
 case 3
  str3=num2str(noise);
  symb='--';
 case 4
  str4=num2str(noise);
  symb=':';
end

% generate the noise and the perturbed right hand side
e = randn (m, 1);
e = (noise / norm (e, 2)) * e;
y = y0 + e;
test_gcv_y = y;

% initialize plots

%find min of the V (G) function
lambdaopt = mmq_gcv_l_GlobalMin ('mmq_test_gcv_V', 0, lambdamax);
% compute the value at min
[vlambdaopt, dvlambdaopt] = mmq_test_gcv_V (lambdaopt);
% find min of the tilde V (G) function
lambdatopt = mmq_gcv_l_GlobalMin ('mmq_test_gcv_Vt', 0, lambdamax);
% compute the value at min
[vtlambdatopt, dvtlambdatopt] = mmq_test_gcv_Vt (lambdatopt);
samples = 300;
c = log (lambdamax / lambdamin) / (samples - 1);
lambdas = zeros (samples, 1);
lambdas (1) = lambdamin;
lambdas (2:samples-1) = lambdamin * exp (c * [1:samples-2]');
lambdas (samples) = lambdamax;
% compute both function at samples points
[vlambdas, dvlambdas] = mmq_test_gcv_V (lambdas);
[vtlambdas, dvtlambdas] = mmq_test_gcv_Vt (lambdas);

% compare  V (lambda)  and  Vt (lambda)
loglog (lambdas, vlambdas, '-', ...
 lambdaopt, vlambdaopt, 'x', ...
 lambdas, vtlambdas, ':', ...
 lambdatopt, vtlambdatopt, 'o');
title (['G (nu),  Gt (nu)']);
hold on;

% compute the svd
s=test_gcv_sigma;

smin=min(s)^2/m;
smax=max(s)^2/m;
minvv=min(vlambdas);
minv=min(minv,minvv);
maxvv=max(vlambdas);
maxv=max(maxv,maxvv);
loglog([smin smin],[0.9*minv 1.1*maxv],':r')
loglog([smax smax],[0.9*minv 1.1*maxv],':r')
% von Matt's bounds
lmin=(eps*normK)^2/m;
lmax=(normK/eps)^2/m;
%loglog([lmin lmin],[0.1*minv 10*maxv],'-.k')
%loglog([lmax lmax],[0.1*minv 10*maxv],'-.k')

ny=norm(y)^2/m;
loglog([lambdamin lambdamax],[ny ny],'--g')
if gcase <= 1
 d = test_gcv_y - test_gcv_u * (test_gcv_u' * test_gcv_y);
else
 d=test_gcv_KU' * test_gcv_y;
end
nm=m*d(r)^2;
if gcase > 1
 loglog([lambdamin lambdamax],[nm nm],'--g')
end
axis([0.1*lambdamin 10*lambdamax 0.5*minv 1.1*maxv])

hold off;
