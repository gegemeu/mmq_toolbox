%MMQ_RUN_TEST_GCV_BLUR run GCV for the Blur problem
%
% Author G. Meurant Dec 2006
%

warning off

% Test problem with a blurred image
% (regutools/blur)

gcase = 13;
m = 5;
n = 5;
noise=1;
mmq_test_gcv;


warning on