function [n,sig,alpha,beta,d]=mmq_test_lslr_ls(N,ix);
%MMQ_TEST_LSLR_LS test for the function mmq_lslr, least squares
% plots the results
%
% Author G. Meurant
% May 2007
%

% generate the data for problem ix
[x,w,y,ier]=mmq_pwv(N,ix);
if ier == 1
 disp('MMQ_TEST_LSLR_LS: Unknown problem, abort')
 return
end

% plot the data
plot(x,y,'b+')
hold on

% sampling points for plotting
xmin=0.9*min(x);
if min(x) < 0
 xmin=1.1*min(x);
end
xmax=1.1*max(x);
nxs=50;
xs=linspace(xmin,xmax,nxs);

% recursively build the least squares solution
sig=w(1);
alpha(1)=x(1);
beta(1)=0;
d(1)=y(1)*sig;
n=1;
for i=1:N-1
 % update
 [n,sig,alpha,beta,d]=mmq_lslr(i,alpha,beta,sig,d,x(i+1),w(i+1),y(i+1));
 if n ~= i+1
  disp('MMQ_TEST_LSLR_LS: pb in updating')
  [i n]
 end
end

% loop on the degree of the polynomial
for i=2:N
 % compute the approximation at sampling points
 for j=1:nxs
  y=zeros(1,N);
  % loop on sampling points
  y(i)=d(i)/beta(i-1);
  if i ~= 2
   y(i-1)=(d(i-1)-(alpha(i-1)-xs(j))*y(i))/beta(i-2);
   for k=i-2:-1:2
    y(k)=(d(k)-(alpha(k)-xs(j))*y(k+1)-beta(k)*y(k+2))/beta(k-1);
   end
   y(1)=d(1)-(alpha(1)-xs(j))*y(2)-beta(1)*y(3);
  else
   y(1)=d(1)-(alpha(1)-xs(j))*y(2);
  end
  q(j)=y(1)/sig;
 end % for j
  
 title(['mmq lslr, Degree = ' num2str(i-1)])
 % the curves are alternatively red and green
 if rem(i,2) == 0
  plot(xs,q,'r')
 else
  plot(xs,q,'g')
 end
 pause
end % for i

hold off



