%MMQ_RUN_TEST_GCV_LARGE run GCV for the large von Matt problem
%
% Author G. Meurant Dec 2006
%

warning off

% Large test problem with exponential singular value distribution

gcase=1;
m = 20000;
n = 10000;
c = -0.003;

noise = 1E0;
mmq_test_gcv;

pause

noise = 1E1;
mmq_test_gcv;

pause

noise = 1E2;
mmq_test_gcv;

pause

warning on