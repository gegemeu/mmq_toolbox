%MMQ_RUN_TEST_L_RIBBON_FOXGOOD run L-ribbon for the Foxgood problem
%
% Author G. Meurant Dec 2006
%

warning off

% Test problem: Fredholm integral equation of the first kind
% (regutools/foxgood)

gcase = 4;
m = 100;
n = 100;

noise = 1E-7;
mmq_test_l_ribbon;

pause

noise = 1E-5;
mmq_test_l_ribbon;

pause

noise = 1E-3;
mmq_test_l_ribbon;

pause

noise = 1E-1;
mmq_test_l_ribbon;

pause

noise = 1E1;
mmq_test_l_ribbon;


warning on