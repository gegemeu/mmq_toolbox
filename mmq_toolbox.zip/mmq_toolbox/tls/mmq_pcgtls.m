function [x,nit]=mmq_pcgtls(K,b,s_tls,epsi,itmax);
%MMQ_PCGTLS solve (K'K-s_tls^2 I)x=K' b using R s.t. K'K=R'R
% the Cholesky factor of K'K
% from A. Bjorck (SIMAX 2000)

% Author G. Meurant
% Oct 2007
%

b=K'*b;
R=chol(K'*K);
n=size(K,2);
x=zeros(n,1);
p=R'\b;
s=p;
eta=norm(s)^2;
s_tls2=s_tls^2;

epss=realmax;
nit=0;

while epss > epsi & nit <= itmax
 nit=nit+1;
 q=R\p;
 del=norm(p)^2-s_tls2*norm(q)^2;
 alpha=eta/del;
 x_old=x;
 x=x+alpha*q;
 epss=norm(x-x_old)/norm(x);
 q=R'\q;
 s=s-alpha*(p-s_tls2*q);
 eta_old=eta;
 eta=norm(s)^2;
 beta=eta/eta_old;
 p=s+beta*p;
end

