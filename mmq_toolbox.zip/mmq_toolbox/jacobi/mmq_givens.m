function [c,s,c2,s2,cs]=mmq_givens(a,b);
%MMQ_GIVENS computes Givens rotation to zero b
% may not be optimal
% from Golub-Van Loan
% The rotation matrix is
%  | c  -s |
%  | s   c |
%
% Author G. Meurant
% June 2007
%

if b == 0
 c=1;
 s=0;
 c2=1;
 s2=0;
 cs=0;
else
 if abs(b) > abs(a)
  t=-a/b;
  t2=t^2;
  s2=1/(1+t2);
  s=sqrt(s2);
  c2=s2*t2;
  c=s*t;
  cs=s2*t;
 else
  t=-b/a;
  t2=t^2;
  c2=1/(1+t2);
  c=sqrt(c2);
  s2=c2*t2;
  s=c*t;
  cs=c2*t;
 end
end
