% 
% Contents of TLS
%
% computation of Total Least Squares parameter and solution
%
% MMQ_GEN_BJORCK1 generates Bjorck's TLS example
% MMQ_GEN_BJORCK2 generates Bjorck's TLS example for large matrices
% MMQ_GEN_TLS generates a TLS example
% MMQ_GEN_TLS_LARGE generates a TLS large example
% MMQ_GEN_TLS_LARGE_K generates a TLS large example
% MMQ_PCGTLS solve (K'K-s_tls^2 I)x=K' b using R s.t. K'K=R'R
% MMQ_SOLVE_DICH_TRID solves the tridiagonal secular equation for the smallest eigenvalue
% MMQ_SOLVE_DICH_TRID1 solves the tridiagonal secular equation for the Gauss estimate
% MMQ_SOLVE_SECUL_RAT solves the tridiagonal secular equation for the Gauss approximation of the TLS parameter
% MMQ_SOLVE_SECUL_TLS solves the Total Least Squares secular equation
% MMQ_SOLVE_SECUL_TLS_GR solves the Total Least Squares secular equation for Gauss-Radau
% MMQ_SOLVE_SECUL_TLS_GR1 solves the Total Least Squares secular equation for Gauss-Radau
% MMQ_SOLVE_SECUL_TRID solves the tridiagonal secular equation for the smallest eigenvalue
% MMQ_SOLVE_TLS compute the TLS solution by bidiagonalization
% MMQ_SOLVE_TLS_USV compute the TLS solution by bidiagonalization
% MMQ_TLS_GK Golub-Kahan bidiagonalization of K
% MMQ_TLS_GK_GR Golub-Kahan bidiagonalization of K
% MMQ_TLS_GK_GR_JK Golub-Kahan bidiagonalization of K for large matrices
% MMQ_TLS_GK_GR_OPT4 Golub-Kahan bidiagonalization of K for large matrices
% MMQ_TLS_GK_GR_OPT5 Golub-Kahan bidiagonalization of K for very large matrices
% MMQ_TLS_GK_GR_USV Golub-Kahan bidiagonalization of K (uu, s, v) for large matrices 
 %MMQ_TLS_GK_GR_USV_JK Golub-Kahan bidiagonalization of K (given by u, s, v) for large matrices
% MMQ_TLS_GK_GR_USV_OPT Golub-Kahan bidiagonalization of K (given by u, s, v) for large matrices
% MMQ_TLS_GK_GR_USV_OPT1 Golub-Kahan bidiagonalization of K (given by u, s, v) for large matrices
% MMQ_TLS_GK_GR_USV_OPT2 Golub-Kahan bidiagonalization of K (given by u, s, v) for large matrices
% MMQ_TLS_GK_GR_USV_OPT3 Golub-Kahan bidiagonalization of K (given by u, s, v) for very large matrices
% MMQ_TLS_GK_GR_USV_OPT6 Golub-Kahan bidiagonalization of K (given by u, s, v) for large matrices

