function [nt,sigt,alphat,betat,dt]=mmq_tldudus(n,alpha,beta,sig,d,x,w,y,ud);
%MMQ_TLDUDUS least squares updating or downdating
% Triangular Lanczos method with determinants, unscaled
% from Elhay, Golub and Kautsky 
%
% ud =1 if updating, -1 if downdating
%
%
% Author G. Meurant
% May 2007
%

if n == 1
 [nt,sigt,alphat,betat,dt]=mmq_rhrud(n,alpha,beta,sig,d,x,w,y,ud);
 return
end

nt=n+1;
q=w/sig;
sw=sig^2+ud*w^2;
p=(x-alpha(1))*q/beta(1);
if sw < 0
 disp('MMQ_TLDUDUS: Pb sw < 0 ------------')
 nt=0;
 alphat=[];
 betat=[];
 dt=[];
 return
end
sigt=sqrt(sw);
t=1+ud*q^2;
nd=size(d,2);
rv=zeros(nd,1);
rv(1)=sqrt(t);
qv=alpha(1)*rv;
d(1)=(d(1)+ud*w*y*q)/sqrt(t);
teta=p*q/t;
alpha(1)=alpha(1)+ud*teta*beta(1);
qv=(alpha(1)*rv-qv)/beta(1);
beta(n)=1;
for i=2:nt-1
 t_new=t+ud*p^2;
 tq=t-ud*q^2;
 tt_new=t_new*(t-ud*q^2);
 if tt_new <= 0
  disp('MMQ_TLDUDUS: tldudus: Pb tt_new <= 0 ---------------')
  i
  [t_new tt_new]
  nt=i-1;
  alphat=alpha(1:nt);
  betat=beta(1:nt-1);
  dt=d(1:nt);
  return
 end % if tt_new
 beta_new=beta(i-1)*sqrt(tt_new)/t;
 rho=sqrt(t_new/t);
 t=t_new;
 r=q;
 q=p;
 p=((x-alpha(i))*q-beta(i-1)*r)/beta(i);
 d(i)=(d(i)+ud*w*y*q-d(1:i-1)*qv(1:i-1))/rho;
 qv(i)=rho;
 vv=qv;
 qv=alpha(i)*qv+beta(i-1)*rv;
 rv=vv;
 alpha(i)=alpha(i)-ud*teta*beta(i-1);
 teta=p*q/t;
 alpha(i)=alpha(i)+ud*teta*beta(i);
 beta(i-1)=beta_new;
 ni=size(qv,1);
 Ji=spdiags([[beta(1:ni-1)'; 0] alpha(1:ni)' [0; beta(1:ni-1)']], -1:1, ni,ni);
 qv=(Ji*rv-qv)/beta(i);
end % for i
pt=abs(p)*(t-q^2);
if ud == 1 & pt <= 0
 disp('MMQ_TLDUDUS: tldudus: pb pt <= 0 -------------')
end
if ud == -1 | pt <= 0
 nt=n-1;
 alphat=alpha(1:nt);
 if nt > 1
  betat=beta(1:nt-1);
 else
  betat=[];
 end
 dt=d(1:nt);
 return
else
 alpha(nt)=x-teta*beta(n);
 beta(n)=beta(n)*abs(p)*sqrt(t-q^2)/t;
 d(nt)=(y*w*p-d(1:nt-1)*qv(1:nt-1))*sqrt(t)/abs(p);

 bb=beta(nt-1);
 alphat=alpha(1:nt);
 if nt > 1
  betat=beta(1:nt-1);
 else
  betat=[];
 end
 dt=d(1:nt);
end

