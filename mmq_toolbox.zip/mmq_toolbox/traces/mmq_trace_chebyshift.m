function [tr,b,a,c]=mmq_trace_chebyshift(n,A,lmin,lmax);
%MMQ_TRACE_CHEBYSHIFT traces of the matrices given by the shifted Chebyshev recurrence
% compute 2n moments
%
% Author G. Meurant
% March 2008
%

m=2*n;
tr=zeros(m,1);

na=size(A,1);
tr(1)=na;

% coefficients of the polynomial recurrence
[b,a,c]=mmq_chebyshift(m,lmin,lmax);

oldc=speye(na);
newc=(A-a(1)*speye(na))/b(1);
tr(2)=trace(newc);

for k=1:m-2
  cc=((A-a(k+1)*speye(na))*newc-c(k)*oldc)/b(k+1);
  oldc=newc;
  newc=cc;
  tr(k+2)=trace(cc);
end
