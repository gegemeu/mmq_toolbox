function y=mmq_pmatat(u,s,v,x);
%MMQ_PMATA matrix vector product y = a' x when the matrix
% is defined by  u, s, v (vectors)
% (I-u u') s (I- v v')
%
% Author G. Meurant
% Feb 2007
%

m=length(u);
n=length(v);
r=min(m,n);

x = x - u * (u' * x);
y = zeros (n, 1);
y (1:r) = s .* x (1:r);
y = y - v * (v' * y);