function [K,b]=mmq_gen_tls_large_K(m,n,noise);
%MMQ_GEN_TLS_LARGE_K generates a TLS large example
% K is the matrix and b the right hand side
%
% Author G. Meurant
% Aug 2007
%

% reset random number generators
% the choice affects the noise which is added

% Matlab 4 random number generator
%rand ('seed', 0);
randn ('seed', 0);
% Matlab 6,... random number generator
%rand('state',0);
%randn('state',0);

if m < n
 error('MMQ_GEN_TLS_LARGE_K: m must be >= n')
end

gen=1;

if gen == 1
r=n;

% generate the singular values  
si=[1:n];
si=sqrt(si);
sigma = si';

elseif gen == 2
r=n;

% choice of c
c=-0.3;
% generate the singular values using c 
sigma = exp (-abs (c) * [1:r]');

end

s=sigma;

% generate random vectors for u and v
u = randn (m, 1);
u = (sqrt (2) / norm (u, 2)) * u;
v = randn (n, 1);
v = (sqrt (2) / norm (v, 2)) * v;
normK = max (sigma);

x=1./[1:n]';

%b=K*x;
b=mmq_pmata(u,s,v,x);

% add noise to the right hand side
%b=mmq_noisy(b,noise);
b=b+noise*randn(m,1);

% perturb the singular values
perts=1;
if perts == 1
  s=s+noise*randn(n,1);
  ind=find(s <= 0);
  s(ind)=1e-2*abs(randn(length(ind),1));
end

s=spdiags(s,0,m,n);

K=(speye(m)-u*u')*s*(speye(n)-v*v');