function [aa,l]=mmq_strakos(n,a,b,rho);
%MMQ_STRAKOS generates the diagonal Strakos matrix
% with eigenvalues 
% l_i=a+((i-1)/(n-1))*(b-a)*rho^(n-i)
% l_1=a, l_n=b
%  
% Author G. Meurant
%

l(1)=a;
l(n)=b;
for i=2:n-1
 l(i)=a+((i-1)/(n-1))*(b-a)*rho^(n-i);
end
aa=spdiags(l',0,n,n);

