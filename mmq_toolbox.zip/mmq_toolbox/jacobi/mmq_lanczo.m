function [q,t,vts,dts,rvec,nv,w]=mmq_lanczo(a,b,x0,kmax);
%MMQ_LANCZO lanczos iteration for a matrix a 
% kmax iterations starting from u=b-a x0 normalized
%
% q = lanczos vectors, t = tridiagonal matrix
% vts = sorted eigenvectors of t
% dts = sorted eigenvalues of t
% rvec = Ritz vectors
% nv = norm of the Lanczos vectors before normalization
% w = new vector before normalization
%
% coded as suggested by Paige
%
% Author G. Meurant
% October 2002
%  

n=size(a,1);
j=kmax;
u=b-a*x0;

% scaling of u
sutu=norm(u);
nv(1)=sutu;
v=u/sutu;

t=sparse(kmax,kmax);
q=zeros(n,j);
w=q;
q(:,1)=v;
w(:,1)=u;
u=a*v;
om=v'*u;
t(1,1)=om;
r=u-om*v;
gam2=r'*r;
gam=norm(r);
nv(2)=gam;
v1=v;
v=r/gam;
q(:,2)=v;
w(:,2)=r;

if kmax > 1
 for k=2:kmax
  t(k,k-1)=gam;
  t(k-1,k)=gam;
  u=a*v-gam*v1;
  om=v'*u;
  t(k,k)=om;
  r=u-om*v;
  if k < kmax
   w(:,k+1)=r;
  end
  gam2=r'*r;
  gam=norm(r);
  nv(k+1)=gam;
  if gam == 0
   break
  end
  v1=v;
  v=r/gam;
  if k <kmax
   q(:,k+1)=v;
  end % if
 end % end for
end % if kmax 

% eigenvalues and eigenvectors of T
[vt,dt]=eig(full(t(1:kmax,1:kmax)));
% sort the eigenvalues
%[dts,ii]=sort(dt);
[dts,ii]=sort(diag(dt));
% and the eigenvectors
vts=vt(:,ii);
% approx of eigenvectors
rvec=q(:,1:kmax)*vts;
t=t(1:kmax,1:kmax);
