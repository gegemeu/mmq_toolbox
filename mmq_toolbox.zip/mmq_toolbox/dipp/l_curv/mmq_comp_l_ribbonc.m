function gr=mmq_comp_l_ribbonc(mu,u,s,v);
%MMQ_COMP_L_RIBBONC computes the function for the curvature of the L-curve
% computed by using the SVD
%
% Author G. Meurant
% Feb 2007
%

m=size(u,1);
n=size(v,1);

d=u'*eye(m,1);

for i = 1:length(mu)
 
 mmu = mu(i);
 
 % compute (e_1)^T(C C^T + mu I)^(-3) e_1 using the singular values
 
 t = s.^2 + mmu;
 num=  sum (d(1:n).^2 ./ t.^3)+sum(d(n+1:m).^2/mmu^3);
 
 gr(i)=num;
 
end
