function mmq_test_trace_est (m, n, c, noise);
%MMQ_TEST_TRACE_EST test for the trace estimator
%
% Author Urs von Matt
%

global test_gcv_case test_gcv_sigma test_gcv_KU test_gcv_u ...
 test_gcv_KV test_gcv_v test_gcv_y;

global gcv_l_m gcv_l_n gcv_l_normy gcv_l_normK gcv_l_normKTy ...
 gcv_l_u gcv_l_normu ...
gcv_l_gamma_y gcv_l_delta_y gcv_l_gamma_u gcv_l_delta_u;

% reset random number generator
rand ('seed', 0);
randn ('seed', 0);

% define test problem

% large test problem with exponential singular value distribution.
test_gcv_case = 1;
r = min (m, n);
test_gcv_sigma = exp (-abs (c) * [1:r]');
test_gcv_u = randn (m, 1);
test_gcv_u = (sqrt (2) / norm (test_gcv_u, 2)) * test_gcv_u;
test_gcv_v = randn (n, 1);
test_gcv_v = (sqrt (2) / norm (test_gcv_v, 2)) * test_gcv_v;
normK = test_gcv_sigma (1);
x = randn (n, 1);
y0 = mmq_test_gcv_Kprod ('N', m, n, x);
e = randn (m, 1);
e = (noise / norm (e, 2)) * e;
y = y0 + e;
test_gcv_y = y;

% print parameters of test problem
fprintf (1, '\n\nMMQ_TEST_TRACE_EST\n--------------\n\n');
fprintf (1, 'm          = %5i\n', m);
fprintf (1, 'n          = %5i\n', n);
fprintf (1, 'c          = %11.4e\n', c);
fprintf (1, 'sigma (1)  = %11.4e    sigma (%i) = %11.4e\n', ...
 test_gcv_sigma (1), r, test_gcv_sigma (r));
fprintf (1, 'cond (K)   = %11.4e\n', ...
 test_gcv_sigma (1) / test_gcv_sigma (r));
fprintf (1, 'noise      = %11.4e\n', noise);

% compute minimizer of V (lambda)
lambdamax = normK^2 / (m * eps);
lambdaopt = mmq_gcv_l_GlobalMin ('mmq_test_gcv_V', 0, lambdamax);
[vlambdaopt, dvlambdaopt] = mmq_test_gcv_V (lambdaopt);
fprintf (1, 'lambdaopt  = %11.4e\n', lambdaopt);

% plot V (lambda)
lambdamin = eps^2 * normK^2 / m;
samples = 100;
factor = log (lambdamax / lambdamin) / (samples - 1);
lambdas = zeros (samples, 1);
lambdas (1) = lambdamin;
lambdas (2:samples-1) = lambdamin * exp (factor * [1:samples-2]');
lambdas (samples) = lambdamax;
[vlambdas, dvlambdas] = mmq_test_gcv_V (lambdas);
loglog (lambdas, vlambdas, '-', ...
 lambdaopt, vlambdaopt, 'x');
title (['V (lambda),  lambdaopt = ' num2str(lambdaopt)]);
drawnow;

% nu = number of random vectors u
for nu = 4.^[0:3]
 fprintf (1, '\nnu = %i\n', nu);
 
 % run N experiments
 N = 100;
 fprintf (1, 'running %i tests: ', N);
 sx = 0;
 sx2 = 0;
 for i = 1:N
  % initialize Hutchinson's trace estimator
  gcv_l_u = rand (nu * n, 1);
  gcv_l_u = 2 * (gcv_l_u > 0.5) - 1;
  gcv_l_u = gcv_l_u / sqrt (nu);
  gcv_l_normu = sqrt (n);
  
  % compute minimizer of Vt (lambda)
  lambdatopt = mmq_gcv_l_GlobalMin ('mmq_test_gcv_Vt', 0, lambdamax);
  x = abs (lambdatopt - lambdaopt) / lambdaopt;
  sx = sx + x;
  sx2 = sx2 + x^2;
  fprintf (1, '.');
 end
 fprintf (1, '\n');
 
 % print results
 fprintf (1, 'X = abs (lambdatopt - lambdaopt) / lambdaopt\n');
 fprintf (1, 'E [X] = %11.4e\n', sx / N);
 fprintf (1, 'sqrt (Var [X]) = %11.4e\n', sqrt (sx2/N - (sx/N)^2));
end



