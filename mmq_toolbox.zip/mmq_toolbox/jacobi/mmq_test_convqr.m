function [alpha,beta]=mmq_test_convqr(N,ix);
%MMQ_TEST_CONVQR implements the Laurie's procedure Convqr
% for  the discrete scalar product
% defined by nodes x_k and weights w_k^2

%
% Author G. Meurant
% June 2007
%

[x,w,y,ier,mu0]=mmq_pwv(N,ix);

% computation of the nodes and weights and solution
[alpha,beta]=mmq_convqr(x,w.^2);


