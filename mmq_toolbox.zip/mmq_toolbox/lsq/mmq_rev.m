function [nt,sigt,alphat,betat,dt]=mmq_rev(n,alpha,beta,sig,d,x,w,y);
%MMQ_REV least squares downdating with the Rev algorithm
% from Elhay, Golub and Kautsky with some corrections
%
% Author G. Meurant
% April 2007
%
 
if length(x) ~= 1 | length(w) ~= 1 | length(y) ~= 1
 error('MMQ_REV: must remove one point at a time')
end

nt=n;
u_old=0;
u=w/sig;
u_new=(x-alpha(1))*u/beta(1);

sw=sig^2-w^2;
if sw <= eps
 disp('MMQ_REV: sig^2-w^2 < eps')
 nt=0;
 sigt=0;
 alphat=[];
 betat=[];
 dt=[];
 return
end

sigt=sqrt(sw);
m=1-u^2;
mu=m-u_new^2;
if mu >= eps
 m=mu;
 mu_old=1;
 
 for j=2:nt-1
  u_old=u;
  u=u_new;
  if abs(beta(j)) > 0
   u_new=((x-alpha(j))*u-beta(j-1)*u_old)/beta(j);
  else
   error('MMQ_REV: pb beta(j) = 0')
  end % if abs
  mu=m-u_new^2;
  if mu > eps
   m=mu;
  else
   mu_old=mu;
   disp('MMQ_REV: mu < eps in loop')
   j
   nt=j;
   break
  end % if mu
 end % for j
 if mu_old > eps
  u_old=u;
  u=u_new;
 end %  if mu_old
else % if mu
 disp('-------------------')
 disp('MMQ_REV: pb mu < eps for step')
 nt
 mu
 nt=1;
 %alphat=alpha(1);
 %betat=[];
 %dt=d(1);
 %return
end %  if mu
u_new=sqrt(m);
if nt > 1
 beta(nt)=((x-alpha(nt))*u-beta(nt-1)*u_old)/u_new;
else
 beta(nt)=((x-alpha(nt))*u)/u_new;
end
alpha(nt+1)=x-beta(nt)*u/u_new;
rnormsq=u_new^2+u^2;
uu=sqrt(rnormsq);
c=u_new/uu;
s=-u/uu;
c2=u_new^2/rnormsq;
s2=u^2/rnormsq;
cs=-(u_new*u)/rnormsq;
q=zeros(1,nt);
atmp=alpha(nt+1);
if nt > 1
 p=-s*beta(nt-1);
end
r=cs*(atmp-alpha(nt))+(c2-s2)*beta(nt);
alpha(nt+1)=c2*atmp+s2*alpha(nt)-2*cs*beta(nt);
alpha(nt)=c2*alpha(nt)+2*cs*beta(nt)+s2*atmp;
if nt > 1
 beta(nt-1)=c*beta(nt-1);
end
beta(nt)=0;
d(nt+1)=-s*d(nt);
d(nt)=c*d(nt);
q(nt)=s;
q(nt+1)=c;
for j=nt-1:-1:1
 s=r;
 c=beta(j);
 s2=s^2;
 c2=c^2;
 rnormsq=c2+s2;
 br=sqrt(rnormsq);
 s2=s2/rnormsq;
 c2=c2/rnormsq;
 cs=(c*s)/rnormsq;
 s=s/br;
 c=c/br;
 atmp=alpha(nt+1);
 alpha(nt+1)=c2*atmp+s2*alpha(j)-2*cs*p;
 beta(j)=c*beta(j)+s*r;
 r=c*s*(atmp-alpha(j))+(c^2-s^2)*p;
 alpha(j)=c2*alpha(j)+2*cs*p+s2*atmp;
 if j > 1
  p=-s*beta(j-1);
  beta(j-1)=c*beta(j-1);
 end
 dtmp=c*d(j)+s*d(nt+1);
 d(nt+1)=-s*d(j)+c*d(nt+1);
 d(j)=dtmp;
 qtmp=c*q(j)+s*q(nt+1);
 q(nt+1)=-s*q(j)+c*q(nt+1);
 q(j)=qtmp;
end
fac=(w*y-d(nt+1))/q(nt+1);
for i=1:nt
 d(i)=d(i)+fac*q(i);
end
nt=n-1;
alphat=alpha(1:nt);
if nt > 1
 betat=beta(1:nt-1);
else 
 betat=[];
end
dt=d(1:nt);