function [nt,sigt,alphat,betat,dt]=mmq_rhrud_d(n,alpha,beta,sig,d,x,w,y);
%MMQ_RHRUD_D least squares downdating
% from Elhay, Golub and Kautsky with some corrections
% use always the same length and complex arithmetic
% w is imaginary
%
%
% Author G. Meurant
% May 2007
%

if length(x) ~= 1 | length(w) ~= 1 | length(y) ~= 1
 error('MMQ_RHRUD_D: must add one point at a time')
end

 ni=n;
 J=spdiags([[beta(1:ni-1)'; 0] alpha(1:ni)' [0; beta(1:ni-1)']], -1:1, ni,ni);
 %full(real(J))
 %pause

nt=n+1;
sw=sig^2+w^2;
if sw <= 0
 disp('MMQ_RHRUD_D: pb sig^2+ud*w^2 <= 0')
end
sigt=sqrt(sw);
% rotation between the first and last line to obtain 
% R_1 (sig 0 ... 0 w)^T = (sig_tilde 0 ... 0)^T
c=sig/sigt;
s=w/sigt;
s=sqrt(1-c^2);
cs=[c s c^2+s^2 c^2-s^2 (abs(c)+abs(s))/(abs(c)-abs(s))]
sig=sigt;
teta1=c*s*(x-alpha(1));
alpha(nt)=c^2*x+s^2*alpha(1);
alpha(1)=c^2*alpha(1)+s^2*x;
if n > 1
 teta2=-s*beta(1);
 beta(1)=c*beta(1);
end
d(nt)=c*w*y-s*d(1);
d(1)=c*d(1)+s*w*y;

for i=2:nt-1
 bt=beta(i-1)^2+teta1^2;
 if bt <= 0
  disp('MMQ_RHRUD_D: pb beta(i-1)^2+teta1^2 <= 0')
  disp('       n i nt beta(i-1)^2+teta1^2')
  [n i nt bt]
 end % if bt
 xi=sqrt(bt);
  %xii=xi
 % rotation to annihilate teta_1 in the last line
 c=beta(i-1)/xi;
 s=teta1/xi;
 s=sqrt(1-c^2);
  cs=[c s c^2+s^2 c^2-s^2 (abs(c)+abs(s))/(abs(c)-abs(s))]
 beta(i-1)=xi;
 t=c^2*alpha(i)+2*c*s*teta2+s^2*alpha(nt);
 r=c^2*alpha(nt)-2*c*s*teta2+s^2*alpha(i);
 teta1=c*s*(alpha(nt)-alpha(i))+teta2*(c^2-s^2);
 alpha(i)=t;
 alpha(nt)=r;
 if i ~= nt-1 
  teta2=-s*beta(i);
  old_bet=beta(i);
  beta(i)=c*beta(i);
 end % if i
 t=d(i);
 d(i)=c*t+s*d(nt);
 d(nt)=c*d(nt)-s*t;
end % for i
if teta1 == 0
 disp('MMQ_RHRUD_D: teta1 = 0')
end
 beta(nt-1)=abs(teta1);
 ni=nt;
 nt=n;

alphat=alpha(1:nt);
if nt > 1
 betat=beta(1:nt-1);
else
 betat=[];
end
dt=d(1:nt);

