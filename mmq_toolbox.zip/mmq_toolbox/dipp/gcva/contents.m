%
% Contents of GCVA
%
% MMQ_GCV Plot the GCV function and find its minimum
% MMQ_GCV_LANCZOS find the GCV reg param by Lanczos bidiagonalization
% MMQ_GCV_LANCZOS_M find the GCV reg param mu by Lanczos bidiagonalization
% MMQ_GCV_LANCZOS_M_LOG find the GCV reg param mu by Lanczos bidiagonalization
% MMQ_GCV_LANCZOS_M_LOG6 find the GCV reg param mu by Lanczos bidiagonalization
% MMQ_GCV_LANCZOS_M_LOG6_G Find the GCV reg param mu by Lanczos bidiagonalization
% MMQ_GCV_LANCZOS_M_LOG6_G_REORT find the GCV reg param mu by Lanczos bidiagonalization
% MMQ_GCV_LANCZOS_REORT Find the GCV reg param by Lanczos bidiagonalization with reorthogonalization
% MMQ_GCV_L_GLOBALMAX locates the maximum of the function f
% MMQ_GCV_L_GLOBALMAX_L locates the maximum of the function f
% MMQ_GCV_L_GLOBALMAX_LM locates the maximum of the function f
% MMQ_GCV_L_GLOBALMIN locates the minimum of the function f
% MMQ_GCV_L_GLOBALMIN_L locates the minimum of the function f
% MMQ_GCV_L_GLOBALMIN_LM locates the minimum of the function f
% MMQ_GCV_L_GLOBALMIN_M locates the minimum of the function f
% MMQ_GCV_L_LOCALMAX locates the local maximum of f
% MMQ_GCV_L_LOCALMIN locates a local minimum of f
% MMQ_GCV_L_LT0 computes the lower bound of the GCV function
% MMQ_GCV_L_LT0_L computes the lower bound of the GCV function
% MMQ_GCV_L_UT0 computes the upper bound of the GCV function
% MMQ_GCV_L_UT0ND computes the upper bound of the GCV function
% MMQ_GCV_L_UT0_L computes the upper bound of the GCV function
% MMQ_GCV_L_UT0_L_BY computes the upper bound of the GCV function
% MMQ_GCV_L_UT0_L_BYY computes the upper bound of the GCV function
% MMQ_GCV_L_UT0_MEQN computes the upper bound of the GCV function when m=n
% MMQ_PLOTGCV plot the GCV function and its approximation
% MMQ_PMATA matrix vector product y = a x when the matrix
% MMQ_PMATA matrix vector product y = a' x when the matrix
% MMQ_TEST_GCV_KPROD Matrix vector product for test_gcv
% MMQ_TEST_GCV_V computes the GCV function and its derivative
% MMQ_TEST_GCV_VT computes the approximation of the GCV function and its derivative