function [b,a,c]=mmq_chebyshift(n,lmin,lmax);
%MMQ_CHEBYSHIFT coefficients of the shifted Chebyshev polynomials
% b C_(k+1) = (x - a) C_k - c C_(k-1)
%
% [lmin, lmax] is the interval mapped to  [-1, 1]
%
% Author G. Meurant
% March 2008
%

a=zeros(n,1);
b=zeros(n-1,1);
c=b;

a(:,1)=(lmax+lmin)/2;
c(:,1)=(lmax-lmin)/4;
b=c;
b(1)=(lmax-lmin)/2;

