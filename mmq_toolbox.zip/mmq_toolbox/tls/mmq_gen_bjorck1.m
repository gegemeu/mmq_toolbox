function [K,b]=mmq_gen_bjorck1(m,n,noise);
%MMQ_GEN_BJORCK1 generates Bjorck's TLS example
%
% Author G. Meurant
% Aug 2007
%

% reset random number generators
% the choice affects the noise which is added

% Matlab 4 random number generator
%rand ('seed', 0);
randn ('seed', 0);
% Matlab 6,... random number generator
%rand('state',0);
%randn('state',0);

if m < n
 error('MMQ_GEN_BJORCK1: m must be >= n')
end

r=n;

% generate the singular values  
si=[0:n-1];
si=pow2(si);
sigma = (1./si)';

s=spdiags(sigma,0,m,n);

% generate random vectors
u = randn (m, 1);
u = (sqrt (2) / norm (u, 2)) * u;
v = randn (n, 1);
v = (sqrt (2) / norm (v, 2)) * v;
normK = max (sigma);

K=(speye(m)-u*u')*s*(speye(n)-v*v');

%x = randn (n, 1);
x=1./[1:n]';

%b=K*x;
tmp=s*(x-v*(v'*x));
b=tmp-u*(u'*tmp);

% add noise to the right hand side
%b=mmq_noisy(b,noise);
rand('state',0);
b=b+noise*randn(m,1);

% add noise to the matrix
K=K+noise*randn(m,n);

