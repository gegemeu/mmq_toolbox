function [bg,bgrl,bgru,bgl]=mmq_bounds_gaussb(a,d,c,kmax,lmin,lmax);
%MMQ_BOUNDS_GAUSSB computation of a lower bound of a bilinear form with the inverse of a
% symmetric matrix a with block Lanczos
%
% kmax iterations
% lmin and lmax are the lower and upper bounds for the smallest and largest eigenvalues
%
% it is not very efficient to compute the square root of the block tridiagonal matrix
%
%  bg :         Gauss
%  bgrl, bgru : Gauss-Radau
%  bgl :        Gauss-Lobatto
%
% Author G. Meurant
% March 2008
%
bg=zeros(kmax,1);
bgrl=zeros(kmax,1);
bgru=zeros(kmax,1);
bgl=zeros(kmax,1);

rand('state',0);
n=size(a,1);
jj=sparse(2*kmax,2*kmax);
x1=zeros(n,2);
nd=norm(d);

% d and c must be orthonormal
% orthogonalization
cdnd=(c'*d)/nd^2;
cd=c-cdnd*d;
ncd=norm(cd);
if ncd < eps
 error('MMQ_BOUNDS_GAUSSB: cannot orthogonalize d and c')
end
x=[d/nd cd/ncd];

gam=zeros(2,2);
om=x'*a*x;
jj(1:2,1:2)=om;
invjj=inv(om);
delta=invjj(1,1);
gamma=invjj(1,2);
bg(1)=cdnd*delta*nd^2+gamma*ncd*nd;

% block Lanczos iterations
if kmax > 1
 for k=2:kmax
  r=a*x-x*om-x1*gam';
  x1=x;
  [xa,gama]=qr(r);
  x=[xa(:,1) xa(:,2)];
  gam=gama(1:2,1:2);
  dgam=det(gam);
  if abs(dgam) < 1.e-6
   nr=sqrt(r(:,1)'*r(:,1));
   if nr == 0
    error('MMQ_BOUNDS_GAUSSB: breakdown')
   end
   r1= r(:,1)/nr;
   y=[x1 r1];
   z=(eye(n)-y*y')*rand(n,1);
   x=[r1 z/sqrt(z'*z)];
  end % if abs
  om=x'*a*x;
  jj(2*k-1:2*k,2*k-1:2*k)=om;
  jj(2*k-1:2*k,2*k-3:2*k-2)=gam;
  jj(2*k-3:2*k-2,2*k-1:2*k)=gam';
  
  % Gauss
  invjj=inv(jj(1:2*k,1:2*k));
  delta=invjj(1,1);
  gamma=invjj(1,2);
  bg(k)=cdnd*delta*nd^2+gamma*ncd*nd;
  
  % Gauss-Radau
  r=a*x-x*om-x1*gam';
  [xa,gama]=qr(r);
  gamm=gama(1:2,1:2);
  b=zeros(2*k,2);
  b(2*k-1:2*k,1:2)=gamm';
  dmax=(jj(1:2*k,1:2*k)-lmin*eye(2*k))\b;
  omm=lmin*eye(2)+dmax(2*k-1:2*k,1:2)'*gamm';
  del=zeros(2,2*k);
  del(1:2,2*k-1:2*k)=gamm;
  jt=zeros(2*k+2,2*k+2);
  jt=[jj(1:2*k,1:2*k) del';del omm];
  invjj=inv(jt);
  delta=invjj(1,1);
  gamma=invjj(1,2);
  bgru(k)=cdnd*delta*nd^2+gamma*ncd*nd;
  
  dmin=(jj(1:2*k,1:2*k)-lmax*eye(2*k))\b;
  omm=lmax*eye(2)+dmin(2*k-1:2*k,1:2)'*gamm';
  jt=[jj(1:2*k,1:2*k) del';del omm];
  invjj=inv(jt);
  delta=invjj(1,1);
  gamma=invjj(1,2);
  bgrl(k)=cdnd*delta*nd^2+gamma*ncd*nd;
  
  % Gauss-Lobatto
  b=zeros(2*k,2);
  i2=eye(2);
  b(2*k-1:2*k,1:2)=i2;
  dmax=(jj(1:2*k,1:2*k)-lmin*eye(2*k))\b;
  dn=dmax(2*k-1:2*k,1:2)';
  dmin=(jj(1:2*k,1:2*k)-lmax*eye(2*k))\b;
  mn=dmin(2*k-1:2*k,1:2)';
  y=(lmax-lmin)*inv(dn-mn);
  vpy=eig(y);
  if min(vpy) > 0
   gamm=chol(y);
  else
   gamm=0;
  end
  omm=lmin*i2+gamm*dn*gamm';
  if min(vpy) <= 0
   omm=i2;
  end
  del=zeros(2,2*k);
  del(1:2,2*k-1:2*k)=gamm;
  jt=zeros(2*k+2,2*k+2);
  jt=[jj(1:2*k,1:2*k) del';del omm];
  invjj=inv(jt);
  delta=invjj(1,1);
  gamma=invjj(1,2);
  bgl(k)=cdnd*delta*nd^2+gamma*ncd*nd;
  
 end % for k
end % if kmax

