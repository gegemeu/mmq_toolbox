%MMQ_RUN_TEST_GCV_SHAW_LARGE run GCV for the Shaw problem
%
% Author G. Meurant Dec 2006
%

warning off

% Test problem: one-dimensional image restoration model
% (regutools/shaw)

gcase = 9;
m = 400;
n = 400;


noise = 1E-5;
mmq_test_gcv;

pause

noise = 1E-3;
mmq_test_gcv;

pause

noise = 1E-1;
mmq_test_gcv;

pause

noise = 1E1;
mmq_test_gcv;


warning on