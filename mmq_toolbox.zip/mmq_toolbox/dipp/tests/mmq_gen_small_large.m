function [K,b,x,normK]=mmq_gen_small_large(m,n,c,noise);
%MMQ_GEN_SMALL_LARGE generates a test matrix for GCV
%
% Author G. Meurant
% Dec 2006
%

% reset random number generators
% the choice affects the noise which is added
% to reproduce the results of the Golub and von Matt paper
% choose the Matlab 4 generator

% Matlab 4 random number generator
%rand ('seed', 0);
% Matlab 6,... random number generator
%rand('state',0);
randn ('seed', 0);
%randn('state',0);

if m < n
 error('MMQ_GEN_SMALL_LARGE: m must be >= n')
end

r=n;

% generate the singular values using c 
sigma = exp (-abs (c) * [1:r]');

s=spdiags(sigma,0,m,n);

% generate random vectors
u = randn (m, 1);
u = (sqrt (2) / norm (u, 2)) * u;
v = randn (n, 1);
v = (sqrt (2) / norm (v, 2)) * v;
normK = max (sigma);

K=(speye(m)-u*u')*s*(speye(n)-v*v');

x = randn (n, 1);

%b=K*x;
tmp=s*(x-v*(v'*x));
b=tmp-u*(u'*tmp);

b=mmq_noisy(b,noise);

