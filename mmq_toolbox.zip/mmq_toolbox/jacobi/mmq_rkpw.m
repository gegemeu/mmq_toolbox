function [alpha,beta]=mmq_rkpw(N,ix);
%MMQ_RKPW implements the Kahan Pal Walker procedure 
% as coded by W. Gautschi
% for monic orthogonal polynomials and the discrete scalar
% product defined by nodes x_k and weights w_k^2

% uses the mmq_lanczosopq function from OPQ of W. Gautschi
% and mmq_pwv from ls

%
% Author G. Meurant
% June 2007
%

% computation of the nodes and weights
[x,w,y,ier]=mmq_pwv(N,ix);
if ier == 1
 error('MMQ_RKPW: Unknown problem, abort')
end

ab=mmq_lanczosopq(N,[x w.^2]);

alpha=ab(:,1)';
beta=sqrt(ab(2:N,2)');


