function y = mmq_test_gcv_Kprod (trans, m, n, x);
%MMQ_TEST_GCV_KPROD Matrix vector product for test_gcv
%
% Author Urs von Matt
%
% The call
%
%     y = mmq_test_gcv_Kprod ('N', m, n, x)
%
% evaluates the matrix-vector product
%
%     y = K * x.
%
% Similarly, the statement
%
%     y = mmq_test_gcv_Kprod ('T', m, n, x)
%
% evaluates the matrix-vector product
%
%     y = K' * x.
%
% the product is computed using the SVD (sigma, KU, KV)

%
% communication among
% mmq_test_gcv, mmq_test_gcv_Kprod, mmq_test_gcv_V, mmq_test_gcv_Vt
%
global test_gcv_case test_gcv_sigma test_gcv_KU test_gcv_u ...
 test_gcv_KV test_gcv_v test_gcv_y;

if test_gcv_case <= 1
 % sparse test matrix
 if m ~= length (test_gcv_u)
  error ('MMQ_TEST_GCV_KPROD: inconsistent value of m');
 end
 if n ~= length (test_gcv_v)
  error ('MMQ_TEST_GCV_KPROD: inconsistent value of n');
 end
 r = min (m, n);
 
 if strcmp (trans, 'N')
  [m_x, n_x] = size (x);
  if (m_x ~= n) | (n_x ~= 1)
   error ('MMQ_TEST_GCV_KPROD: x is not an nx1-vector');
  end
  x = x - test_gcv_v * (test_gcv_v' * x);
  y = zeros (m, 1);
  y (1:r) = test_gcv_sigma .* x (1:r);
  y = y - test_gcv_u * (test_gcv_u' * y);
 elseif strcmp (trans, 'T')
  [m_x, n_x] = size (x);
  if (m_x ~= m) | (n_x ~= 1)
   error ('MMQ_TEST_GCV_KPROD: x is not an mx1-vector');
  end
  x = x - test_gcv_u * (test_gcv_u' * x);
  y = zeros (n, 1);
  y (1:r) = test_gcv_sigma .* x (1:r);
  y = y - test_gcv_v * (test_gcv_v' * y);
 else
  error ('MMQ_TEST_GCV_KPROD: invalid value of trans');
 end
 
else
 % full test matrix
 if m ~= length (test_gcv_KU)
  error ('MMQ_TEST_GCV_KPROD: inconsistent value of m');
 end
 if n ~= length (test_gcv_KV)
  error ('MMQ_TEST_GCV_KPROD: inconsistent value of n');
 end
 r = min (m, n);
 
 if strcmp (trans, 'N')
  [m_x, n_x] = size (x);
  if (m_x ~= n) | (n_x ~= 1)
   error ('MMQ_TEST_GCV_KPROD: x is not an nx1-vector');
  end
  x = test_gcv_KV' * x;
  y = zeros (m, 1);
  y (1:r) = test_gcv_sigma .* x (1:r);
  y = test_gcv_KU * y;
 elseif strcmp (trans, 'T')
  [m_x, n_x] = size (x);
  if (m_x ~= m) | (n_x ~= 1)
   error ('MMQ_TEST_GCV_KPROD: x is not an mx1-vector');
  end
  x = test_gcv_KU' * x;
  y = zeros (n, 1);
  y (1:r) = test_gcv_sigma .* x (1:r);
  y = test_gcv_KV * y;
 else
  error ('MMQ_TEST_GCV_KPROD: invalid value of trans');
 end
 
end
