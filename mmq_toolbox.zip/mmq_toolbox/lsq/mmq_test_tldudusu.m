function [n,sig,alpha,beta,d]=mmq_test_tldudusu(N,ix);
%MMQ_TEST_TLDUDUSU computes the solution by updating with mmq_tldudus
%
% Author G. Meurant
% June 2007
%

[x,w,y,ier]=mmq_pwv(N,ix);
if ier == 1
 error('MMQ_TEST_TLDUDUSU: Unknown problem, abort')
end

% recursively build the solution
sig=abs(w(1));
alpha(1)=x(1);
beta(1)=0;
d(1)=y(1)*sig;

n=1;
for i=1:N-1
 % update
 [n,sig,alpha,beta,d]=mmq_tldudus(i,alpha,beta,sig,d,x(i+1),w(i+1),y(i+1),1);
 %disp('update tldudus-----------------------')
 %n
 if n ~= i+1
  disp('MMQ_TEST_TLDUDUSU: pb in updating')
  [i n]
 end
end

