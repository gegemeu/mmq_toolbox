/* lbidiagQx.c, MATLAB Version 6

   The calling syntax is:

       y = lbidiagQx (Q, x)

   This procedure computes the product

       y = Q * x.

   The matrix Q must originate from the procedure lbidiagQR.

   Urs von Matt, October 26, 1994 */
   /* modified by G. Meurant, Dec 06 */



#include <math.h>
#include "mex.h"
#include "blas.c"



static void lbidiagQx (n, Q, x, y)
  int    n;
  double *Q, *x, *y;

{ int i, ldQ;

  ldQ = 2*n;
  for (i = 0; i <= 2*n; i++) {
    y [i] = x [i];
  }
  for (i = n-1; i >= 0; i--) {
    rot (&y [i], &y [i+1], Q [2*i+1], -Q [2*i+1 + ldQ]);
    rot (&y [i], &y [n+1+i], Q [2*i], -Q [2*i + ldQ]);
  }
}



/* Input Arguments */
#define	Q prhs[0]
#define	x prhs[1]

/* Output Arguments */
#define	y plhs[0]

void mexFunction(
    int nlhs, mxArray *plhs[],
    int nrhs, const mxArray *prhs[])

{ int n;

  /* Check for proper number of arguments */
  if (nrhs != 2) {
    mexErrMsgTxt ("lbidiagQx requires two input arguments.");
  } else if (nlhs != 1) {
    mexErrMsgTxt ("lbidiagQx requires one output argument.");
  }

  /* Check the dimensions of x. */
  n = (mxGetM (x) - 1) / 2;
  if ((mxGetM (x) != 2*n+1) || (mxGetN (x) != 1)) {
    mexErrMsgTxt ("x must be an (2*n+1)-by-1 matrix.");
  }

  /* Check the dimensions of Q. */
  if ((mxGetM (Q) != 2*n) || (mxGetN (Q) != 2)) {
    mexErrMsgTxt ("Q must be an (2*n)-by-2 matrix.");
  }

  /* Create matrices for the return arguments. */
  /* y = mxCreateFull (2*n+1, 1, REAL); */
  y = mxCreateDoubleMatrix(2*n+1,1, mxREAL);

  /* Do the actual computations in a subroutine. */
  lbidiagQx (n, mxGetPr (Q), mxGetPr (x), mxGetPr (y));
}
