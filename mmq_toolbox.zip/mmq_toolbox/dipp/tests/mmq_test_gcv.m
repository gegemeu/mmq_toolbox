%MMQ_TEST_GCV compute the regularization parameters
%
% Script by Urs von Matt
% modified by G. Meurant Dec 2006
%
% mmq_test_gcv is called by scripts mmq_run_test_gcv....
%
% communication among
% mmq_test_gcv, mmq_test_gcv_Kprod, mmq_test_gcv_V, mmq_test_gcv_Vt
%
global test_gcv_case test_gcv_sigma test_gcv_KU test_gcv_u ...
 test_gcv_KV test_gcv_v test_gcv_u test_gcv_y;

global gcv_func_min gcv_func_max;

% clear all figures
close all

fprintf (1, '\n\nMMQ_TEST_GCV\n--------\n\n');

% reset random number generators
% the choice affects the noise which is added
% to reproduce the results of the Golub and von Matt paper
% choose the Matlab 4 generator

% Matlab 4 random number generator
rand ('seed', 0);
% Matlab 6,... random number generator
%rand('state',0);
randn ('seed', 0);
%randn('state',0);

test_gcv_case = gcase;
r = min (m, n);

reort=0;
plotsol = 0;

% different methods for the computation of the 
% regularization parameter

% Von Matt - Golub (GCV)
vm=1;
% Golub - Meurant (GCV)
gm=1;
% Discrepancy principle
disc=1;
% Grefrer - Raus
gr=1;
% GCV (with SVD)
gcv=1;
% L-curve
lc=1;
% Quasi-optimality
qo=1;

if gcase == 0
 fprintf (1, 'MMQ_TEST_GCV: Test problem with linear singular value distribution\n');
 fprintf (1, '(c = %11.4e)\n', c);
 
 % generate the singular values 
 aa=(1000*eps-1)/(r-1);
 % linear distribution
 test_gcv_sigma=aa*([1:r]'-1)+1;
 % generate random vectors
 test_gcv_u = mmq_usin (m);
 %test_gcv_u = randn (m, 1);
 test_gcv_u = (sqrt (2) / norm (test_gcv_u, 2)) * test_gcv_u;
 test_gcv_v = mmq_usin (n);
 %test_gcv_v = randn (n, 1);
 test_gcv_v = (sqrt (2) / norm (test_gcv_v, 2)) * test_gcv_v;
 normK = max (test_gcv_sigma);
 
 %x0 = randn (n, 1);
 % use the solution of the Shaw problem
 %
 x0 = mmq_solshaw (n);
 % matrix vector product using the SVD
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 if plotsol == 1
  plot(x0)
  pause
  plot(y0)
  pause
 end
 
elseif gcase == 1
 fprintf (1, 'MMQ_TEST_GCV: Test problem with exponential singular value distribution\n');
 fprintf (1, '(c = %11.4e)\n', c);
 
 % generate the singular values using c (set in run_test_gcv...)
 test_gcv_sigma = exp (-abs (c) * [1:r]');
 % generate random vectors
 test_gcv_u = randn (m, 1);
 %test_gcv_u = usin(m);
 test_gcv_u = (sqrt (2) / norm (test_gcv_u, 2)) * test_gcv_u;
 test_gcv_v = randn (n, 1);
 %test_gcv_v = usin(n);
 test_gcv_v = (sqrt (2) / norm (test_gcv_v, 2)) * test_gcv_v;
 normK = max (test_gcv_sigma);
 
 %x0 = randn (n, 1);
 % use the solution of the Shaw problem
 %
 %[Ks, ys, x0] = shaw (n);
 x0 = mmq_solshaw (n);
 % matrix vector product using the SVD
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 if plotsol == 1
  plot(x0)
  pause
  plot(y0)
  pause
 end
 
elseif gcase == 2
 fprintf (1, 'MMQ_TEST_GCV:  Fredholm integral equation of the first kind\n');
 fprintf (1, '(regutools/baart)\n');
 if m ~= n
  error ('MMQ_TEST_GCV: m ~= n');
 end
 
 % generate the problem using regutools
 [K, y, x0] = baart (n);
 % compute the SVD
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 3
 fprintf (1, 'MMQ_TEST_GCV:  Computation of the second derivative.\n');
 fprintf (1, '(regutools/deriv2)\n');
 if m ~= n
  error ('MMQ_TEST_GCV: m ~= n');
 end
 
 [K, y, x0] = deriv2 (n, 1);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 4
 fprintf (1, 'MMQ_TEST_GCV: Severely ill-posed test problem.\n');
 fprintf (1, '(regutools/foxgood)\n');
 if m ~= n
  error ('MMQ_TEST_GCV: m ~= n');
 end
 
 [K, y, x0] = foxgood (n);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 5
 fprintf (1, 'MMQ_TEST_GCV: Inverse heat equation.\n');
 fprintf (1, '(regutools/heat)\n');
 if m ~= n
  error ('MMQ_TEST_GCV: m ~= n');
 end
 
 kappa = 1;
 [K, y, x0] = heat (n, kappa);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 6
 fprintf (1, 'MMQ_TEST_GCV: Inverse Laplace transformation.\n');
 fprintf (1, '(regutools/ilaplace)\n');
 if m ~= n
  error ('MMQ_TEST_GCV: m ~= n');
 end
 
 example = 1;
 [K, y, x0] = ilaplace (n, example);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 7
 fprintf (1, 'MMQ_TEST_GCV: Stellar parallax problem with 28 fixed, real observations.\n');
 fprintf (1, '(regutools/parallax)\n');
 
 [K, y0] = parallax (n);
 % the exact solution x0 is unknown
 x0 = zeros (n, 1);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 
elseif gcase == 8
 fprintf (1, 'MMQ_TEST_GCV: Phillips''s "famous" test problem.\n');
 fprintf (1, '(regutools/phillips)\n');
 if m ~= n
  error ('MMQ_TEST_GCV: m ~= n');
 end
 
 [K, y, x0] = phillips (n);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 9
 fprintf (1, 'MMQ_TEST_GCV: One-dimensional image restoration model.\n');
 fprintf (1, '(regutools/shaw)\n');
 if m ~= n
  error ('MMQ_TEST_GCV: m ~= n');
 end
 
 [K, y, x0] = shaw (n);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 10
 fprintf (1, 'MMQ_TEST_GCV: Test problem with a "spiky" solution.\n');
 fprintf (1, '(regutools/spikes)\n');
 if m ~= n
  error ('MMQ_TEST_GCV: m ~= n');
 end
 
 t_max = 5;
 [K, y, x0] = spikes (n, t_max);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 11
 fprintf (1, 'MMQ_TEST_GCV: Integral equation with no square integrable solution.\n');
 fprintf (1, '(regutools/ursell)\n');
 if m ~= n
  error ('MMQ_TEST_GCV: m ~= n');
 end
 
 [K, y0] = ursell (n);
 % there is no square integrable solution
 x0 = zeros (n, 1);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 
elseif gcase == 12
 fprintf (1, 'MMQ_TEST_GCV: Test problem with a discontinuous solution.\n');
 fprintf (1, '(regutools/wing)\n');
 if m ~= n
  error ('MMQ_TEST_GCV: m ~= n');
 end
 
 t1 = 1/3;
 t2 = 2/3;
 [K, y, x0] = wing (n, t1, t2);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
 
elseif gcase == 13
 fprintf (1, 'MMQ_TEST_GCV: Test problem with a blurred image\n');
 fprintf (1, '(regutools/blur\n');
 if m ~= n
  error ('MMQ_TEST_GCV: m ~= n');
 end
 
 [K, y, x0] = blur (n);
 K=full(K);
 [m,n]=size(K);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 r=rank(K);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
else
 error ('MMQ_TEST_GCV: invalid value of gcase');
end

tmp=test_gcv_sigma;
ntmp=length(tmp);
tmp=sort(tmp);
test_gcv_sigma=tmp(ntmp:-1:1);

fprintf (1, 'm          = %5i\n', m);
fprintf (1, 'n          = %5i\n', n);
fprintf (1, 'sigma (1)  = %11.4e    sigma (%i) = %11.4e\n', ...
 test_gcv_sigma (1), r, test_gcv_sigma (r));
fprintf (1, 'cond (K)   = %11.4e\n', ...
 test_gcv_sigma (1) / test_gcv_sigma (r));
fprintf (1, 'noise      = %11.4e\n\n', noise);

pause

% generate the noise and the perturbed right hand side
old_rhs=0;
if old_rhs == 1
 e = randn (m, 1);
 e = (noise / norm (e, 2)) * e;
 y = y0 + e;
else
 %reset the random number generator
 y=mmq_noisy(y0,noise);
end
if plotsol == 1
 plot(y)
 pause
end
% compute the solution  x (lambda) using the SVD
if gcase <= 1
 % large test problem
 x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
 x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 );
 x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
else
 % small test problem
 x = test_gcv_KU (:, 1:r)' * y;
 x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2);
 x = test_gcv_KV (:, 1:r) * x;
end
if plotsol == 1
 plot(x)
 pause
end
test_gcv_y = y;

if plotsol == 1
 figure
 plot(x0)
 title(['solution, noise = ' num2str(noise)])
 hold on
end

% computation of the regularization parameter

if vm == 1
 disp('-----------------------')
 % call the bidiagonalization Lanczos algorithm defined in the Golub and von
 % Matt paper
 % return the regularization parameter s.t. mu=m lambda
 if reort == 0
  [gcv_l_lambda, success] = mmq_gcv_lanczos ('mmq_test_gcv_Kprod', m, n, normK, y);
 else
  [gcv_l_lambda, success] = mmq_gcv_lanczos_reort ('mmq_test_gcv_Kprod', m, n, normK, y);
 end
 %if ~success
 %  fprintf (1, 'MMQ_TEST_GCV: gcv_lanczos failed.\n');
 % end
 fprintf (1, 'nb func min = %10i,   nb func max = %10i,    sum = %10i\r', gcv_func_min, gcv_func_max,gcv_func_min+gcv_func_max);
 
 % compute the regularized solution  x (lambda) using the SVD
 if gcase <= 1
  % large test problem
  x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
  x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * gcv_l_lambda);
  x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
 else
  % small test problem
  x = test_gcv_KU (:, 1:r)' * y;
  x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * gcv_l_lambda);
  x = test_gcv_KV (:, 1:r) * x;
 end
 % compute the norm  of the residual and the error
 fprintf (1, '|| y - K * x (lambda) ||_2 = %11.4e\n', ...
  norm (y - mmq_test_gcv_Kprod ('N', m, n, x)));
 fprintf (1, '|| x (lambda) - x0 ||_2    = %11.4e\n', norm (x - x0, 2));
 fprintf (1, '|| x (lambda) ||_2    = %11.4e\n', norm (x, 2));
 
 if plotsol == 1
  plot(x,'--')
 end
end

if gm == 1
 disp('-----------------------')
 if gcase > 1
  [gcv_l_lambda_m, gcv_l_lambda1, success_m] = mmq_gcv_lanczos_m_log6 (K, y);
  gcv_l_lambda=gcv_l_lambda_m;
  fprintf (1, 'nb func min = %10i,   nb func max = %10i,    sum = %10i\r', gcv_func_min, gcv_func_max,gcv_func_min+gcv_func_max);
 else
  if reort == 0
   [gcv_l_lambda_m, gcv_l_lambda1, success_m] = mmq_gcv_lanczos_m_log6_g (test_gcv_u,test_gcv_sigma,test_gcv_v, y);
  else
   [gcv_l_lambda_m, gcv_l_lambda1, success_m] = mmq_gcv_lanczos_m_log6_g_reort (test_gcv_u,test_gcv_sigma,test_gcv_v, y);
  end
  gcv_l_lambda=gcv_l_lambda_m;
  fprintf (1, 'nb func min = %10i,   nb func max = %10i,    sum = %10i\r', gcv_func_min, gcv_func_max,gcv_func_min+gcv_func_max);
 end
 
 % compute the regularized solution  x (lambda) using the SVD
 if gcase <= 1
  % large test problem
  x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
  x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * gcv_l_lambda/m);
  x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
 else
  % small test problem
  x = test_gcv_KU (:, 1:r)' * y;
  x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * gcv_l_lambda/m);
  x = test_gcv_KV (:, 1:r) * x;
 end
 % compute the norm  of the residual and the error
 fprintf (1, '|| y - K * x (lambda) ||_2 = %11.4e\n', ...
  norm (y - mmq_test_gcv_Kprod ('N', m, n, x)));
 fprintf (1, '|| x (lambda) - x0 ||_2    = %11.4e\n', norm (x - x0, 2));
 fprintf (1, '|| x (lambda) ||_2    = %11.4e\n', norm (x, 2));
 fprintf (1, '\n');
 
 if plotsol == 1
  plot(x,'-.')
  pause
 end
end

if disc == 1
 % compute the regularization parameter from the discrepancy principle
 % compute mu=m * lambda
 disp('-----------------------')
 if gcase <= 1
  discrep_lambda = mmq_discrep (test_gcv_u, test_gcv_sigma, test_gcv_y, noise);
 else
  discrep_lambda = mmq_discrep (test_gcv_KU, test_gcv_sigma, test_gcv_y, noise);
 end
 discrep_lambda = discrep_lambda / m;
 fprintf (1, '\n');
 fprintf (1, 'discrep: nu = %11.4e  mu = %11.4e\n\n', discrep_lambda, m*discrep_lambda);
 
 if discrep_lambda > 0
  % compute the regularized solution  x (lambda) using the SVD
  if gcase <= 1
   % large test problem
   x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * discrep_lambda);
   x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
  else
   % small test problem
   x = test_gcv_KU (:, 1:r)' * y;
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * discrep_lambda);
   x = test_gcv_KV (:, 1:r) * x;
  end
  % compute the norm  of the residual and the error
  fprintf (1, '|| y - K * x (lambda) ||_2 = %11.4e\n', ...
   norm (y - mmq_test_gcv_Kprod ('N', m, n, x)));
  fprintf (1, '|| x (lambda) - x0 ||_2    = %11.4e\n', norm (x - x0, 2));
  fprintf (1, '|| x (lambda) ||_2    = %11.4e\n', norm (x, 2));
  
  if plotsol == 1
   plot(x,':')
  end
 else
  fprintf (1, 'lambda <= 0\n');
 end
 if plotsol == 1
  pause
  hold off
 end
end

if gr == 1
 % compute the regularization parameter from the Gfrerer principle
 % compute mu=m * lambda
 disp('-----------------------')
 if gcase <= 1
  gfrerer_lambda = mmq_gfrerer (test_gcv_u, test_gcv_sigma, test_gcv_y, noise);
 else
  gfrerer_lambda = mmq_gfrerer (test_gcv_KU, test_gcv_sigma, test_gcv_y, noise);
 end
 gfrerer_lambda = gfrerer_lambda / m;
 fprintf (1, '\n');
 fprintf (1, 'Gfrerer: nu = %11.4e  mu = %11.4e\n\n', gfrerer_lambda, m*gfrerer_lambda);
 
 if gfrerer_lambda > 0
  % compute the regularized solution  x (lambda) using the SVD
  if gcase <= 1
   % large test problem
   x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * gfrerer_lambda);
   x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
  else
   % small test problem
   x = test_gcv_KU (:, 1:r)' * y;
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * gfrerer_lambda);
   x = test_gcv_KV (:, 1:r) * x;
  end
  % compute the norm  of the residual and the error
  fprintf (1, '|| y - K * x (lambda) ||_2 = %11.4e\n', ...
   norm (y - mmq_test_gcv_Kprod ('N', m, n, x)));
  fprintf (1, '|| x (lambda) - x0 ||_2    = %11.4e\n', norm (x - x0, 2));
  fprintf (1, '|| x (lambda) ||_2    = %11.4e\n', norm (x, 2));
  
  if plotsol == 1
   plot(x,':v')
  end
 else
  fprintf (1, 'lambda <= 0\n');
 end
 
 if plotsol == 1
  pause
 end
end

if gcv == 1
 % compute the regularization parameter from the (old) regutools toolbox
 disp('-----------------------')
 if gcase <= 1
  [regutools_gcv, G, reg_param] = ...
   mmq_gcv (test_gcv_u, test_gcv_sigma, test_gcv_y);
 else
  [regutools_gcv, G, reg_param] = ...
   mmq_gcv (test_gcv_KU, test_gcv_sigma, test_gcv_y);
 end
 regutools_gcv = regutools_gcv^2 / m;
 fprintf (1, '\n');
 fprintf (1, 'gcv: nu = %11.4e  mu = %11.4e\n\n', regutools_gcv, m*regutools_gcv);
 
 if regutools_gcv > 0
  % compute the regularized solution  x (lambda) using the SVD
  if gcase <= 1
   % large test problem
   x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * regutools_gcv);
   x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
  else
   % small test problem
   x = test_gcv_KU (:, 1:r)' * y;
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * regutools_gcv);
   x = test_gcv_KV (:, 1:r) * x;
  end
  % compute the norm  of the residual and the error
  fprintf (1, '|| y - K * x (lambda) ||_2 = %11.4e\n', ...
   norm (y - mmq_test_gcv_Kprod ('N', m, n, x)));
  fprintf (1, '|| x (lambda) - x0 ||_2    = %11.4e\n', norm (x - x0, 2));
  fprintf (1, '|| x (lambda) ||_2    = %11.4e\n', norm (x, 2));
  
  if plotsol == 1
   plot(x,':o')
  end
 else
  fprintf (1, 'lambda <= 0\n');
 end
 if plotsol == 1
  pause
 end
end

if lc == 1
 % compute the regularization parameter from the L-curve
 disp('-----------------------')
 if gcase <= 1
  [regutools_l_curve, G, reg_param] = ...
   mmq_l_curve (test_gcv_u, test_gcv_sigma, test_gcv_y);
 else
  [test_gcv_KU1, test_gcv_sigma1, test_gcv_KV1] = svd (K,0);
  test_gcv_sigma1 = diag(test_gcv_sigma1);
  [regutools_l_curve, G, reg_param] = ...
   mmq_l_curve (test_gcv_KU1, test_gcv_sigma1, test_gcv_y);
 end
 regutools_l_curve = regutools_l_curve^2 / m;
 fprintf (1, '\n');
 fprintf (1, 'l_curve: nu = %11.4e  mu = %11.4e\n\n', regutools_l_curve,m*regutools_l_curve);
 
 if regutools_l_curve > 0
  % compute the regularized solution  x (lambda) using the SVD
  if gcase <= 1
   % large test problem
   x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * regutools_l_curve);
   x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
  else
   % small test problem
   x = test_gcv_KU (:, 1:r)' * y;
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * regutools_l_curve);
   x = test_gcv_KV (:, 1:r) * x;
  end
  % compute the norm  of the residual and the error
  fprintf (1, '|| y - K * x (lambda) ||_2 = %11.4e\n', ...
   norm (y - mmq_test_gcv_Kprod ('N', m, n, x)));
  fprintf (1, '|| x (lambda) - x0 ||_2    = %11.4e\n', norm (x - x0, 2));
  fprintf (1, '|| x (lambda) ||_2    = %11.4e\n', norm (x, 2));
  
  if plotsol == 1
   plot(x,':+')
  end
 else
  fprintf (1, 'lambda <= 0\n');
 end
 if plotsol == 1
  pause
 end
end

if qo == 1
 % compute the quasiopt parameter
 % plots the quasiopt curve
 % needs the regutools toolbox
 disp('-----------------------')
 
 if gcase <= 1
  [regutools_quasiopt, G, reg_param] = ...
   mmq_quasiopt (test_gcv_u, test_gcv_sigma, test_gcv_y);
 else
   [test_gcv_KU1, test_gcv_sigma1, test_gcv_KV1] = svd (K,0);
  test_gcv_sigma1 = diag(test_gcv_sigma1);
  [regutools_quasiopt, G, reg_param] = ...
   mmq_quasiopt (test_gcv_KU1, test_gcv_sigma1, test_gcv_y);
 end
 old_regutools_quasiopt=regutools_quasiopt;
 regutools_quasiopt = regutools_quasiopt^2 / m;
 fprintf (1, '\n');
 fprintf (1, 'regutools/quasiopt: nu = %11.4e  mu = %11.4e  sigma = %11.4e\n\n', regutools_quasiopt,m*regutools_quasiopt,old_regutools_quasiopt);
 
 if regutools_quasiopt > 0
  % compute the regularized solution  x (lambda) using the SVD
  if gcase <= 1
   % large test problem
   x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * regutools_quasiopt);
   x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
  else
   % small test problem
   x = test_gcv_KU (:, 1:r)' * y;
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * regutools_quasiopt);
   x = test_gcv_KV (:, 1:r) * x;
  end
  % compute the norm  of the residual and the error
  fprintf (1, '|| y - K * x (lambda) ||_2 = %11.4e\n', ...
   norm (y - mmq_test_gcv_Kprod ('N', m, n, x)));
  fprintf (1, '|| x (lambda) - x0 ||_2    = %11.4e\n', norm (x - x0, 2));
  fprintf (1, '|| x (lambda) ||_2    = %11.4e\n', norm (x, 2));
  
  if plotsol == 1
   plot(x,':s')
  end
 else
  fprintf (1, 'lambda <= 0\n');
 end
 if plotsol == 1
  hold off
  pause
 end
end