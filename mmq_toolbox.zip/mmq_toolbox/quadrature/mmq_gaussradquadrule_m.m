function [t,w]=mmq_gaussradquadrule_m(a,b,mu0,node);
%MMQ_GAUSSRADQUADRULE_M computes nodes and weights of the Gauss-Radau rule using the Matlab QR algorithm
% a and b are the elements of the diagonal and subdiagonal of the Jacobi
% matrix for the orthonormal polynomials associated with the measure
% mu0 is the moment of order zero
%

% Author G. Meurant
% June 2007
%

n=length(a);
if n == 1
  t=a(1);
  w=mu0;
  return
end

% modify the last element diagonal element

% tridiagonal solve of (J_{n-1}- node I) delta = b_{n-1}^2 (0 0 ... 1)^T

t=spdiags([b' a(1:n-1)' [0 b(1:n-2)]'], -1:1, n-1, n-1);

e=zeros(n-1,1);
e(n-1)=1;
d=(t-node*speye(n-1))\(b(n-1)^2*e);

a(n)=node+d(n-1);

J=diag(a)+diag(b,-1)+diag(b,1); 
J=full(J);
[V,D]=eig(J);
t=diag(D);
[t,i]=sort(t);
w=mu0*V(1,i).^2;
t=t';