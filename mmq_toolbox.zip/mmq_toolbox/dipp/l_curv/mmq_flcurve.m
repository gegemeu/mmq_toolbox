function [x,r] = mmq_flcurve(lambda,u,s,v,y);
%MMQ_FLCURVE computes the values of the l-curve
%
% u, s, v SVD
%
% Author  G. Meurant
% Jan 2007
%

[m_lambda, n_lambda] = size (lambda);
ut0 = zeros (m_lambda, n_lambda);
N = m_lambda * n_lambda;

lambda=10.^lambda;

d = u' * y;

x=zeros(N,1);
r=x;

for i = 1:N
 if lambda (i) < 0
  error ('MMQ_FLCURVE: lambda (i) < 0');
 end
 mu = lambda (i);
 
 % compute the norm of c-Ax using the  singular values of A
 
 t = s.^2 + mu;
 num=  sum ((mu*d ./ t).^2);
 
 % norms of x and r
 
 den=sum((s .* d ./ t).^2);
 
 nri=log10(sqrt(num));
 nxi=log10(sqrt(den));
 
 r(i)=nri;
 x(i)=nxi;
 
end