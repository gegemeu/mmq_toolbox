function w=mmq_qlgauss(t,alpha,beta,mu0);
%MMQ_QLGAUSS given the nodes t and the Jacobi matrix 
% (alpha, beta) computes the weights w
% mu0 is the zero-th moment
% from Laurie's paper
%

% Author G. Meurant
% June 2007
%

n=length(alpha);
ww=eye(n,1);

for j=1:n-2
 [alpha,beta,ww]=mmq_qlsweep(alpha,beta,t(j),ww);
 w(j)=ww(1);
 % deflation
 alpha=alpha(2:end);
 beta=beta(2:end);
 ww=ww(2:end);
end

% we are left with a 2 x 2 matrix J
[alpha,beta,ww]=mmq_qlsweep(alpha,beta,t(n-1),ww);
w(n-1)=ww(1);

% last element
w(n)=ww(2);

% the weights are mu0 times the squares of the first components
w=mu0*w.^2;




 