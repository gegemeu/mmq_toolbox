function mmq_plotsecul(d,rho,c);
%MMQ_PLOTSECUL plot figures of a secular equation
%  y=1+rho*sum(c(i)^2/(d(i)-x))
% the function is defined in secul
% rho is a scalar and the coefficients c and the poles d are vectors
%
% Author G. Meurant
% july 2007
%

km=length(d);
lmin=min(d(:));
lmax=max(d(:));
dta=sort(d);
lmm=lmax-lmin;
ymax=10;
ymin=-10;

k=km;
 
% we  need the components squared
xi=(c(:).^2);
figure
hold on

% plot the poles
for i=1:k
  plot([d(i) d(i)],[-ymax ymax],'--')
end

% plot the function between the k poles 
lamb=[lmin-2 d(:)' lmax+2];
for i=1:k+1
  epsi1=(lamb(i+1)-lamb(i))*1e-5;
  epsi2=epsi1;
  if i == 1
    epsi1=-lmin/2;
    epsii=epsi1;
  end
  if i == k+1
    epsi2=-lmin/2;
  end
  x=linspace(lamb(i)+epsi1,lamb(i+1)-epsi2,50);
  y=secul(rho,xi,d,x);
  plot(x,y)
end

% plot( the x axis
plot([min(lamb) max(lamb)],[0 0],'-.')
axis([min(lamb) max(lamb) -ymax ymax])
title(['Secular function'])
hold off

function y=secul(rho,xi,dts,x);
%SECUL function f
%
k=length(x);
for i=1:k
  z=xi(:)./(dts(:)-x(i));
  y(i)=1+rho*sum(z);
end
