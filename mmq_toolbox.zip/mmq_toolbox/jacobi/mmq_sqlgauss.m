function w=mmq_sqlgauss(t,alpha,beta,mu0);
%MMQ_SQLGAUSS given the nodes t and the Jacobi matrix 
% (alpha, beta) computes the weights w by streamline QL
% mu0 is the zero-th moment
% from Laurie's paper
%

% Author G. Meurant
% June 2007
%

n=length(alpha);
mu=mu0;

for j=1:n-2
 [alpha,beta,C,S]=mmq_qlsweepcs(alpha,beta,t(j));
 w(j)=C*mu;
 mu=S*mu;
 % deflation
 alpha=alpha(2:end);
 beta=beta(2:end);
end

% we are left with a 2 x 2 matrix J
[alpha,beta,C,S]=mmq_qlsweepcs(alpha,beta,t(n-1));
w(n-1)=C*mu;
mu=S*mu;

% last element
w(n)=mu;





 