function [mul,muu,iter]=mmq_l_ribbon_curvat_it_g(ur,s,vr,y,kmax);
%MMQ_L_RIBBON_CURVAT_IT_G computes the curvatures of the L-ribbon
% approximations when the matrix is defined by ur, s, vr
%
% Lanczos bidiagonalization to compute lower and upper bounds of the L-curve
%
% Author G. Meurant
% Feb 2007
%

ny=norm(y);
naty=norm(mmq_pmatat(ur,s,vr,y));
m=size(ur,1);

% compute the exact L-curve and the limits

np=50;
[rho,eta,mu,err,lambdamin,lambdamax]=mmq_comp_l_curve2(ur,s,vr,y,np,zeros(size(vr,1),1));

mul_old=realmin;
muu_old=realmax;

% start the Lanczos iterations
% similar to l_bidiagaat

k=kmax;
c=sparse(k+1,k+1);

% init
u_old=y/norm(y);
%w=a'*u_old;
w=mmq_pmatat(ur,s,vr,u_old);
c(1,1)=norm(w);
v_old=w/c(1,1);

epsd=1e-2;
% t refers to values of log(lambda)
aa=log10(lambdamin);
bb=log10(lambdamax);
n=50;
t=linspace(aa,bb,n);
mu=10.^t;

for i=2:k+1
 %w=a*v_old-c(i-1,i-1)*u_old;
 w=mmq_pmata(ur,s,vr,v_old)-c(i-1,i-1)*u_old;
 c(i,i-1)=norm(w);
 u=w/c(i,i-1);
 
 %w=a'*u-c(i,i-1)*v_old;
 w=mmq_pmatat(ur,s,vr,u)-c(i,i-1)*v_old;
 c(i,i)=norm(w);
 v=w/c(i,i);
 
 u_old=u;
 v_old=v;
 
 if i > 3
  
  cc=c(1:i-1,1:i-1);
  ccb=c(1:i,1:i-1);
  [q,cch]=qr(full(ccb));
  cch=cch(1:end-1,:);
  if any(diag(cch) < 0)
   cch=-cch;
  end
  cch=cch';
  % remove the last column
  cchb=cch(:,1:end-1);
  
  % compute the approximations using SVDs rather than
  % solving least squares problems
  % (there are relations between these SVDs ?)
  [ucc,scc,vcc]=svd(full(cc));
  scc=diag(scc);
  [uccb,sccb,vccb]=svd(full(ccb));
  sccb=diag(sccb);
  [ucch,scch,vcch]=svd(full(cch));
  scch=diag(scch);
  [ucchb,scchb,vcchb]=svd(full(cchb));
  scchb=diag(scchb);
  
  gcc=mmq_comp_l_ribbon(mu,ucc,scc,vcc);
  lbr=ny^2*mu.^2.*gcc;
  
  gccb=mmq_comp_l_ribbon(mu,uccb,sccb,vccb);
  ubr=ny^2*mu.^2.*gccb;
  
  gcch=mmq_comp_l_ribbon(mu,ucch,scch,vcch);
  lbx=naty^2*gcch;
  
  gcchb=mmq_comp_l_ribbon(mu,ucchb,scchb,vcchb);
  ubx=naty^2*gcchb;
  
  pcch=mmq_comp_l_ribbon1(mu,ucch,scch,vcch);
  ubxp=-4*(naty^2*pcch);
  
  pcchb=mmq_comp_l_ribbon1(mu,ucchb,scchb,vcchb);
  lbxp=-4*(naty^2*pcchb);
  
  taul=2*(lbx.*lbr)./(mu.^2.*ubx.^2+ubr.^2).^(3/2);
  tauu=2*(ubx.*ubr)./(mu.^2.*lbx.^2+lbr.^2).^(3/2);
  
  xil=mu.*lbr+mu.^2.*lbx+2*ubr.*(ubx./ubxp);
  xiu=mu.*ubr+mu.^2.*ubx+2*lbr.*(lbx./lbxp);
  
  cl=zeros(length(mu),1);
  cu=cl;
  for j=1:length(mu)
   if xil(j) >= 0
    cl(j)=taul(j)*xil(j);
   else
    cl(j)=tauu(j)*xil(j);
   end
   if xiu(j) >= 0
    cu(j)=tauu(j)*xiu(j);
   else
    cu(j)=taul(j)*xiu(j);
   end
  end
  
  curl=-cu;
  curu=-cl;
  
  plots=0;
  if plots
   plot(curl)
   hold on
   plot(curu,'r')
   hold off
   pause
  end
  
  [ltmp,kl]=max(curl);
  [utmp,ku]=max(curu);
  
  % the corner is given by the corresponding value of t
  mul=mu(kl);
  muu=mu(ku);
  
  dmul=abs(mul-mul_old)/mul;
  dmuu=abs(muu-muu_old)/muu;
  
  if dmul+dmuu <= 2*epsd & abs(mul-muu)/muu <= epsd
   iter=i;
   return
  else
   mul_old=mul;
   muu_old=muu;
  end
  
 end
end
% end of Lanczos iterations





