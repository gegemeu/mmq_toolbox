function [alpha,beta,w]=mmq_qrsweep(alpha,beta,sigma,w);
%MMQ_QRSWEEP one step of implicit shift QR with shift sigma
% from Laurie's paper
% w is a vector (weights)

% Author G. Meurant
% June 2007
%

x=alpha(1)-sigma;
z=beta(1);
n=length(alpha);

if n == 1
 return
end

% first rotation
[c,s,c2,s2,cs]=mmq_givens(x,z);
csb=2*cs*beta(1);
t11=c2*alpha(1)-csb+s2*alpha(2);
t21=beta(1)*(c2-s2)+cs*(alpha(1)-alpha(2));
t22=s2*alpha(1)+csb+c2*alpha(2);
w1=c*w(1)-s*w(2);
w2=s*w(1)+c*w(2);

alpha(1)=t11;
beta(1)=t21;
alpha(2)=t22;
w(1)=w1;
w(2)=w2;

if n > 2
 t32=c*beta(2);
 z=-s*beta(2);
 beta(2)=t32;
else 
 return
end

% chase the bulge z down the diagonal
for k=2:n-2
 x=beta(k-1);
 [c,s,c2,s2,cs]=mmq_givens(x,z);
 csb=2*cs*beta(k);
 tkk=c2*alpha(k)-csb+s2*alpha(k+1);
 tkkm1=c*beta(k-1)-s*z;
 tk1k1=s2*alpha(k)+csb+c2*alpha(k+1);
 tk1k=beta(k)*(c2-s2)+cs*(alpha(k)-alpha(k+1));
 z=-s*beta(k+1);
 tk2k1=c*beta(k+1);
 wk=c*w(k)-s*w(k+1);
 wk1=s*w(k)+c*w(k+1);
 
 alpha(k)=tkk;
 beta(k-1)=tkkm1;
 alpha(k+1)=tk1k1;
 beta(k)=tk1k;
 beta(k+1)=tk2k1;
 w(k)=wk;
 w(k+1)=wk1;
end

 x=beta(n-2);
 [c,s,c2,s2,cs]=mmq_givens(x,z);
 csb=2*cs*beta(n-1);
 tkk=c2*alpha(n-1)-csb+s2*alpha(n);
 tkkm1=c*beta(n-2)-s*z;
 tk1k1=s2*alpha(n-1)+csb+c2*alpha(n);
 tk1k=beta(n-1)*(c2-s2)+cs*(alpha(n-1)-alpha(n));
 wn1=c*w(n-1)-s*w(n);
 wn=s*w(n-1)+c*w(n);
 
 alpha(n-1)=tkk;
 beta(n-2)=tkkm1;
 alpha(n)=tk1k1;
 beta(n-1)=tk1k;
 w(n-1)=wn1;
 w(n)=wn;
 
 

 
 
