%MMQ_RUN_TEST_GCV_SMALL run GCV for the small von Matt problem
%
% Author G. Meurant Dec 2006
%

warning off

% Small test problem with exponential singular value distribution

gcase = 1;
m = 1000;
n = 500;
%c = -0.03;
c=-20*3/m;


noise = 1e-1;
mmq_test_gcv;

pause

noise = 1;
mmq_test_gcv;

pause

noise = 10;
mmq_test_gcv;


warning on