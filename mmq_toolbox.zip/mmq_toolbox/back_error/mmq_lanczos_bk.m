function [mu, success, iter] = mmq_lanczos_bk(K,b,x);
%MMQ_LANCZOS_BK estimate of backward error of a least squares solution
% by Lanczos bidiagonalization
% matrix K, right hand side b
% to be used instead of mmq_backls when K is large
%
%
% use the SVD of B_k
%
%
% Author  G. Meurant 
% Aug 2008
%
%
% communication among
% mmq_gcv_lanczos, mmq_gcv_l_Bounds, mmq_gcv_l_Lt0, mmq_gcv_l_Lt1,
% mmq_gcv_l_Ut0, mmq_gcv_l_Ut1, mmq_test_gcv_Vt, etc...
%
global gcv_l_m gcv_l_n gcv_l_normy gcv_l_normK gcv_l_normKTy ...
 gcv_l_u gcv_l_normu ...
gcv_l_gamma_y gcv_l_delta_y gcv_l_gamma_u gcv_l_delta_u;

global gcv_func_min gcv_func_max;

global S_y U_y S_u V_u;

global uyn2;

[m,n]=size(K);
r=b-K*x;

iter=0;

lambda = 0;
success = 0;

gcv_l_m = m;
gcv_l_n = n;

gcv_l_gamma_y = [];
gcv_l_delta_y = [];

tic

% initialize bidiagonalizations
bidiag_y = 1;

k_y = 0;
% maximum number of iterations
kmax = 2 * min (m, n);

normK=norm(K,'fro');
bidiag_tol = 10 * max (m, n) * eps * normK;

end_of_Lanczos = 0;

by=sparse(m,m);
y=r;
gcv_l_normy=norm(y);
nx=norm(x);
nx2=nx*nx;
nu=gcv_l_normy/nx;
nu=nu*nu;
mu_old=1;
mueps=realmax;

% start Lanczos iterations

while ~(end_of_Lanczos | success)
 %fprintf (1, 'MMQ_LANCZOS_BK: k_y = %4i\r', k_y);
 
 % bidiagonalization with y as starting vector
 if k_y == 0
  p_y = y / gcv_l_normy;
  q_y = K' * p_y;
  gcv_l_gamma_y (1) = norm (q_y, 2);
  gcv_l_normKTy = gcv_l_gamma_y (1) * gcv_l_normy;
  if abs (gcv_l_gamma_y (1)) <= bidiag_tol
   fprintf (1, 'MMQ_LANCZOS_BK: || K'' y || <= c * eps * || y ||\n');
   mu=0;
   success = 1;
   return;
  else % if abs
   q_y = q_y / gcv_l_gamma_y (1);
   by(1,1)=gcv_l_gamma_y(1);
   p_y = K * q_y - gcv_l_gamma_y (1) * p_y;
   gcv_l_delta_y (1) = norm (p_y, 2);
   if abs (gcv_l_delta_y (1)) <= bidiag_tol
    bidiag_y = 0;
    fprintf (1, 'MMQ_LANCZOS_BK: bidiag_y = 0\n');
   else
    p_y = p_y / gcv_l_delta_y (1);
    by(2,1)=gcv_l_delta_y(1);
   end
   
   k_y = 1;
  end % if abs
  
 else % if k_y
  q_y = K' * p_y - gcv_l_delta_y (k_y) * q_y;
  gcv_l_gamma_y (k_y+1) = norm (q_y, 2);
  if abs (gcv_l_gamma_y (k_y+1)) <= bidiag_tol
   gcv_l_gamma_y = gcv_l_gamma_y (1:k_y);
   bidiag_y = 0;
   fprintf (1, 'MMQ_LANCZOS_BK: bidiag_y = 0\n');
  else
   k_y = k_y + 1;
   q_y = q_y / gcv_l_gamma_y (k_y);
   by(k_y,k_y)=gcv_l_gamma_y(k_y);
   p_y = K * q_y - gcv_l_gamma_y (k_y) * p_y;
   gcv_l_delta_y (k_y) = norm (p_y, 2);
   if abs (gcv_l_delta_y (k_y)) <= bidiag_tol
    bidiag_y = 0;
    fprintf (1, 'MMQ_LANCZOS_BK: bidiag_y = 0\n');
   else
    p_y = p_y / gcv_l_delta_y (k_y);
    by(k_y+1,k_y)=gcv_l_delta_y(k_y);
   end
  end
  
  [U_y,S_y,V_y]=svd(full(by(1:k_y+1,1:k_y)));
  S_y=diag(S_y);
  S_y2=S_y.^2;
  
  f=U_y(1,:);
  f=S_y.*f(1:k_y)';
  muc=gcv_l_normy^2*sum(f.^2./(S_y2+nu));
  mu=sqrt(muc/nx2);
  mueps=abs(mu-mu_old)/mu;
  mu_old=mu;
 end % if k_y
 
 if mueps <= 1e-6
  success=1
 end
 end_of_Lanczos = (~bidiag_y | k_y >= kmax | mueps <= 1e-6);
end
iter=k_y;

toc

if success
 % display results
 fprintf (1, '\n');
 fprintf (1, 'MMQ_LANCZOS_BK: mu = %11.4e\n', mu);
 fprintf (1, '%4i Lanczos iterations\n\n', iter);
end