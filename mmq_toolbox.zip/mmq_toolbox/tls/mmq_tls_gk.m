function [s_tls,s_tls2,itsec,itsecmin,itsecmax]=mmq_tls_gk(K,y,epsi);
%MMQ_TLS_GK Golub-Kahan bidiagonalization of K
% computes also the smallest singular value

% bidiagonalization with y (K' y) as starting vector

end_of_Lanczos=0;
success=0;
bidiag_tol=1e-15;
itmax=500;
kmax=min(itmax,size(K,2));
kmax=100;
bidiag_y=1;
s_tls_old=1;
itsec=0;
itsecmin=realmax;
itsecmax=realmin;

% init 

% Lanczos bidiagonalization II = Bidiag1

normy=norm(y);
ny2=normy^2;
p_y = y / normy;
q_y = K' * p_y;
gamma_y (1) = norm (q_y, 2);
by(1,1)=gamma_y(1);
if abs (gamma_y (1)) <= bidiag_tol
 fprintf (1, 'MMQ_TLS_GK: || K'' y || <= c * eps * || y ||\n');
 success = 1;
 return;
end
q_y = q_y / gamma_y (1);
p_y = K * q_y - gamma_y (1) * p_y;
delta_y (1) = norm (p_y, 2);
by(2,1)=delta_y(1);
if abs (delta_y (1)) <= bidiag_tol
 bidiag_y = 0;
 fprintf (1, 'MMQ_TLS_GK: bidiag_y = 0\n');
else %if
 p_y = p_y / delta_y (1);
end %if abs(delta
k_y=1;

while ~(end_of_Lanczos | success)
 %fprintf (1, 'MMQ_TLS_GK: Lanczos it = %4i\r', k_y+1);
 
 % update bidiagonalization
 
 q_y = K' * p_y - delta_y (k_y) * q_y;
 gamma_y (k_y+1) = norm (q_y, 2);
 if abs (gamma_y (k_y+1)) <= bidiag_tol
  gamma_y = gamma_y (1:k_y);
  bidiag_y = 0;
  fprintf (1, 'MMQ_TLS_GK: bidiag_y = 0\n');
 else
  k_y = k_y + 1;
  q_y = q_y / gamma_y (k_y);
  by(k_y,k_y)=gamma_y(k_y);
  p_y = K * q_y - gamma_y (k_y) * p_y;
  delta_y (k_y) = norm (p_y, 2);
  if abs (delta_y (k_y)) <= bidiag_tol
   bidiag_y = 0;
   fprintf (1, 'MMQ_TLS_GK: bidiag_y = 0\n');
  else %if
   p_y = p_y / delta_y (k_y);
   by(k_y+1,k_y)=delta_y(k_y);
  end %if abs(delta
 end %if abs(gamma
 
 % computation of the SVD of B_k
 [U_y,S_y,V_y]=svd(full(by(1:k_y+1,1:k_y)));
 S_y=diag(S_y(1:k_y,1:k_y));
 S_min=min(S_y);
 S_y=S_y(end:-1:1);
 
 % solve the secular equation with BNS1
 meth='b1';
 %epss=1e-10;
 epss=epsi/10;
 d=[0; S_y.^2];
 e1=zeros(size(U_y,2),1);
 e1(1)=1;
 c=U_y'*e1;
 c=c(end:-1:1);
 % 0 is supposed to be the first pole
 [s_tls_new,its]=mmq_solve_secul_tls(d,c,ny2,epss,meth);
 %fprintf (1, 'MMQ_TLS_GK: secul iterations = %4i\r', its);
 itsec=itsec+its;
 itsecmin=min(itsecmin,its);
 itsecmax=max(itsecmax,its);
 s_tls=sqrt(s_tls_new);
 
 end_of_Lanczos = (~bidiag_y) | (k_y >= kmax+1);
 if abs(s_tls_old-s_tls_new) <= epsi*s_tls_old
  end_of_Lanczos=1;
 else
  s_tls_old=s_tls_new;
  if isnan(s_tls_new)
   end_of_Lanczos=1;
  end
 end
end %while
s_tls2=s_tls_new;

%fprintf (1, 'MMQ_TLS_GK: total secul it = %4i, min = %4i, max = %4i\r', itsec,itsecmin,itsecmax);
