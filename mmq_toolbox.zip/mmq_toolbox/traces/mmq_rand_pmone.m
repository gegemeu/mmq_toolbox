function z=mmq_rand_pmone(n);
%MMQ_RAND_PMONE generate a vector with components 1 and -1 with equal probability
%
% Author G. Meurant
% March 2008
%

x=rand(n,1);
z=ones(n,1);
ind=find(x <= 0.5);
z(ind)=-1;

