function [n,sig,alpha,beta,d]=mmq_test_rhrud_egk_v(N,M,ns,ix);
%MMQ_TEST_RHRUD_EGK_V test for the function mmq_rhrud as in Elhay, Golub and Kautsky
% sliding window through the data
% check at every step and plot
%
% Author G. Meurant
% June 2007
%

[x,w,y,ier]=mmq_pwv(N,ix);
if ier == 1
 error('MMQ_TEST_RHRUD_EGK_V: Unknown problem, abort')
end

% recursively build the solution up to M
sig=abs(w(1));
alpha(1)=x(1);
beta(1)=0;
d(1)=y(1)*sig;
n=1;
for i=1:M-1
 % update
[n,sig,alpha,beta,d]=mmq_rhrud(i,alpha,beta,sig,d,x(i+1),w(i+1),y(i+1),1);
disp('update init rhrud-----------------------')
n
end

alpha=alpha(1:ns);
beta=beta(1:ns-1);
d=d(1:ns);

for k=1:N-M
 disp('*********************************')
 k
 % add a point k+M by updating
 [n,sig,alpha,beta,d]=mmq_rhrud(length(alpha),alpha,beta,sig,d,x(k+M),w(k+M),y(k+M),1);
 disp('update k+M rhrud-----------------------')
 n
 % delete the point k by downdating
 [n,sig,alpha,beta,d]=mmq_rhrud(length(alpha),alpha,beta,sig,d,x(k),w(k),y(k),-1);
 disp('downdate k rhrud-----------------------')
 n
 
 if n ~= ns
  error('MMQ_TEST_RHRUD_EGK_V: cannot downdate correctly, abort')
 end
 %generate directly the solution by updating
 sigr=abs(w(k+1));
alphar(1)=x(k+1);
betar(1)=0;
dr(1)=y(k+1)*sigr;
for i=1:M-1
 % update
[nout,sigr,alphar,betar,dr]=mmq_rhrud(i,alphar,betar,sigr,dr,x(k+i+1),w(k+i+1),y(k+i+1),1);
end
alphar=alphar(1:ns);
betar=betar(1:ns-1);
dr=dr(1:ns);
% differences
err_sig(k)=abs(sig-sigr)/abs(sigr);
if norm(alphar) > 100*eps
 err_alpha(k)=norm(alpha-alphar)/norm(alphar);
else
 err_alpha(k)=0;
end
if norm(betar) > 100*eps
 err_beta(k)=norm(beta-betar)/norm(betar);
else
 err_beta(k)=0;
end
err_d(k)=norm(d-dr)/norm(dr);
disp(' err_sig err_alpha err_beta err_d:')
[err_sig(k) err_alpha(k) err_beta(k) err_d(k)]
end

% plot
plot(log10(err_sig))
hold on
plot(log10(err_alpha),'--')
plot(log10(err_beta),'-.')
plot(log10(err_d),':')
legend('err sig','err alpha','err beta','err d')
title('Rhrud: relative errors in sliding')
hold off






