function x = mmq_gcv_l_LocalMin (f, a, b);
%MMQ_GCV_L_LOCALMIN locates a local minimum of f
%
% Author Urs von Matt
%
% The call
%
%     x = gcv_l_LocalMin (f, a, b)
%
% determines a local minimizer of f in the interval [a, b].  The
% statement
%
%     [fx, dfx] = feval (f, x)
%
% must evaluate  fx = f (x)  and the derivative  dfx = f' (x)
%
% It is also required that
%     a <= b
%     f' (a) <= 0  or  f (a) > f (b)
%     f' (b) > 0  or  f (a) <= f (b)
%

global gcv_func_min gcv_func_max

if a > b
 error ('MMQ_GCV_L_LOCALMIN: a > b');
end
if a == b
 x = a;
 return;
end

% a < b
[fa, dfa] = feval (f, a);
[fb, dfb] = feval (f, b);
gcv_func_min=gcv_func_min+2;

if (dfa > 0) & (fa <= fb)
 error ('MMQ_GCV_L_LOCALMIN: (f'' (a) > 0) & (f (a) <= f (b))');
end
if (dfb <= 0) & (fa > fb)
 error ('MMQ_GCV_L_LOCALMIN: (f'' (b) <= 0) & (f (a) > f (b))');
end

iter = 0;
while 1
 iter = iter + 1;
 % compute next iterate
 if (dfa < 0) & (dfb > 0) & (rem (iter, 2) == 0)
  % linear interpolation of f'
  x = (a * dfb - b * dfa) / (dfb - dfa);
  if (x <= a) | (x >= b)
   x = (a + b) / 2;
  end
 else
  % bisection
  x = (a + b) / 2;
 end
 if (x <= a) | (x >= b)
  break;
 end
 
 % a < x < b
 [fx, dfx] = feval (f, x);
 gcv_func_min=gcv_func_min+1;
 if dfx <= 0
  if dfb > 0
   a = x;  
   fa = fx;  
   dfa = dfx;
   % dfa <= 0,  dfb > 0
  elseif fx <= fb
   a = x;  
   fa = fx;  
   dfa = dfx;
   % dfa <= 0,  fa <= fb
  else
   % dfb <= 0,  fa <= fb < fx,  dfa <= 0
   b = x;  
   fb = fx;  
   dfb = dfx;
   % dfa <= 0,  fa <= fb,  dfb <= 0
  end
 else
  if dfa <= 0
   b = x;  
   fb = fx;  
   dfb = dfx;
   % dfa <= 0,  dfb > 0
  elseif fx < fa
   b = x;  
   fb = fx;  
   dfb = dfx;
   % fa > fb,  dfb > 0
  else
   % dfa > 0,  fx >= fa > fb,  dfb > 0
   a = x;  
   fa = fx;  
   dfa = dfx;
   % dfa > 0,  fa > fb,  dfb > 0
  end
 end
end
