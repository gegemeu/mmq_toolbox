function [x,w,y,ier,mu0]=mmq_pwv(N,ix);
%MMQ_PWV computes the points, weights and values for examples in
% updating/downdating algorithms
%
% Author G. Meurant
% June 2007
%

mu0=1;
% return code ier
ier=0;

rand('state',0)
% eventually add perturbations to the data
%delta=1e-4*(0.5-rand(N,1));
%delta1=1e-4*(0.5-rand(N,1));
%delta2=1e-4*(0.5-rand(N,1));
j=[1:N]';
% points x, weights w, values y
% no perturbations
delta=zeros(N,1);
delta1=zeros(N,1);
delta2=zeros(N,1);

switch ix
 case 1
  x=-1+2*(j-1)/(N-1)+delta;
  w=1/sqrt(N)+delta1;
  y=1.5+sin(4*x)+delta2;
 case 2
  x=cos((2*(j-1)+1)*pi/(2*N));
  x=sort(x);
  w=1/sqrt(N)+delta1;
  y=sin(4*x)+cos(10*x)+delta2;
 case 3
  x=-1+2*rand(N,1);
  x=sort(x);
  w=1/sqrt(N)+delta1;
  y=1.5+sin(4*x)+delta2;
 case 4
  % Reichel example
  x=-2+4*(j-1)/(N-1)+delta;
  w=1/sqrt(N)+delta1;
  y=exp(x)+delta2;
 case 5
  % Strakos example
  n=N;
  rho=0.9;
  x(1)=0.01;
  x(n)=100;
  for i=2:n-1
   x(i)=x(1)+((i-1)/(n-1))*(x(n)-x(1))*rho^(n-i);
  end
  x=x';
  w=ones(N,1)/sqrt(N);
  y=1.5+sin(4*x);
 case 6
  % laguerre polynomials
  [a,b,mu0]=classicorthopoly('la',N,0,0);
  [x,w]=gaussquadrule(a,b,ones(N,1),mu0,0);
  w=sqrt(w);
  y=1.5+sin(4*x);
 case 7
  % Legendre polynomials
  [a,b,mu0]=classicorthopoly('le',N,0,0);
  [x,w]=gaussquadrule(a,b,ones(N,1),mu0,0);
  w=sqrt(w);
  y=1.5+sin(4*x);
 case 8
  % Chebyshev polynomials (first kind)
  [a,b,mu0]=classicorthopoly('c1',N,0,0);
  [x,w]=gaussquadrule(a,b,ones(N,1),mu0,0);
  w=sqrt(w);
  y=1.5+sin(4*x);
 case 9
  % Gegenbauer polynomials 
  [a,b,mu0]=classicorthopoly('ge',N,1,0);
  [x,w]=gaussquadrule(a,b,ones(N,1),mu0,0);
  w=sqrt(w);
  y=1.5+sin(4*x);
 otherwise
  ier=1;
  error('MMQ_PWV: Unknown problem, exit')
end