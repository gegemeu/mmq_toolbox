function [n,sig,alpha,beta,d]=mmq_test_rhru(N,ix);
%MMQ_TEST_RHRU compute the solution with N points using RHRud
% in updating mode
%
% Author G. Meurant
% June 2007
%

[x,w,y,ier]=mmq_pwv(N,ix);
if ier == 1
 error('MMQ_TEST_RHRU: Unknown problem, abort')
end

% recursively build the solution
sig=abs(w(1));
alpha(1)=x(1);
beta(1)=0;
d(1)=y(1)*sig;
n=1;

for i=1:N-1
 % update with rhrud
 [n,sig,alpha,beta,d]=mmq_rhrud(i,alpha,beta,sig,d,x(i+1),w(i+1),y(i+1),1);
 if n ~= i+1
  disp('MMQ_TEST_RHRU: pb in updating')
  [i n]
 end
end
 