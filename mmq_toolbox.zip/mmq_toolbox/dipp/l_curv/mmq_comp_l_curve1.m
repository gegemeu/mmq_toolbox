function [rho,eta,mu,lambdamin,lambdamax]=mmq_comp_l_curve1(a,y,np);
%MMQ_COMP_L_CURVE1 computes the l-curve 
% computed by using the SVD of a
%
% rho : norm of r
% eta : norm of x
% mu  : values of the parameter
% lambdamin, lambdamax interval of computation
%
% Author G. Meurant
% Feb 2007
%
% compute the SVD

[u,s,v]=svd(a);
s=diag(s);
maxs=max(s);
m=size(a,1);

normK=norm(a,'fro');
% useful range for lambda
lambdamax = maxs^2;
lambdamin = (eps * normK);

a=log10(lambdamin);
b=log10(lambdamax);

n=np;
tt=linspace(a,b,n);

d=u'*y;

for i = 1:n
 
 mmu = 10^tt (i);
 mu(i)=mmu;
 
 % compute the norm of c-Ax using the  singular values of A
 
 t = s.^2 + mmu;
 num=  sum ((mmu*d ./ t).^2);
 
 % norm of x
 
 den=sum((s .* d ./ t).^2);
 
 nri=sqrt(num);
 nxi=sqrt(den);
 
 rho(i)=nri;
 eta(i)=nxi;
 
end