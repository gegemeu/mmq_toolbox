%MMQ_RUN_TEST_GCV test problems for test_gcv
%
% Author Urs von Matt
%

warning off

% Large test problem with exponential singular value distribution.
% (large)

gcase = 1;
m = 2000;
n = 1000;
c = -0.03;
noise = 1E0;
mmq_test_gcv;

pause

% change the noise level
noise = 1E1;
mmq_test_gcv;

pause

noise = 1E2;
mmq_test_gcv;

pause

%% (larger)
m = 20000;
n = 10000;
c = -0.003;
noise = 1E0;
%mmq_test_gcv;

%pause

noise = 1E1;
%mmq_test_gcv;

%pause

noise = 1E2;
%mmq_test_gcv;

%pause

% Test problem: Fredholm integral equation of the first kind
% (regutools/baart)

gcase = 2;
m = 100;
n = 100;
noise = 1E-7;
mmq_test_gcv;

pause

noise = 1E-5;
mmq_test_gcv;

pause

noise = 1E-3;
mmq_test_gcv;

pause

noise = 1E-1;
mmq_test_gcv;

pause

noise = 1E1;
mmq_test_gcv;

pause

% Phillips''s "famous" test problem
% (regutools/phillips)

gcase = 8;
m = 200;
n = 200;
noise = 1E-5;
mmq_test_gcv;

pause

noise = 1E-3;
mmq_test_gcv;

pause

noise = 1E-1;
mmq_test_gcv;

pause

noise = 1E1;
mmq_test_gcv;

pause

% Test problem: one-dimensional image restoration model
% (regutools/shaw)

gcase = 9;
m = 100;
n = 100;
noise = 1E-5;
mmq_test_gcv;

pause

noise = 1E-3;
mmq_test_gcv;

pause

noise = 1E-1;
mmq_test_gcv;

pause

noise = 1E1;
mmq_test_gcv;

pause

% Test problem: computation of the second derivative
% (regutools/deriv2)

gcase = 3;
m = 64;
n = 64;
noise = 1E-1;
mmq_test_gcv;

pause

% Severely ill-posed test problem
% (regutools/foxgood)

gcase = 4;
m = 64;
n = 64;
noise = 1E-1;
mmq_test_gcv;

pause

% Test problem: inverse heat equation
% (regutools/heat)

gcase = 5;
m = 64;
n = 64;
noise = 1E-1;
mmq_test_gcv;

pause
 
% Test problem: inverse Laplace transformation.
% (regutools/ilaplace)

gcase = 6;
m = 64;
n = 64;
noise = 1E-1;
mmq_test_gcv;

pause
 
% Stellar parallax problem with 28 fixed, real observations
% (regutools/parallax)

gcase = 7;
m = 26;  % the number of rows is fixed
n = 26;
noise = 1E-1;
mmq_test_gcv;

pause

% Test problem with a "spiky" solution
% (regutools/spikes)

gcase = 10;
m = 64;
n = 64;
noise = 1E-1;
mmq_test_gcv;

pause

% Test problem: integral equation with no square integrable solution
% (regutools/ursell)

gcase = 11;
m = 64;
n = 64;
noise = 1E-1;
mmq_test_gcv;

pause
 
% Test problem with a discontinuous solution
% (regutools/wing)

gcase = 12;
m = 64;
n = 64;
noise = 1E-1;
mmq_test_gcv;

pause

warning on