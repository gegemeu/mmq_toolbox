function [U,V,C,C_bar,C_hat,C_hatbar]=mmq_Bidiag1a(A,b,l,reorth);
%MMQ_BIDIAG1A Lanczos bidiagonalization algorithm
%
% function [U,V,C,B,BB,VV,sigma,rho]=Bidiag1(A,b,l,reorth) % change to this for BJORCK

% Input: b , A, and l ; where 0<l<n
% Ouput: {u_j}, j=1:l+1 ; U_{l+1}
%        {v_j}, j=1:l; V_{l}
%        {rho(j)}, j=1:l; rho
%        {sigma(j)}, j=1:l; sigma
%        The Cholesky factor, C_l = C

% C is square lower bidiagonal
% C_bar is l+1 x l lower bidiagonal
% C_hat is square lower bidiagonal (obtained from QR of C_bar)
% C_barhat is l x l-1 lower bidiagonal (obtained from C_hat)

%% Initialization
[m,n] = size(A);
sigma(1)=norm(b,2);
U(:,1)=b/sigma(1);
Vtilde(:,1)=A'*U(:,1);
rho(1)=norm(Vtilde(:,1),2);
V(:,1)= Vtilde(:,1)/rho(1);

for j=2:l
 Utilde(:,j)=A*V(:,j-1)-rho(j-1)*U(:,j-1);
 sigma(j)=norm(Utilde(:,j),2);
 U(:,j)=Utilde(:,j)/sigma(j);

 % Reorthonormalization Columns of U
 if reorth == 1,
  for k=1:j-1
   alpha=U(:,k)'*U(:,j); U(:,j)=U(:,j)-alpha*U(:,k);
   normu=norm(U(:,j)); U(:,j)=U(:,j)/normu;
  end
 end

 Vtilde(:,j)=A'*U(:,j)-sigma(j)*V(:,j-1);
 rho(j)= norm(Vtilde(:,j),2);
 V(:,j)=Vtilde(:,j)/rho(j);

 % Reorthonormalization Columns of V
 if reorth==1,
  for k=1:j-1
   alpha=V(:,k)'*V(:,j); V(:,j)=V(:,j)-alpha*V(:,k);
   normu=norm(V(:,j));
   V(:,j)=V(:,j)/normu;
  end
 end
end

Utilde(:,l+1) = A*V(:,l)-rho(l)*U(:,l);
sigma(l+1)=norm(Utilde(:,l+1),2);
U(:,l+1)=Utilde(:,l+1)/sigma(l+1);

C = diag(rho);
for i=2:l
 C(i,i-1)=sigma(i);
end

%FOR BJORCK
C_bar = zeros(l+1,l);
C_bar(1:l,1:l)=C;
C_bar(l+1,l)=sigma(l+1);
temp = A'*U(:,l+1)-sigma(l+1)*V(:,l);
rho(l+1)= norm(temp,2);
BB = zeros(l+1,l+1);
BB(1:l+1,1:l)=C_bar;
BB(l+1,l+1)=rho(l+1);
VV = zeros(n,l+1);
VV(:,1:l)=V;
VV(:,l+1)=temp/rho(l+1);

[QQ,RR] = qr(C_bar,0);
C_hat = RR';
C_hatbar = C_hat(:,1:l-1);

