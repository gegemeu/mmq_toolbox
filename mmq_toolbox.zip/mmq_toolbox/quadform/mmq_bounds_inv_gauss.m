function [bg,bgrl,bgru,bgl]=mmq_bounds_inv_gauss(a,i,kmax,lmin,lmax);
%MMQ_BOUNDS_INV_GAUSS computation of lower and upper bounds of the element (i,i) of the inverse
% of a symmetric matrix a using Lanczos
%
% kmax iterations
% lmin and lmax are the lower and upper bounds for the smallest and largest eigenvalues
%
% it is not very efficient to compute the inverse of the Jacobi matrix
% see mmq_bounds_gauss
%
%  bg :         Gauss
%  bgrl, bgru : Gauss-Radau
%  bgl :        Gauss-Lobatto
%
%  
% Author G. Meurant
% July 2008
%

bg=zeros(kmax,1);
bgrl=zeros(kmax,1);
bgru=zeros(kmax,1);
bgl=zeros(kmax,1);

jj=sparse(kmax,kmax);
n=size(a,1);
ei=zeros(n,1);
ei(i)=1;
x1=zeros(n,1);
x=ei;
gam=0;
ax=a*x;
om=x'*ax;
jj(1,1)=om;
bg(1)=1/om;
r=ax-om*x;
gam2=r'*r;
gam=sqrt(gam2);
x1=x;
x=r/gam;

% Lanczos iterations
if kmax > 1
 for k=2:kmax
  gam1=gam;
  gam21=gam2;
  ax=a*x;
  om=x'*ax;
  jj(k,k)=om;
  jj(k,k-1)=gam;
  jj(k-1,k)=gam;
  r=ax-om*x-gam*x1;
  gam2=r'*r;
  gam=sqrt(gam2);
  x1=x;
  if gam == 0
   error('MMQ_BOUNDS_INV_GAUSS: breakdown')
  end
  x=r/gam;
  
  % Gauss
  ejj=inv(full(jj(1:k,1:k)));
  bg(k)=ejj(1,1);
  
  % Gauss-Radau
  b=zeros(k,1);
  b(k)=gam*gam;
  dmax=(jj(1:k,1:k)-lmin*eye(k))\b;
  omm=lmin+dmax(k);
  del=zeros(1,k);
  del(k)=gam;
  jt=[jj(1:k,1:k) del';del omm];
  ejj=inv(full(jt));
  bgru(k)=ejj(1,1);
  dmin=(jj(1:k,1:k)-lmax*eye(k))\b;
  omm=lmax+dmin(k);
  jt(k+1,k+1)=omm;
  ejj=inv(full(jt));
  bgrl(k)=ejj(1,1);
  
  % Gauss-Lobatto
  bbb=zeros(k,1);
  bbb(k)=1;
  dmin=(jj(1:k,1:k)-lmin*eye(k))\bbb;
  ga=dmin(k);
  dmax=(jj(1:k,1:k)-lmax*eye(k))\bbb;
  gb=dmax(k);
  pol=[1 -ga; 1 -gb];
  yy=pol\[lmin ; lmax];
  omm=yy(1);
  gamm=sqrt(yy(2));
  del=zeros(1,k);
  del(k)=gamm;
  jj1=jj(1:k,1:k);
  jt=[jj1 del';del omm];
  ejj=inv(full(jt));
  bgl(k)=ejj(1,1);
  
 end
end
