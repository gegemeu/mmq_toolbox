function [a,b,mu0]=mmq_corthopolag(swt,n,alpha,beta);
%MMQ_CORTHOPOLAG computes the Jacobi matrix for classical orthogonal
% polynomials for the Anti-Gauss rule
% modification by sqrt(2) of the last non diagonal coefficient

% Author G. Meurant
% March 2008

% compute the Gauss Jacobi matrix
[a,b,mu0]=mmq_classicorthopoly(swt,n,alpha,beta);

% modify the last element in b
b(n-1)=sqrt(2)*b(n-1);
