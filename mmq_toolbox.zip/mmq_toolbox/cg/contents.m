%
% Contents of CG
%
% Conjugate Gradient with estimation of the A_norm of the error
%
% MMQ_CD_BOUNDS_ACC preconditioned conjugate gradient for a symmetric matrix a
% MMQ_CG_BOUNDS_ADAPT conjugate gradient for a matrix a, switch when lmin has converged
% MMQ_CG_BOUNDS_ANORM conjugate gradient with estimates of the A-norm, Gauss and anti-Gauss estimates
% MMQ_INITPREC computes some preconditioners for CG
% MMQ_MAXNZPR maximum number of non zeros per row of a
% MMQ_NORMALIZ symmetrically scales the matrix a with 1's on the diagonal
% MMQ_SOLVEPREC solves M z = r
% MMQ_STAGEST computes  quantities for estimation of the maximum accuracy
% MMQ_STAGESTB computes a quantity for estimation of the maximum accuracy