function x = mmq_gcv_l_GlobalMin_l (f, a, b);
%MMQ_GCV_L_GLOBALMIN_L locates the minimum of the function f
% uses the logarithm with a regular mesh
%
% Author Urs von Matt
% modified by G. Meurant, Dec 2006
%
% The call
%
%     x = gcv_l_GlobalMin (f, a, b)
%
% tries to determine a global minimizer of f in the interval [a, b].  The
% statement
%
%     [fx, dfx] = feval (f, x)
%
% must evaluate  fx = f (x)  and the derivative  dfx = f' (x).
%
% It is also required that
%     0 <= a < b
%
global gcv_func_min gcv_func_max;

if a >= b
  error ('MMQ_GCV_L_GLOBALMIN_L: a >= b');
end

if a < 0
  error ('MMQ_GCV_L_GLOBALMIN_L: a < 0');
end

a=log10(a);
b=log10(b);

% number of samples
n = 300;

t=linspace(a,b,n);
%
% need to ensure that t (k) are distinct!
%

[ft, dft] = feval (f, t);
gcv_func_min=gcv_func_min+n;
[tmp, k] = min (ft);

while 1
  if k == 1
   break
  end
  if ft (k-1) > ft (k)
   break
  end
  k = k - 1;
end
% k == 1  |  f (t (k-1)) > f (t (k))

if dft (k) <= 0
  if k < n
    % f' (t (k)) <= 0,  f (t (k)) <= f (t (k+1))
    x = mmq_gcv_l_LocalMin (f, t (k), t (k+1));
  else  % k == n
    x = b;
  end
else  % f' (t (k)) > 0
  if k == 1
    x = a;
  else  % k > 1
    % f' (t (k)) > 0,  f (t (k-1)) > f (t (k))
    x = mmq_gcv_l_LocalMin (f, t (k-1), t (k));
  end
end

x=10^x;