function [alpha,beta]=mmq_stieltj(x,w);
%MMQ_STIELTJ implements the Stieltjes procedure 
% for orthonormal polynomials and the discrete scalar
% product defined by nodes x_k and weights w_k^2

% this can eventually be implemented in a better way as in Paige's
% version of Lanczos algorithm

%
% Author G. Meurant
% July 2008
%

N=length(x);

if N == 1
  alpha(1)=x(1);
  beta=[];
  return
end
x=x(:);
w=sqrt(w(:));

% init
beta_0=sqrt(mmq_disc_scal_prod(ones(N,1),ones(N,1),w));
% initial polynomial pi_0 at nodes
pi_0=ones(N,1)/beta_0;
xpi_0=x.*pi_0;
alpha(1)=mmq_disc_scal_prod(xpi_0,pi_0,w);
beta(1)=sqrt(mmq_disc_scal_prod(xpi_0,xpi_0,w)-alpha(1)^2);
old_pi=pi_0;
% new_pi = pi_1
new_pi=(x-alpha(1)).*old_pi/beta(1);

for j=2:N
 xnew_pi=x.*new_pi;
 alpha(j)=mmq_disc_scal_prod(xnew_pi,new_pi,w);
 beta(j)=sqrt(mmq_disc_scal_prod(xnew_pi,xnew_pi,w)-alpha(j)^2-beta(j-1)^2);
 % new polynomial values
 pi_j=((x-alpha(j)).*new_pi-beta(j-1)*old_pi)/beta(j);
 old_pi=new_pi;
 new_pi=pi_j;
end
beta=beta(1:N-1);


alpha=alpha(:);
beta=beta(:);