function [c,s,r,u]=mmq_givenshaf(a,b);
%MMQ_GIVENSHAF computes hyperbolic Givens rotation to zero b, E. Anderson version
% and the factorization
%
% The rotation matrix C is 
%  |  c  is |
%  | -is  c |
% but we compute in real arithmetic, a is real and the second element is assumed to be i b
% C is written as
% C = S - 2(u u^H)/(u^H S u)
% S is the signature matrix
% | 1   0 |
% | 0  -1 |
% u is a complex vector
% a must be different from b
%

% Author G. Meurant
% nov 2007

if a == b
 error('MMQ_GIVENSHAF: a=b')
end

if b == 0
 c=sign(a);
 s=0;
 r=abs(a);
elseif a == 0
 c=0;
 s=sign(b);
 r=abs(b);
elseif abs(a) > abs(b)
 t=b/a;
 if 1-t^2 < 0
  error('MMQ_GIVENSHAF: argument of sqrt < 0')
 end
 u=sign(a)*sqrt(1-t^2);
 c=1/u;
 s=t*c;
 r=a*u;
else
 t=a/b;
 if 1-t^2 < 0
  error('MMQ_GIVENSHAF: argument of sqrt < 0')
 end
 u=sign(b)*sqrt(1-t^2);
 s=1/u;
 c=t*s;
 r=b*u;
end

% factorize the hyperbolic rotation, C - S is rank one
ii=sqrt(-1);
cc=sqrt((c-1)/2);
if cc ~= 0
 u=[cc; -ii*s/(2*cc)];
else
 error('MMQ_GIVENSHAF: cc is zero')
end



