function [S_min,it]=mmq_solve_dich_trid(s_min,Jk,alpha,beta,epss);
%MMQ_SOLVE_DICH_TRID solves the tridiagonal secular equation for the smallest eigenvalue
% x - alpha + beta^2 'e_k T inv(Jk-xI) e_k = 0
% s_min is the leftmost pole
% Dichotomy algorithm

%
% Author G. Meurant
% aug 2007
%
x_old=s_min;
yx=secultr(Jk,alpha,beta,x_old);
%yx=1;

xl=x_old;
xr=x_old;
it=0;
it=it+1;
for i=1:10
  xl=0.9*xl;
  yl=secultr(Jk,alpha,beta,xl);
  if yx*yl < 0
    xr=x_old;
    yr=yx;
    break
  end
  %xr=1.1*xr;
  %yr=secultr(Jk,alpha,beta,xr);
  %if yx*yr < 0
  %  xl=x_old;
  %  yl=yx;
  %  break
  %end
end
if xl > 0
  xl=0;
end
if it >= 10
  disp('MMQ_SOLVE_DICH_TRID: no interval found')
  return
end

itmax=50;
sc=1;
it=0;

while it <= itmax & sc > epss
  it=it+1;
  xm=(xl+xr)/2;
  ym=secultr(Jk,alpha,beta,xm);
  if yl*ym < 0
    xr=xm;
  else
    xl=xm;
  end
  sc=abs(xr-xl)/abs((xr+xl)/2);
end
S_min=(xl+xr)/2;
if it >= itmax
  disp('MMQ_SOLVE_DICH_TRID: no conv mmq_solve_dich_trid')
end

 
function [yx]=secultr(Jk,alpha,beta,x);
%SECULTR function f
%
k=size(Jk,1);

% solve (Jk - xI) y = e_k
ek=zeros(k,1);
ek(k)=1;
y=(Jk-x*speye(k,k))\ek;

beta2=beta^2;
yx=x-alpha+beta2*y(k);
