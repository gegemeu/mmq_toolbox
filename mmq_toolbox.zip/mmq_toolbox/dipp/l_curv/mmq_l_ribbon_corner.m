function [mul,muu]=mmq_l_ribbon_corner(a,y,kmax);
%MMQ_L_RIBBON_CORNER computes the corners of the L-ribbon approximations
% after kmax iterations
% find the corner by rotations
%
% Lanczos bidiagonalization to compute lower and upper bounds of the L-curve
% without reorthogonalization
%
% Author G. Meurant
% Feb 2007
%

ny=norm(y);
naty=norm(a'*y);

% compute the exact L-curve and the limits

np=50;
[rho,eta,mu,lambdamin,lambdamax]=mmq_comp_l_curve1(a,y,np);

% start the Lanczos iterations
% similar to l_bidiagaat

k=kmax;
c=sparse(k+1,k+1);

% init
u_old=y/norm(y);
w=a'*u_old;
c(1,1)=norm(w);
v_old=w/c(1,1);

for i=2:k+1
 w=a*v_old-c(i-1,i-1)*u_old;
 c(i,i-1)=norm(w);
 u=w/c(i,i-1);
 
 w=a'*u-c(i,i-1)*v_old;
 c(i,i)=norm(w);
 v=w/c(i,i);
 
 u_old=u;
 v_old=v;
 
end

i=k+1;

cc=c(1:i-1,1:i-1);
ccb=c(1:i,1:i-1);
[q,cch]=qr(full(ccb),0);
if any(diag(cch) < 0)
 cch=-cch;
end
cch=cch';
% remove the last column
cchb=cch(:,1:end-1);

% compute the approximations using SVDs rather than
% solving least squares problems
[ucc,scc,vcc]=svd(full(cc));
scc=diag(scc);
[uccb,sccb,vccb]=svd(full(ccb));
sccb=diag(sccb);
[ucch,scch,vcch]=svd(full(cch));
scch=diag(scch);
[ucchb,scchb,vcchb]=svd(full(cchb));
scchb=diag(scchb);

al=log10(lambdamin);
bl=log10(lambdamax);
au=al;
bu=bl;

% locate the minimums in a few passes

% t refers to values of log(lambda)
n=25;
ipass=3;
iter=0;
fail=0;

while ipass > 0
 iter=iter+1;
 ipass=ipass-1;
 if n <= 0
  disp('MMQ_L_RIBBON_CORNER: failure, n=0')
  fail=1;
  break
 end
 tl=linspace(al,bl,n);
 tu=linspace(au,bu,n);
 tll=10.^tl;
 tuu=10.^tu;
 
 gcc=mmq_comp_l_ribbon(tll,ucc,scc,vcc);
 lbr=ny^2*tll.^2.*gcc;
 
 gccb=mmq_comp_l_ribbon(tuu,uccb,sccb,vccb);
 ubr=ny^2*tuu.^2.*gccb;
 
 gcch=mmq_comp_l_ribbon(tll,ucch,scch,vcch);
 lbx=naty^2*gcch;
 
 gcchb=mmq_comp_l_ribbon(tuu,ucchb,scchb,vcchb);
 ubx=naty^2*gcchb;
 
 lbr=log10(sqrt(lbr));
 ubr=log10(sqrt(ubr));
 lbx=log10(sqrt(lbx));
 ubx=log10(sqrt(ubx));
 
 % locate the origins (in log scale)
 
 originl=mmq_l_origin(lbr,lbx);
 originu=mmq_l_origin(ubr,ubx);
 
 % change the origin
 
 lbr=lbr-originl(1);
 lbx=lbx-originl(2);
 ubr=ubr-originu(1);
 ubx=ubx-originu(2);
 
 % rotate by -pi/4
 
 [lnr,lnx]=mmq_rotat(lbr,lbx,-pi/4);
 [unr,unx]=mmq_rotat(ubr,ubx,-pi/4);
 
 [tmp, kl] = min (lnx);
 [tmp, ku] = min (unx);
 
 if kl == 1
  % the min is on the boundary
  kkl=mmq_angled(lbr,lbx);
  if kkl == 0
   error('MMQ_L_RIBBON_CORNER: unable to find the corner')
  end
  if kkl == 1
   bl=tl(2);
  elseif kkl == n
   al=tl(n-1);
  else
   al=tl(kkl-1);
   bl=tl(kkl+1);
  end
  
 elseif kl == n
  % the min is on the boundary
  kkl=mmq_angled(lbr,lbx);
  if kkl == 0
   error('MMQ_L_RIBBON_CORNER: unable to find the corner')
  end
  if kkl == 1
   bl=tl(2);
  elseif kkl == n
   al=tl(n-1);
  else
   al=tl(kkl-1);
   bl=tl(kkl+1);
  end
  
 else
  % for the next pass look in the interval enclosing the min
  al=tl(kl-1);
  bl=tl(kl+1);
 end
 
 if ku == 1
  % the min is on the boundary
  kku=mmq_angled(ubr,ubx);
  if kku == 0
   error('MMQ_L_RIBBON_CORNER: unable to find the corner')
  end
  if kku == 1
   bu=tu(2);
  elseif kku == n
   au=tu(n-1);
  else
   au=tu(kkl-1);
   bu=tu(kkl+1);
  end
  
 elseif ku == n
  % the min is on the boundary
  kku=mmq_angled(ubr,ubx);
  if kku == 0
   error('MMQ_L_RIBBON_CORNER: unable to find the corner')
  end
  if kku == 1
   bu=tu(2);
  elseif kku == n
   au=tu(n-1);
  else
   au=tu(kku-1);
   bu=tu(kku+1);
  end
  
 else
  % for the next pass look in the interval enclosing the min
  au=tu(ku-1);
  bu=tu(ku+1);
 end
end

if fail == 1
 mul=0;
 muu=0;
else
 % the corner is given by the corresponding value of t
 mul=tl(kl);
 mul=10^mul;
 muu=tu(ku);
 muu=10^muu;
end




