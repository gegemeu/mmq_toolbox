%MMQ_RUN_TEST_GCV_LARGE1 run GCV for the large von Matt problem
%
% Author G. Meurant 
% Aug 2008
%

warning off

% Large test problem with exponential singular value distribution

gcase=0;
m = 2000;
n = 1000;
c=-0.025;


noise = 1e-3;
mmq_test_gcv;

pause

noise = 1;
mmq_test_gcv;

pause

warning on