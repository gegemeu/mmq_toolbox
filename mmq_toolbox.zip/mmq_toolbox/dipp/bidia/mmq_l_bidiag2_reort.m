function ch=mmq_l_bidiag2_reort(a,y,k);
%MMQ_L_BIDIAG2_REORT compute the Lanczos bidiagonalization (with reorthogonalization)
% on A' A and a right hand side A'y
% as in von Matt and Golub paper
%
% this is Lanczos bidiagonalization II = bidiag 1
% computes a lower bidiagonal matrix ch
% ch is k+1 x k
%
% Author G. Meurant
% July 2008
%

ch=sparse(k+1,k);

% init
u_old=y/norm(y);
w=a'*u_old;
ch(1,1)=norm(w);
v_old=w/norm(w);
w=a*v_old-ch(1,1)*u_old;
ch(2,1)=norm(w);
u_old=w/ch(2,1);
U=zeros(size(u_old,1),k);
V=zeros(size(v_old,1),k);
U(:,1)=u_old;
V(:,1)=v_old;

for i=2:k
 w=a'*u_old-ch(i,i-1)*v_old;
 ch(i,i)=norm(w);
 v=w/ch(i,i);
 % reorthogonalize v
 for j=1:i-1
  alp=V(:,j)'*v;
  v=v-alp*V(:,j);
  v=v/norm(v);
 end
 for j=1:i-1
  alp=V(:,j)'*v;
  v=v-alp*V(:,j);
  v=v/norm(v);
 end
 V(:,i)=v;
 
 w=a*v-ch(i,i)*u_old;
 ch(i+1,i)=norm(w);
 u=w/ch(i+1,i);
 % reorthogonalize u
 for j=1:i-1
  alp=U(:,j)'*u;
  u=u-alp*U(:,j);
  u=u/norm(u);
 end
 for j=1:i-1
  alp=U(:,j)'*u;
  u=u-alp*U(:,j);
  u=u/norm(u);
 end
 U(:,i)=u;
 
 u_old=u;
 v_old=v;
end
