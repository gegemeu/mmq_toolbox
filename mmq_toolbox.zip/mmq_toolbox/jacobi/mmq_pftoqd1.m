function [q,e,e0,alpha,beta]=mmq_pftoqd1(t,w);
%MMQ_PFTOQD1 computes the augmented QD row of a partial fraction
% given by the points t and the weights w
% without shift, assume that the points are positive
% from Laurie's paper

% Author G. Meurant
% June 2007
%

n=length(t);

alpha(1)=t(n);
beta=[];
if n == 1
  q=0;
  e=0;
  e0=0;
 return
end

% sort the points and compute the differences
[t,ind]=sort(t);
if t(1) < 0
 error('MMQ_PFTOQD1: The points must be positive')
end
w=w(ind);
if size(t,1) ~= 1
 t=t';
end
t=[0 t];
sig=t(2:end)-t(1:end-1);

if size(w,1) ~= 1
 w=w';
end
Q=[w zeros(1,n)];
k=n+1;
Q(k)=sig(n);

for j=n-1:-1:1
 [Q(j:2:k),Q(j+1:2:k)]=dqds(Q(j:2:k),Q(j+1:2:k),0);
 [Q(j+1:2:k+1),Q(j+2:2:k+1)]=dstqd(Q(j+1:2:k+1),Q(j+2:2:k+1),-sig(j));
 k=k+1;
end

q=Q(2:2:2*n);
e=Q(3:2:2*n-1);
e0=Q(1);
alpha(1)=q(1);
alpha(2:n)=q(2:n)+e(1:n-1);
beta(1:n-1)=sqrt(q(1:n-1).*e(1:n-1));
