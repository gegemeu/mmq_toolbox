function [gamma,alpha,eta,mu0]=mmq_modifcheb(m,modm,pi0,symm,b,a,c,p0);
%MMQ_MODIFCHEB modified Chebyshev algorithm for general orthogonal polynomials
% m order of the tridiagonal matrix, modm 2m modified moments 
% b, a, c coefficients of the known orthogonal polynomials p_k
% p0 (pi0) constant value of the polynomial p_0 (pi_0)
%
% ouptut gamma, alpha, eta coefficients of the unknown orthogonal polynomials
%        mu0 moment of order 0 = integral of 1
%
% Author G. Meurant
% March 2008
%

if size(modm,2) == 1
 modm=modm';
end
if m > size(modm,2)/2
 m=size(modm,2)/2;
end

if nargin < 5
 % Chebyshev algorithm
 b=ones(2*m,1);
 a=zeros(2*m,1);
 c=a;
 p0=1;
end
gamma=zeros(m,1);
alpha=gamma;
eta=gamma;

alpha(1)=a(1)+b(1)*modm(2)/modm(1);
mu0=modm(1)/p0;

if m == 1
 return
end

% init of the mixed moments
sig(1,1:2*m)=0; 
sig(2,:)=pi0*modm(1:2*m);

% mixed moments
for k=1:m-1
 kt=k+2;
 if k == 1
  mm=k;
  mt=mm+1;
  sq=b(mm+1)*sig(kt-1,mt+1)-(alpha(k)-a(mm+1))*sig(kt-1,mt) ...
   +c(mm)*sig(kt-1,mt-1);
  if symm == 1
   % if ssq > 0 we compute a symmetric matrix
   ssq=b(k)*sq/sig(kt-1,kt-2);
   if ssq > 0
    gamma(k)=sqrt(ssq);
   else
    error('MMQ_MODIFCHEB: ssq < 0, Abort')
   end
   
  else % if symm
   % monic polynomials
   gamma(k)=1;
  end % if symm
  sig(kt,mt)=sq/gamma(k);
  for mm=k+1:2*m-k-1
   mt=mm+1;
   sig(kt,mt)=(b(mm+1)*sig(kt-1,mt+1)-(alpha(k)-a(mm+1))*sig(kt-1,mt) ...
    +c(mm)*sig(kt-1,mt-1))/gamma(k);
  end % for mm
  
 else % k == 1
  mm=k;
  mt=mm+1;
  sq=b(mm+1)*sig(kt-1,mt+1)-(alpha(k)-a(mm+1))*sig(kt-1,mt) ...
   -eta(k-1)*sig(kt-2,mt)+c(mm)*sig(kt-1,mt-1);
  if symm == 1
   % if ssq > 0 we compute a symmetric matrix
   ssq=b(k)*sq/sig(kt-1,kt-2);
   if ssq > 0
    gamma(k)=sqrt(ssq);
   else
    error('MMQ_MODIFCHEB: ssq < 0, Abort')
   end
   
  else % if symm
   % monic polynomials
   gamma(k)=1;
  end % if symm
  sig(kt,mt)=sq/gamma(k);
  for mm=k+1:2*m-k-1
   mt=mm+1;
   sig(kt,mt)=(b(mm+1)*sig(kt-1,mt+1)-(alpha(k)-a(mm+1))*sig(kt-1,mt) ...
    -eta(k-1)*sig(kt-2,mt)+c(mm)*sig(kt-1,mt-1))/gamma(k);
  end
  
 end
 
 alpha(k+1)=a(k+1)+b(k+1)*sig(kt,kt)/sig(kt,kt-1)-b(k)*sig(kt-1,kt-1)/sig(kt-1,kt-2);
 eta(k)=b(k)*sig(kt,kt-1)/sig(kt-1,kt-2);
 
end
gamma=gamma(1:m-1);
eta=eta(1:m-1);

