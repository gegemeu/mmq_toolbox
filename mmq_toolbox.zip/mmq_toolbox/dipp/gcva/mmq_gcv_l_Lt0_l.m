function [lt0, dlt0] = mmq_gcv_l_Lt0_l (lambda);
%MMQ_GCV_L_LT0_L computes the lower bound of the GCV function
% computes the log of the function
%
% Author Urs von Matt
% modified by G. Meurant, Dec 2006
%
% The statement
%
%     [lt0, dlt0] = gcv_l_Lt0 (lambda)
%
% evaluates the function  Lt0 (lambda)  and its derivative:
%
%     lt0 = Lt0 (lambda)
%
%               d
%     dlt0 = ------- Lt0 (lambda)
%            dlambda
%

%
% communication among
% mmq_gcv_lanczos, mmq_gcv_l_Bounds, mmq_gcv_l_Lt0, mmq_gcv_l_Lt1,
% mmq_gcv_l_Ut0, mmq_gcv_l_Ut1, mmq_test_gcv_Vt
%
global gcv_l_m gcv_l_n gcv_l_normy gcv_l_normK gcv_l_normKTy ...
       gcv_l_u gcv_l_normu ...
       gcv_l_gamma_y gcv_l_delta_y gcv_l_gamma_u gcv_l_delta_u;

n_y = length (gcv_l_gamma_y);
if length (gcv_l_delta_y) ~= n_y
  error ('MMQ_GCV_L_LT0_L: length (gcv_l_delta_y) ~= n_y');
end

n_u = length (gcv_l_gamma_u);
if (n_u > 1) & (length (gcv_l_delta_u) ~= n_u - 1)
  error ('MMQ_GCV_L_LT0_L: length (gcv_l_delta_u) ~= n_u - 1');
end

[m_lambda, n_lambda] = size (lambda);
lt0 = zeros (m_lambda, n_lambda);
dlt0 = zeros (m_lambda, n_lambda);
N = m_lambda * n_lambda;

m = gcv_l_m;
n = gcv_l_n;

lambda=10.^lambda;

for i = 1:N
  if lambda (i) <= 0
   error ('MMQ_GCV_L_LT0_L: lambda (i) <= 0');
  end
  mu = m * lambda (i);

  % compute \tilde{U}_k
  [Q, u, v] = lbidiagQR (gcv_l_gamma_y, gcv_l_delta_y, 0);
  u (n_y) = 0;

  [Q, u, v] = ubidiagQR (u, v, sqrt (mu));
  xi = lbidiagSolve (u, v, eye (n_y, 1));
  b = [zeros(n_y,1); eye(n_y,1)];
  b = ubidiagQTx (Q, b);
  eta = ubidiagSolve (u, v, b (1:n_y));
  num = gcv_l_normy^2 - (gcv_l_normKTy * norm ([xi; eta], 2))^2;
  zeta = lbidiagSolve (u, v, eta);
  nump = 2 * m * (gcv_l_normKTy * norm (zeta, 2))^2;

  tmp = gcv_l_gamma_u (n_u);
  gcv_l_gamma_u (n_u) = 0;
  [Q, u, v] = ubidiagQR (gcv_l_gamma_u, gcv_l_delta_u, sqrt (mu));
  b = [zeros(n_u,1); eye(n_u,1)];
  b = ubidiagQTx (Q, b);
  xi = ubidiagSolve (u, v, b (1:n_u));
  den = (m - n) + gcv_l_normu^2 * sqrt (mu) * xi (1);
  [Q, u, v] = lbidiagQR (gcv_l_gamma_u, [gcv_l_delta_u(:); 0], sqrt (mu));
  b = lbidiagQTx (Q, eye (2*n_u+1, 1));
  eta = ubidiagSolve (u, v, b (1:n_u));
  denp = m * (gcv_l_normu * norm (eta, 2))^2;
  gcv_l_gamma_u (n_u) = tmp;

  lt0i = m * num / den^2;
  % we are not interested in negative values
  if lt0i < 0
   lt0i=10*realmin;
  end
  lt0(i)=log10(lt0i);
  dlt0i = m * (nump / den^2 - 2 * num * denp / den^3);
  dlt0(i)=dlt0i/lt0i;
end
