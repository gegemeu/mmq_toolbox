function [n,sig,alpha,beta,d]=mmq_test_tldudsfus(N,ix);
%MMQ_TEST_TLDUDSFUS test for the function mmq_tldudsfus
% update from 1 to N and then downdate one point at a time
%
% Author G. Meurant
% May 2007
%

[x,w,y,ier]=mmq_pwv(N,ix);
if ier == 1
 error('MMQ_TEST_TLDUDSFUS: Unknown problem, abort')
end

% recursively build the solution
sig=abs(w(1));
alpha(1)=x(1);
beta(1)=0;
d(1)=y(1)*sig;
n=1;
sigup=zeros(1,N);
alphaup=zeros(N,N);
betaup=zeros(N,N-1);
dup=zeros(N,N);
sigup(1)=sig;
alphaup(1,1)=alpha(1);
dup(1)=d(1);
nup(1)=1;

% reference solution
sigref=abs(w(1));
alpharef(1)=x(1);
betaref(1)=0;
dref(1)=y(1)*sig;
sigupref=zeros(1,N);
alphaupref=zeros(N,N);
betaupref=zeros(N,N-1);
dupref=zeros(N,N);
sigupref(1)=sig;
alphaupref(1,1)=alpha(1);
dupref(1)=d(1);
nupref(1)=1;
n=1;
for i=1:N-1
 % update
[n,sigref,alpharef,betaref,dref]=mmq_rhrud(i,alpharef,betaref,sigref,dref,x(i+1),w(i+1),y(i+1),1);
if n ~= i+1
 disp('MMQ_TEST_TLDUDSFUS: pb in rhrud updating')
 [i n]
end
nupref(n)=n;
sigupref(n)=sigref;
alphaupref(n,:)=[alpharef zeros(1,N-i-1)];
betaupref(n,:)=[betaref zeros(1,N-i-1)];
dupref(n,:)=[dref zeros(1,N-i-1)];
disp('update ref using rhrud-----------------------')
n
end

n=1;
for i=1:N-1
 % update
 [n,sig,alpha,beta,d]=mmq_tldudsfus(i,alpha,beta,sig,d,x(i+1),w(i+1),y(i+1),1);
 disp('update tldudsfus-----------------------')
 n
 if n ~= i+1
  disp('MMQ_TEST_TLDUDSFUS: pb in  tldudsfus updating')
  [i n]
 end
 nup(n)=n;
 sigup(n)=sig;
 alphaup(n,:)=[alpha zeros(1,N-i-1)];
 betaup(n,:)=[beta zeros(1,N-i-1)];
 dup(n,:)=[d zeros(1,N-i-1)];
 err_sigref=abs(sig-sigupref(n))/sigupref(n)
 err_sigiref(n)=err_sigref;
 err_alpharef=norm(alpha-alphaupref(n,1:n))/norm(alphaupref(n,1:n))
 err_alphairef(n)=err_alpharef;
 if norm(betaupref(n,1:n-1)) >0
  err_betaref=norm(beta-betaupref(n,1:n-1))/norm(betaupref(n,1:n-1))
  err_betairef(n)=err_betaref;
 end
 err_dref=norm(d-dupref(n,1:n))/norm(dupref(n,1:n))
 err_dief(n)=err_dref;
 disp(' err_sig err_alpha err_beta err_d:')
 [err_sigref err_alpharef err_betaref err_dref]
end

n=N;
for i=N:-1:2
 % downdate
 [nout,sig,alpha,beta,d]=mmq_tldudsfus(n,alpha,beta,sig,d,x(n),w(n),y(n),-1);
 disp('downdate tldudsfus-----------------------')
 nout
 if nout ~= n-1
  disp('MMQ_TEST_TLDUDSFUS: cannot downdate correctly')
  [n nout]
  return
 else
  n=nout;
 end
 err_sig=abs(sig-sigup(n))/sigup(n)
 err_sigi(nout)=err_sig;
 err_alpha=norm(alpha-alphaup(n,1:n))/norm(alphaup(n,1:n))
 err_alphai(nout)=err_alpha;
 if norm(betaup(n,1:n-1)) >0
  err_beta=norm(beta-betaup(n,1:n-1))/norm(betaup(n,1:n-1))
  err_betai(nout)=err_beta;
 end
 err_d=norm(d-dup(n,1:n))/norm(dup(n,1:n))
 err_di(nout)=err_d;
 disp(' err_sig err_alpha err_beta err_d:')
 [err_sig err_alpha err_beta err_d]
end
 
% plot
figure
plot(log10(err_sigi))
hold on
plot(log10(err_alphai),'--')
plot(log10(err_betai),'-.')
plot(log10(err_di),':')
legend('err sig','err alpha','err beta','err d')
title('Tldudsfus: relative errors in downdating')
hold off
