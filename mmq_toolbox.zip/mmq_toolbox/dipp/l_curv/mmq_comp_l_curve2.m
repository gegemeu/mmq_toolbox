function [rho,eta,mu,err,lambdamin,lambdamax]=mmq_comp_l_curve2(u,s,v,y,np,x0);
%MMQ_COMP_L_CURVE2 computes the l-curve using the SVD of a
%
% Author G. Meurant
% Feb 2007
%
maxs=max(s);
m=size(u,1);

normK=maxs;
% useful range for lambda
lambdamax = maxs^2;
lambdamin = (eps * normK);

a=log10(lambdamin);
b=log10(lambdamax);

n=np;
tt=linspace(a,b,n);

d=u'*y;

for i = 1:n
 
 mmu = 10^tt (i);
 mu(i)=mmu;
 
 % compute the norm of c-Ax using the  singular values of A
 
 t = s.^2 + mmu;
 num=  sum ((mmu*d ./ t).^2);
 
 % norm of x
 
 den=sum((s .* d ./ t).^2);

 nri=sqrt(num);
 nxi=sqrt(den);
 
 rho(i)=nri;
 eta(i)=nxi;
 
 sol=mmq_solipp1(mmu,u,s,v,y);
 err(i)=norm(sol-x0);
 
end