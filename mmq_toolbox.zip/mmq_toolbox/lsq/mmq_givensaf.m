function [c,s,r,u,v]=mmq_givensaf(a,b);
%MMQ_GIVENSAF computes Givens rotation to zero b, E. Anderson version
% and the factorization
%
% The rotation matrix C is 
%  |  c  s |
%  | -s  c |
%
% C is written as C = S - 2(u v^T)/(u^T S v)
% S is a signature matrix
% | 1   0 |
% | 0  -1 |
% u and v are vectors, v_1 = u_1, v_2 = -u_2
%

% Author G. Meurant
% nov 2007

if b == 0
 c=sign(a);
 s=0;
 r=abs(a);
elseif a == 0
 c=0;
 s=sign(b);
 r=abs(b);
elseif abs(a) > abs(b)
 t=b/a;
 u=sign(a)*sqrt(1+t^2);
 c=1/u;
 s=t*c;
 r=a*u;
else
 t=a/b;
 u=sign(b)*sqrt(1+t^2);
 s=1/u;
 c=t*s;
 r=b*u;
end

% factorize the rotation
cc=sqrt((1-c)/2);
if cc ~= 0
 u=[cc; s/(2*cc)];
 v=u;
 v(2)=-u(2);
else
 error('MMQ_GIVENSAF: cc is zero')
end

