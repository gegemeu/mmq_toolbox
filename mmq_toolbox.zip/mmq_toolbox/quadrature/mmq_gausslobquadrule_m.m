function [t,w]=mmq_gausslobquadrule_m(a,b,mu0,node1,node2);
%MMQ_GAUSSLOBQUADRULE_M computes nodes and weights of the Gauss-Lobatto rule using the Matlab QR algorithm
% a and b are the elements of the diagonal and subdiagonal of the Jacobi
% matrix for the orthonormal polynomials associated with the measure
%

% Author G. Meurant
% June 2007
%

n=length(a);
if n == 1
  t=a(1);
  w=mu0;
  return
end

% modify the last element diagonal element and the last subdiagonal element

% tridiagonal solve of (J_{n-1}- node I) delta = (0 0 ... 1)^T

t=spdiags([b' a(1:n-1)' [0 b(1:n-2)]'], -1:1, n-1, n-1);

e=zeros(n-1,1);
e(n-1)=1;
d1=(t-node1*speye(n-1))\e;
d2=(t-node2*speye(n-1))\e;

x=[1 -d1(n-1); 1 -d2(n-1)]\[node1; node2];

a(n)=x(1);
b(n-1)=sqrt(x(2));

J=diag(a)+diag(b,-1)+diag(b,1); 
J=full(J);
[V,D]=eig(J);
t=diag(D);
[t,i]=sort(t);
w=mu0*V(1,i).^2;
t=t';