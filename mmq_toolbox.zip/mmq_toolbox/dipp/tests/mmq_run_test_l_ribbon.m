%MMQ_RUN_TEST_L_RIBBON test problems for test_l_ribbon
%
% Author G. Meurant
% Feb 2007
%

warning off

% Test problem: Fredholm integral equation of the first kind
% (regutools/baart)

gcase = 2;
m = 100;
n = 100;
noise = 1E-7;
mmq_test_l_ribbon;

pause

noise = 1E-5;
mmq_test_l_ribbon;

pause

noise = 1E-3;
mmq_test_l_ribbon;

pause

noise = 1E-1;
mmq_test_l_ribbon;

pause

noise = 1E1;
mmq_test_l_ribbon;

pause

% Severely ill-posed test problem
% (regutools/foxgood)

gcase = 4;
m = 100;
n = 100;
noise = 1E-7;
mmq_test_l_ribbon;

pause

noise = 1E-5;
mmq_test_l_ribbon;

pause

noise = 1E-3;
mmq_test_l_ribbon;

pause

noise = 1E-1;
mmq_test_l_ribbon;

pause

noise = 10;
mmq_test_l_ribbon;

pause

% Test problem: inverse Laplace transformation
% (regutools/ilaplace)

gcase = 6;
m = 100;
n = 100;

noise = 1E-5;
mmq_test_l_ribbon;

pause

noise = 1E-3;
mmq_test_l_ribbon;

pause

noise = 1E-1;
mmq_test_l_ribbon;

pause

noise = 10;
mmq_test_l_ribbon;

pause

% Phillips''s "famous" test problem
% (regutools/phillips)

gcase = 8;
m = 200;
n = 200;


noise = 1E-3;
mmq_test_l_ribbon;

pause

noise = 1E-1;
mmq_test_l_ribbon;

pause

noise = 10;
mmq_test_l_ribbon;

pause

% Test problem: one-dimensional image restoration model
% (regutools/shaw)

gcase = 9;
m = 100;
n = 100;

noise = 1E-5;
mmq_test_l_ribbon;

pause

noise = 1E-3;
mmq_test_l_ribbon;

pause

noise = 1E-1;
mmq_test_l_ribbon;

pause

noise = 10;
mmq_test_l_ribbon;







 
