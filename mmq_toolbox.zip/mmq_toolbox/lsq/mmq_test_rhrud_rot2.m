function [n,sig,alpha,beta,d]=mmq_test_rhrud_rot2(N,ix);
%MMQ_TEST_RHRUD_ROT2 test for the function mmq_rhrud_rot2
% update from 1 to N and then downdate one point at a time
% update with mmq_rhrud_rot1, downdating with eigenvectors
%
% Author G. Meurant
% May 2007
%

warning off
[x,w,y,ier]=mmq_pwv(N,ix);
if ier == 1
 error('MMQ_TEST_RHRUD_ROT2: Unknown problem, abort')
end

% recursively build the solution
sig=abs(w(1));
alpha(1)=x(1);
beta(1)=0;
d(1)=y(1)*sig;
n=1;
sigup=zeros(1,N);
alphaup=zeros(N,N);
betaup=zeros(N,N-1);
dup=zeros(N,N);
sigup(1)=sig;
alphaup(1,1)=alpha(1);
dup(1)=d(1);
nup(1)=1;
eigvec=zeros(N,N);
eigvec(1,1)=1;
eigval=zeros(N,1);
eigval(1)=x(1);
cc=zeros(N,N);
ss=zeros(N,N);
n=1;
for i=1:N-1
 % update
 [n,sig,alpha,beta,d,cc,ss,eigvec,eigval]=mmq_rhrud_rot1(i,alpha,beta,sig,d,x(i+1),w(i+1),y(i+1),cc,ss,eigvec,eigval);
 if n ~= i+1
  disp('MMQ_TEST_RHRUD_ROT2: pb in updating')
  [i n]
 end
 nup(n)=n;
 sigup(n)=sig;
 alphaup(n,:)=[alpha zeros(1,N-i-1)];
 betaup(n,:)=[beta zeros(1,N-i-1)];
 dup(n,:)=[d zeros(1,N-i-1)];
 disp('update rhrud_rot1-----------------------')
 n
 ni=n;
 J=spdiags([[beta(1:ni-1)'; 0] alpha(1:ni)' [0; beta(1:ni-1)']], -1:1, ni,ni);
 eigJ=sort(eig(full(J)));
 errJ=abs(sort(x(1:ni))-eigJ)./abs(sort(x(1:ni)));
 err_abs=abs(sort(x(1:ni))-eigJ)'
 err_rel=errJ'
end
 
format long e

n=N;
for i=N:-1:2
 % downdate
 [nout,sig,alpha,beta,d,eigvec,eigval]=mmq_rhrud_rot2d(n,alpha,beta,sig,d,x(i),w(i),y(i),eigvec,eigval,i);
 disp('downdate rhrud_rot2d-----------------------')
 J=spdiags([[betaup(i-1,1:i-2)'; 0] alphaup(i-1,1:i-1)' [0; betaup(i-1,1:i-2)']], -1:1, i-1,i-1);
 %full(J)
 nout
 if nout ~= n-1
  disp('MMQ_TEST_RHRUD_ROT2: cannot downdate correctly')
  [n nout]
  return
 else
  n=nout;
 end
 ni=n;
 J=spdiags([[beta(1:ni-1)'; 0] alpha(1:ni)' [0; beta(1:ni-1)']], -1:1, ni,ni);
 eigJ=sort(eig(full(J)));
 errJ=abs(sort(x(1:ni))-eigJ)./abs(sort(x(1:ni)));
 err_abs=abs(sort(x(1:ni))-eigJ)'
 err_rel=errJ'
 err_sig=abs(sig-sigup(n))/sigup(n);
 err_sigi(nout)=err_sig;
 abs_alpha=abs(alpha-alphaup(n,1:n))
 err_alpha=norm(alpha-alphaup(n,1:n))/norm(alphaup(n,1:n));
 err_alphai(nout)=err_alpha;
 if nout > 1
  abs_beta=abs(beta-betaup(n,1:n-1))
  if norm(betaup(n,1:n-1)) > 0
   err_beta=norm(beta-betaup(n,1:n-1))/norm(betaup(n,1:n-1));
  else
   err_beta=0;
  end
 else
  abs_beta=0;
  err_beta=0;
 end
 err_betai(nout)=err_beta;
 err_d=norm(d-dup(n,1:n))/norm(dup(n,1:n));
 err_di(nout)=err_d;
 disp(' err_sig err_alpha err_beta err_d:')
 [err_sig err_alpha err_beta err_d]
end % for i

% plot
figure
plot(log10(err_sigi))
hold on
plot(log10(err_alphai),'--')
plot(log10(err_betai),'-.')
plot(log10(err_di),':')
legend('err sig','err alpha','err beta','err d')
title('Rhrud-rot2: relative errors in downdating')
hold off
warning on
