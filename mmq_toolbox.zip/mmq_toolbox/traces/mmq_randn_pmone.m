function z=mmq_randn_pmone(n);
%MMQ_RANDN_PMONE generate a vector with components 1 and -1 with equal probability
%
% Author G. Meurant
% March 2008
%

x=randn(n,1);
z=ones(n,1);
ind=find(x <= 0);
z(ind)=-1;

