function [reg_min,G,reg_param] = mmq_gcv(U,s,b);
%MMQ_GCV Plot the GCV function and find its minimum
% coming from an old regutools library
%
% Plots the GCV-function
%
%          || A*x - b ||^2
%    G = -------------------
%        (trace(I - A*A_I)^2
%
% as a function of the regularization parameter reg_param
% Here, A_I is a matrix which produces the regularized solution
%
% If any output arguments are specified, then the minimum of G is
% identified and the corresponding reg. parameter reg_min is returned

% From Per Christian Hansen, UNI-C, 03/16/93.

% modified by Urs von Matt, June 9, 1995

% cleaned by G. Meurant, Dec 2006

plots=0;

% Set defaults
npoints = 200;                      % Number of points on the curve
smin_ratio = 16*eps;                % Smallest regularization parameter

% Initialization
[m,n] = size(U); [p,ps] = size(s);
if norm(U(:,1),2) > 1.2
 % U represents a Householder transformation
 n = p;
end
% beta = U'*b;
if norm(U(:,1),2) > 1.2
 % U represents a Householder transformation
 beta = b - U*(U'*b);
 beta = beta (1:p);
else
 beta = U'*b;
end
beta2 = b'*b - beta'*beta;
if (ps==2)
 s = s(p:-1:1,1)./s(p:-1:1,2);
 beta = beta(p:-1:1);
end
if (nargout > 0)
 find_min = 1;
else
 find_min = 0;
end

reg_param = zeros(npoints,1);
G = reg_param;
s2 = s.^2;
reg_param(npoints) = max([s(p),s(1)*smin_ratio]);
ratio = (s(1)/reg_param(npoints))^(1/(npoints-1));
ratio = 1.2*(s(1)/reg_param(npoints))^(1/(npoints-1));
for i=npoints-1:-1:1
 reg_param(i) = ratio*reg_param(i+1);
end
delta0 = 0;
if (m > n & beta2 > 0)
 delta0 = beta2;
end
for i=1:npoints
 f1 = (reg_param(i)^2)./(s2 + reg_param(i)^2);
 fb = f1.*beta(1:p);
 rho2 = fb'*fb + delta0;
 G(i) = rho2/(m - n + sum(f1))^2;
end

if find_min
 [minG,minGi] = min(G);
 reg_min = reg_param(minGi);
end

if plots == 1
 %[min(reg_param.^2) max(reg_param.^2)]
 figure
 loglog(reg_param.^2,G,'-')
 xlabel('nu')
 ylabel('G(nu)')
 title('GCV function')

 if (find_min)
  HoldState = ishold;
  hold on;
  loglog(reg_min^2,minG,'*',[reg_min^2,reg_min^2],[minG/2,minG],':')
  title(['GCV function, minimum at ',num2str(reg_min^2,3)])
  if (~HoldState)
   hold off;
  end
 end

 figure
 loglog(reg_param,G,'-')
 xlabel('mu')
 ylabel('G(mu)')
 title('GCV function')
 if (find_min)
  HoldState = ishold;
  hold on;
  loglog(reg_min,minG,'*',[reg_min,reg_min],[minG/2,minG],':')
  title(['GCV function, minimum at ',num2str(reg_min,3)])
  if (~HoldState)
   hold off;
  end
 end
end



