function [t,w]=mmq_gaussqr(a,b,muzero);
%MMQ_GAUSSQR  QR algorithm to compute the eigenvalues of a tridiagonal matrix
% given the coefficients (a,b) of the orthogonal polynomials
% p(k)=(a(k) x + b(k)) p(k-1) - c(k) p(k-2)
% computes the abscissas t and the weights w of the Gauss type quadrature
% associated with orthogonal polynomials by QR iteration with shift
%

% Author G. Meurant
% June 2007
%

n=length(a);

a_old=a;
b_old=b;
% find the maximum row sum norm
 ni=n;
 J=spdiags([[b(1:ni-1)'; 0] a(1:ni)' [0; b(1:ni-1)']], -1:1, ni,ni);
 J=abs(J);
 nJ=J*ones(n,1);
 normJ=max(nJ);
 
 w=zeros(1,n);
 w(1)=1;
 % relative zero tolerance
 epss=eps*normJ;
 lambda=normJ; lambda1=lambda; lambda2=lambda; rho=lambda;
 m=n;
 
 inspect=1;
 
 while inspect == 1

  if m == 0
   % sort the abscissas
   [t,ind]=sort(t);
   w=w(ind);
   inspect=0;
   return
  end
  
  i=m-1; k=i; m1=i;
  if m1 >= 1
   if abs(b(m1)) <= epss
    t(m)=a(m);
    w(m)=muzero*w(m)^2;
    rho=min(lambda1,lambda2);
    m=m1;
    continue
   end
  else
   t(1)=a(1);
   w(1)=muzero*w(1)^2;
   m=0;
   continue
  end
  
  % small off diagonal element means the matrix can be split
  for j=i-1:-1:1
   if abs(b(j)) <= epss 
    k=j;
    break
   else
    k=1;
   end
  end
  % find the shift with the eigenvalues of lower 2x2 block
  b2=b(m1)^2;
  det=sqrt((a(m1)-a(m))^2+4*b2);
  aa=a(m1)+a(m);
  if aa > 0
   lambda2=(aa+det)/2;
  else
   lambda2=(aa-det)/2;
  end
  lambda1=(a(m1)*a(m)-b2)/lambda2;
  eigmax=max(lambda1,lambda2);
  if abs(eigmax-rho) <= abs(eigmax)/8
   lambda=eigmax;
   rho=eigmax;
  else
   rho=eigmax;
  end
  
  [a(k:m),b(k:m-1),w(k:m)]=mmq_qrsweep(a(k:m),b(k:m-1),lambda,w(k:m));
  
 end
 
 % eventually recompute the weights by QR with perfect shifts
 
 %w=mmq_qrgauss(t,a_old,b_old,muzero);
 
 