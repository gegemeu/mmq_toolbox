function [ut0, dut0] = mmq_gcv_l_Ut0_l_by (lambda);
%MMQ_GCV_L_UT0_L_BY computes the upper bound of the GCV function
% computes the log of the function
% uses the SVD of B_k
%
% Author  G. Meurant, Jan 2007
%
% The statement
%
%     [ut0, dut0] = gcv_l_Ut0 (lambda)
%
% evaluates the function  Ut0 (lambda)  and its derivative:
%
%     ut0 = Ut0 (lambda)
%
%               d
%     dut0 = ------- Ut0 (lambda)
%            dlambda
%

%
% communication among
% mmq_gcv_lanczos, mmq_gcv_l_Bounds, mmq_gcv_l_Lt0, mmq_gcv_l_Lt1,
% mmq_gcv_l_Ut0, mmq_gcv_l_Ut1, mmq_test_gcv_Vt
%
global gcv_l_m gcv_l_n gcv_l_normy gcv_l_normK gcv_l_normKTy ...
 gcv_l_u gcv_l_normu ...
gcv_l_gamma_y gcv_l_delta_y gcv_l_gamma_u gcv_l_delta_u;

global S_y U_y S_u V_u;

global uyn2;

n_y = length (gcv_l_gamma_y);
if length (gcv_l_delta_y) ~= n_y 
 error ('MMQ_GCV_L_UT0_L_BY: length (gcv_l_delta_y) ~= n_y');
end

n_u = length (gcv_l_gamma_u);
if (n_u > 1) & (length (gcv_l_delta_u) ~= n_u - 1)
 error ('MMQ_GCV_L_UT0_L_BY: length (gcv_l_delta_u) ~= n_u - 1');
end

[m_lambda, n_lambda] = size (lambda);
ut0 = zeros (m_lambda, n_lambda);
dut0 = zeros (m_lambda, n_lambda);
N = m_lambda * n_lambda;

m = gcv_l_m;
n = gcv_l_n;

lambda=10.^lambda;

% SVD of B_y (k+1) x k matrix computed with y
s=S_y;
d=U_y'*eye(n_y+1,1);

for i = 1:N
 if lambda (i) < 0
  error ('MMQ_GCV_L_UT0_L_BY: lambda (i) < 0');
 end
 mu = m * lambda (i);
 
 % compute the numerator using the approximate singular values of B_y
 
 t = s.^2 + mu;
 dny=gcv_l_normy^2*d(n_y+1)^2;
 coeff=1;
 num= gcv_l_normy^2 * sum ((mu*d(1:n_y) ./ t).^2)+coeff*dny;
 nn=mu*d(1:n_y).^2.*s.^2./t.^3;
 nump= 2 * gcv_l_normy^2 * sum(mu*d(1:n_y).^2.*s.^2./t.^3);
 
 % denominator
 
 %den=sum(mu./t);
 %denp=sum(s.^2./t.^2);
 
 % as before right now
 [Q, u, v] = ubidiagQR (gcv_l_gamma_u, gcv_l_delta_u, sqrt (mu));
 b = [zeros(n_u,1); eye(n_u,1)];
 b = ubidiagQTx (Q, b);
 xi = ubidiagSolve (u, v, b (1:n_u));
 den = (m - n) + gcv_l_normu^2 * sqrt (mu) * xi (1);
 [Q, u, v] = lbidiagQR (gcv_l_gamma_u, [gcv_l_delta_u(:); 0], sqrt (mu));
 b = lbidiagQTx (Q, eye (2*n_u+1, 1));
 eta = ubidiagSolve (u, v, b (1:n_u));
 denp = m * (gcv_l_normu * norm (eta, 2))^2;
 
 den2p=den^2;
 if m == n 
  ll=lambda(i);
  %den2p=den2p+min(500,dny/uyn2);
  %den2p=den2p+modcoeff(log10(ll),-40,5)*min(500,dny/uyn2);
  den2p=den2p+gcv_l_normy^2;
 end
 
 ut0i = m * num / den2p;
 ut0(i)=log10(ut0i);
 dut0i = m * (nump / den^2 - 2 * num * denp / den^3);
 dtu0(i)=dut0i/ut0i;
end
