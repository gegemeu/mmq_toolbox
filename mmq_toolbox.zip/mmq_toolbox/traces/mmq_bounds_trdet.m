function [trmin,trmax]=mmq_bounds_trdet(a,lmin,lmax);
%MMQ_BOUNDS_TRDET Golub and Bai bounds for the determinant of a
% using the two first moments mu1, mu2
%
% lmin, lmax are estimates of the smallest and largest eigenvalues of a
%
% Author G. Meurant
% March 2008
%

n=size(a,1);
mu1=trace(a);
mu2=norm(a,'fro')^2;

tub=(lmin*mu1-mu2)/(lmin*n-mu1);
tob=(lmax*mu1-mu2)/(lmax*n-mu1);

matl=[lmin tub; lmin^2 tub^2];
matu=[lmax tob; lmax^2 tob^2];

mu=[log(lmin) log(tub)];
mo=[log(lmax) log(tob)];
n1=[mu1 ; mu2];

trmin=mu*inv(matl)*n1;
trmax=mo*inv(matu)*n1;

trmin=exp(trmin);
trmax=exp(trmax);