function [S_min,it]=mmq_solve_dich_trid1(s_min,Jk,y,ny2,nay2,epss);
%MMQ_SOLVE_DICH_TRID1 solves the tridiagonal secular equation for the Gauss estimate
% x - ny2 + nay2 y^T inv(Jk-xI) y = 0
% s_min is the leftmost pole
% Dichotomy algorithm

%
% Author G. Meurant
% aug 2007
%
x_old=s_min;
yx=1;

xl=x_old;
xr=x_old;
it=0;
it=it+1;
for i=1:20
  xl=0.5*xl;
  yl=secultr(Jk,y,ny2,nay2,xl);
  if yx*yl < 0
    xr=x_old;
    yr=yx;
    break
  end
  %xr=1.1*xr;
  %yr=secultr(Jk,alpha,beta,xr);
  %if yx*yr < 0
  %  xl=x_old;
  %  yl=yx;
  %  break
  %end
end
if xl < 0
  xl=0;
end
if it >= 10
  disp('MMQ_SOLVE_DICH_TRID1: no interval found')
  return
end

itmax=100;
sc=1;
it=0;

while it <= itmax & sc > epss
  it=it+1;
  xm=(xl+xr)/2;
  ym=secultr(Jk,y,ny2,nay2,xm);
  if yl*ym < 0
    xr=xm;
  else
    xl=xm;
  end
  sc=abs(xr-xl)/abs((xr+xl)/2);
end
S_min=(xl+xr)/2;
if it >= itmax
  disp('MMQ_SOLVE_DICH_TRID1: no conv solve_dich_trid1')
end

  
function [yx]=secultr(Jk,yy,ny2,nay2,x);
%SECULTR function f
%
k=size(Jk,1);

% solve (Jk - xI) y = yy
y=(Jk-x*speye(k,k))\yy;
yk1=yy'*y;
yx=x-ny2+nay2*yk1;


