function [alpha,beta]=mmq_convqr(t,w);
%MMQ_CONVQR computes the Jacobi matrix from the nodes t and weights w
% from Laurie's paper

% Author G. Meurant
% June 2007
%

n=length(t);

mu=w(n);
alpha(1)=t(n);
beta=[];

for j=n-1:-1:1
 % augment J by a first column and first row
 alpha=[t(j) alpha];
 beta=[0 beta];
 x=sqrt(w(j));
 z=sqrt(mu);
 % rotate and chase the bulge
 [alpha,beta]=mmq_qrsweep1(alpha,beta,t(j),x,z);
 mu=mu+w(j);
end

alpha=alpha(:);
beta=beta(:);
