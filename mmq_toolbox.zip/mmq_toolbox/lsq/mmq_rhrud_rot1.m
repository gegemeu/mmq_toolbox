function [nt,sigt,alphat,betat,dt,cc,ss,eigvec,eigval]=mmq_rhrud_rot1(n,alpha,beta,sig,d,x,w,y,cc,ss,eigvec,eigval);
%MMQ_RHRUD_ROT1 least squares updating 
% from Elhay, Golub and Kautsky with some corrections
% store the rotations when updating to compute the eigenvectors of J in w
% All the eigenvectors are computed using the rotations
%
% Author G. Meurant
% May 2007
%

if length(x) ~= 1 | length(w) ~= 1 | length(y) ~= 1
 error('MMQ_RHRUD_ROT1: must add one point at a time')
end

alpha_old=alpha;
beta_old=beta;
d_old=d(1:n);

nt=n+1;
c2=sig^2;
s2=w^2;
sw=c2+s2;
sigt=sqrt(sw);
% rotation between the first and last line to obtain 
% R_1 (sig 0 ... 0 w)^T = (sig_tilde 0 ... 0)^T
c2=c2/sw;
s2=s2/sw;
cs=(sig*w)/sw;
c=sqrt(c2);
s=sqrt(s2);
cc(1,n)=c;
ss(1,n)=s;
sig=sigt;
teta1=cs*(x-alpha(1));
alpha(nt)=c2*x+s2*alpha(1);
alpha(1)=c2*alpha(1)+s2*x;
if n > 1
 teta2=-s*beta(1);
 beta(1)=c*beta(1);
end
d(nt)=c*w*y-s*d(1);
d(1)=c*d(1)+s*w*y;

for i=2:nt-1
 c2=beta(i-1)^2;
 s2=teta1^2;
 bt=c2+s2;
 xi=sqrt(bt);
 % rotation to annihilate teta_1 in the last line
 c2=c2/bt;
 s2=s2/bt;
 cs=(beta(i-1)*teta1)/bt;
 c=sqrt(c2);
 s=sqrt(s2);
 cc(i,n)=c;
 ss(i,n)=s;
 beta(i-1)=xi;
 cs2=2*cs*teta2;
 t=c2*alpha(i)+s2*alpha(nt)+cs2;
 r=c2*alpha(nt)-cs2+s2*alpha(i);
 teta1=cs*alpha(nt)-(cs*alpha(i)-teta2*(c2-s2));
 alpha(i)=t;
 alpha(nt)=r;
 if i ~= nt-1 
  teta2=-s*beta(i);
  old_bet=beta(i);
  beta(i)=c*beta(i);
 end % if i
 t=d(i);
 d(i)=c*t+s*d(nt);
 d(nt)=c*d(nt)-s*t;
end % for i
if teta1 == 0
 disp('MMQ_RHRUD_ROT1: teta1 = 0')
end
beta(nt-1)=abs(teta1);
d(nt)=sign(teta1)*d(nt);

alphat=alpha(1:nt);
if nt > 1
 betat=beta(1:nt-1);
else
 betat=[];
end
dt=d(1:nt);

vJ_old=eigvec(1:n,1:n);

nJ=size(vJ_old,1);
vJ_aug=[vJ_old zeros(nJ,1); zeros(1,nJ) 1];

% apply the rotations to vJ_aug to obtain the new eigenvectors

ww=vJ_aug;
for i=1:n
 r=speye(n+1,n+1);
 r(i,i)=cc(i,n);
 r(n+1,n+1)=cc(i,n);
 r(n+1,i)=-ss(i,n);
 r(i,n+1)=ss(i,n);
 ww=r*ww;
end
% positive first elements
for i=1:n+1
  if ww(1,i) < 0
    ww(:,i)=-ww(:,i);
  end
end
eigvec(1:n+1,1:n+1)=ww;

% add the new eigenvalue
eigval(nt)=x;

% recompute alpha and beta from the eigenvectors and eigenvalues
% (this does not improve much the solution)

%for j=1:n+1
%  yy=eigval(1:n+1).*ww(j,1:n+1)';
%  alphat(j)=ww(j,1:n+1)*yy;
%end
%for j=1:n-1
%  yy=eigval(1:n+1).*ww(j,1:n+1)';
%  betat(j)=ww(j+1,1:n+1)*yy;
%end
%ni=n+1;
%JJ=spdiags([[betat(1:ni-1)'; 0] alphat(1:ni)' [0; betat(1:ni-1)']], -1:1, ni,ni);
%JJf=full(JJ)







