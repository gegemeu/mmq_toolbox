%MMQ_RUN_TEST_GCV_DERIV2 run GCV for the deriv2 problem
%
% Author G. Meurant Dec 2006
%

warning off

% Test problem: computation of the second derivative
% (regutools/deriv2)

gcase = 3;
m=100;
n=100;

noise = 1E-7;
mmq_test_gcv;

pause

noise = 1E-5;
mmq_test_gcv;

pause

noise = 1E-3;
mmq_test_gcv;

pause

noise = 1E-1;
mmq_test_gcv;

pause

noise = 10;
mmq_test_gcv;

pause

warning on