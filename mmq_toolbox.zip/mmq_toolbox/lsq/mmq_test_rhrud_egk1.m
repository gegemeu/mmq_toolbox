function [n,sig,alpha,beta,d]=mmq_test_rhrud_egk1(N,M,ns,ix);
%MMQ_TEST_RHRUD_EGK1 test for the function rhrud as in Elhay, Golub and Kautsky
% compare to mmq_rhrud_rot1
%
% Author G. Meurant
% April 2007
%

[x,w,y,ier]=mmq_pwv(N,ix);
if ier == 1
 disp(' Unknown problem, abort')
 return
end
%x=x(N:-1:1);
%w=w(N:-1:1);
%y=y(N:-1:1);

% recursively build the solution up to M
sig=abs(w(1));
alpha(1)=x(1);
beta(1)=0;
d(1)=y(1)*sig;
n=1;
for i=1:M-1
 % update
[n,sig,alpha,beta,d]=mmq_rhrud(i,alpha,beta,sig,d,x(i+1),w(i+1),y(i+1),1);
disp('update init rhrud-----------------------')
n
end

alpha=alpha(1:ns);
beta=beta(1:ns-1);
d=d(1:ns);

for k=1:N-M
 disp('*********************************')
 k
 % add a point k+M by updating
 %[n,sig,alpha,beta,d]=rhrud(M,alpha,beta,sig,d,x(k+M),w(k+M),y(k+M),1);
 [n,sig,alpha,beta,d]=mmq_rhrud(length(alpha),alpha,beta,sig,d,x(k+M),w(k+M),y(k+M),1);
 disp('update k+M rhrud-----------------------')
 n
 % delete the point k by downdating
 [n,sig,alpha,beta,d]=mmq_rhrud(length(alpha),alpha,beta,sig,d,x(k),w(k),y(k),-1);
 disp('downdate k rhrud-----------------------')
 n
 %if n ~= M
 if n ~= ns
 %if n < ns
  disp('rhud: cannot downdate correctly, abort')
  return
 end
end
na=length(alpha);
alpha=alpha(1:ns);
beta=beta(1:ns-1);
d=d(1:ns);


%generate directly the solution at the end by updating
sigr=abs(w(N-M+1));
alphar(1)=x(N-M+1);
betar(1)=0;
dr(1)=y(N-M+1)*sigr;
eigvec=zeros(N,N);
eigvec(1,1)=1;
eigval=zeros(N,1);
eigval(1)=x(N-M+1);
cc=zeros(N,N);
ss=zeros(N,N);
for i=1:M-1
 % update
 [n,sigr,alphar,betar,dr,cc,ss,eigvec,eigval]=mmq_rhrud_rot1(i,alphar,betar,sigr,dr,x(N-M+i+1),w(N-M+i+1),y(N-M+i+1),cc,ss,eigvec,eigval);
disp('update ref rhrud_rot1-----------------------')
n
end
alphar=alphar(1:ns);
betar=betar(1:ns-1);
dr=dr(1:ns);

disp('++++++++++++++++++++++')
disp(' Final checks---------')
disp('  ')

% compare the solution
err_sig=abs(sig-sigr)/abs(sigr);
err_alpha=norm(alpha-alphar)/norm(alphar);
err_beta=norm(beta-betar)/norm(betar);
err_d=norm(d-dr)/norm(dr);
disp(' err_sig err_alpha err_beta err_d:')
[err_sig err_alpha err_beta err_d]





