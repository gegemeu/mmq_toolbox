function mmq_test_quadrule(n);
%MMQ_TEST_QUADRULE test program for Gauss quadrature rules
% computes the nodes and weights from the Jacobi matrix
%
% mmq_gaussquadrule is the Golub and Welsch original algorithm

% Author G. Meurant
% June 2007
%


% Legendre polynomials on [-1,1]
disp(' ')
disp('------ Legendre quadrature')
[a,b,mu0]=mmq_classicorthopoly('le',n,0,0);
[t,w]=mmq_gaussquadrule(a,b,ones(n,1),mu0,0);
disp(' ')
disp('          Abscissas                   Weights ')
[t' w']

% Shifted Legendre polynomials on [0,1]
disp(' ')
disp('------ Shifted Legendre quadrature')
[a,b,mu0]=mmq_classicorthopoly('sl',n,0,0);
[t,w]=mmq_gaussquadrule(a,b,ones(n,1),mu0,0);
disp(' ')
disp('          Abscissas                   Weights ')
[t' w']

% First kind Chebyshev polynomials on [-1,1]
disp(' ')
disp('------ Chebyshev (first kind) quadrature')
[a,b,mu0]=mmq_classicorthopoly('c1',n,0,0);
[t,w]=mmq_gaussquadrule(a,b,ones(n,1),mu0,0);
disp(' ')
disp('          Abscissas                   Weights ')
[t' w']

% Second kind Chebyshev polynomials on [-1,1]
disp(' ')
disp('------ Chebyshev (second kind) quadrature')
[a,b,mu0]=mmq_classicorthopoly('c2',n,0,0);
[t,w]=mmq_gaussquadrule(a,b,ones(n,1),mu0,0);
disp(' ')
disp('          Abscissas                   Weights ')
[t' w']

% Third kind Chebyshev polynomials on [-1,1]
disp(' ')
disp('------ Chebyshev (third kind) quadrature')
[a,b,mu0]=mmq_classicorthopoly('c3',n,0,0);
[t,w]=mmq_gaussquadrule(a,b,ones(n,1),mu0,0);
disp(' ')
disp('          Abscissas                   Weights ')
[t' w']

% Fourth kind Chebyshev polynomials on [-1,1]
disp(' ')
disp('------ Chebyshev (fourth kind) quadrature')
[a,b,mu0]=mmq_classicorthopoly('c4',n,0,0);
[t,w]=mmq_gaussquadrule(a,b,ones(n,1),mu0,0);
disp(' ')
disp('          Abscissas                   Weights ')
[t' w']

% Gegenbauer polynomials on [-1,1]
disp(' ')
disp('------ Gegenbauer quadrature')
[a,b,mu0]=mmq_classicorthopoly('ge',n,1,0);
[t,w]=mmq_gaussquadrule(a,b,ones(n,1),mu0,0);
disp(' ')
disp('          Abscissas                   Weights ')
[t' w']

% Jacobi polynomials on [-1,1]
disp(' ')
disp('------ Jacobi quadrature')
[a,b,mu0]=mmq_classicorthopoly('ja',n,1/2,1/2);
[t,w]=mmq_gaussquadrule(a,b,ones(n,1),mu0,0);
disp(' ')
disp('          Abscissas                   Weights ')
[t' w']

% Laguerre polynomials
disp('  ')
disp('----- Laguerre quadrature')
[a,b,mu0]=mmq_classicorthopoly('la',n,0,0);
str=sprintf('mu0 = %25.16e',mu0);
%disp(str)
[t,w]=mmq_gaussquadrule(a,b,ones(n,1),mu0,0);
disp(' ')
disp('          Abscissas                  Weights ')
[t' w']  

% Generalized Laguerre polynomials
disp('  ')
disp('----- Generalized Laguerre quadrature with alpha = -0.75')
[a,b,mu0]=mmq_classicorthopoly('gl',n,-0.75,0);
str=sprintf('mu0 = %25.16e',mu0);
%disp(str)
[t,w]=mmq_gaussquadrule(a,b,ones(n,1),mu0,0);
disp(' ')
disp('          Abscissas                  Weights ')
[t' w']

% Hermite polynomials
disp('  ')
disp('----- Hermite quadrature')
[a,b,mu0]=mmq_classicorthopoly('he',n,0,0);
[t,w]=mmq_gaussquadrule(a,b,ones(n,1),mu0,0);
disp(' ')
disp('          Abscissas                  Weights ')
[t' w']

% Generalized Hermite polynomials
disp('  ')
disp('----- Generalized Hermite quadrature with mu = 1')
[a,b,mu0]=mmq_classicorthopoly('gh',n,1,0);
[t,w]=mmq_gaussquadrule(a,b,ones(n,1),mu0,0);
disp(' ')
disp('          Abscissas                  Weights ')
[t' w']



