function l=mmq_maxnzpr(a);
%MMQ_MAXNZPR maximum number of non zeros per row of a
%
% Author G. Meurant
% Feb 2001
%

aa=spones(a);
l=full(max(sum(aa)));
