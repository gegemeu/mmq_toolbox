function [c,s,c2,s2,cs,r]=mmq_givensha(a,b);
%MMQ_GIVENSHA computes hyperbolic Givens rotation to zero b, E. Anderson version
%
% The rotation matrix is 
%  |  c  is |
%  | -is  c |
% but we compute in real arithmetic, a is real and the second element is assumed to be i b
% a must be different from b

% Author G. Meurant
% nov 2007

if a == b
 error('MMQ_Givensha: a=b')
end

if b == 0
 c=sign(a);
 s=0;
 r=abs(a);
elseif a == 0
 c=0;
 s=sign(b);
 r=abs(b);
elseif abs(a) > abs(b)
 t=b/a;
 if 1-t^2 < 0
  error('MMQ_Givensha: argument of sqrt < 0')
 end
 u=sign(a)*sqrt(1-t^2);
 c=1/u;
 s=t*c;
 r=a*u;
else
 t=a/b;
 if 1-t^2 < 0
  error('MMQ_Givensha: argument of sqrt < 0')
 end
 u=sign(b)*sqrt(1-t^2);
 s=1/u;
 c=t*s;
 r=b*u;
end

c2=c^2;
s2=s^2;
cs=c*s;


