%MMQ_RUN_TEST_L_RIBBON_PHILLIPS run L-ribbon for the Phillips problem
%
% Author G. Meurant Dec 2006
%

warning off

% Test problem: Fredholm integral equation of the first kind
% (regutools/phillips)

gcase = 8;
m = 200;
n = 200;


noise = 1E-5;
mmq_test_l_ribbon;

pause

noise = 1E-3;
mmq_test_l_ribbon;

pause

noise = 1E-1;
mmq_test_l_ribbon;

pause

noise = 1E1;
mmq_test_l_ribbon;


warning on