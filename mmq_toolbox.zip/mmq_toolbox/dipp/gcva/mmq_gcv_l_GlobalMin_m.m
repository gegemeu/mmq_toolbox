function x = mmq_gcv_l_GlobalMin_m (f, a, b);
%MMQ_GCV_L_GLOBALMIN_M locates the minimum of the function f
%
% Author  G. Meurant, Jan 2007
%
% The call
%
%     x = gcv_l_GlobalMin (f, a, b)
%
% tries to determine a global minimizer of f in the interval [a, b].  The
% statement
%
%     [fx, dfx] = feval (f, x)
%
% must evaluate  fx = f (x)  and the derivative  dfx = f' (x)
%
% It is also required that
%     0 <= a < b
%
global gcv_func_min gcv_func_max;

if a >= b
 error ('MMQ_GCV_L_GLOBALMIN_M: a >= b');
end

if a < 0
 error ('MMQ_GCV_L_GLOBALMIN_M: a < 0');
end

% first try with a few samples
n=50;
t=linspace(a,b,n);
[ft, dft] = feval (f, t);
gcv_func_min=gcv_func_min+n;
[tmp, k] = min (ft);
if k == 1
 b=t(2);
elseif k == n
 a=t(n-1);
else
 % look in the interval enclosing the min
 a=t(k-1);
 b=t(k+1);
end

% number of samples
%n = 300;
n=100;

t=linspace(a,b,n);

[ft, dft] = feval (f, t);
gcv_func_min=gcv_func_min+n;
[tmp, k] = min (ft);

while 1
 if k == 1
  break
 end
 if ft (k-1) > ft (k)
  break
 end
 k = k - 1;
end
% k == 1  |  f (t (k-1)) > f (t (k))

if dft (k) <= 0
 if k < n
  % f' (t (k)) <= 0,  f (t (k)) <= f (t (k+1))
  x = mmq_gcv_l_LocalMin (f, t (k), t (k+1));
 else  % k == n
  x = b;
 end
else  % f' (t (k)) > 0
 if k == 1
  x = a;
 else  % k > 1
  % f' (t (k)) > 0,  f (t (k-1)) > f (t (k))
  x = mmq_gcv_l_LocalMin (f, t (k-1), t (k));
 end
end
