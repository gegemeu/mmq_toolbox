function [nt,sigt,alphat,betat,dt]=mmq_rhrud_givf(n,alpha,beta,sig,d,x,w,y,ud);
%MMQ_RHRUD_GIVF least squares updating or downdating
% from Elhay, Golub and Kautsky with some corrections
% calls to Anderson's Givens rotations (mmq_givensa)
% and hyperbolic rotations (mmq_givensha)
% uses the factored form of the rotation (mmq_givensaf and mmq_givenshaf)
%
% this does not solve the rounding error problem!
%
% ud =1 if updating, -1 if downdating
%
% Author G. Meurant
% nov 2007
%

if length(x) ~= 1 | length(w) ~= 1 | length(y) ~= 1
 error('MMQ_RHRUD_GIVF: must add one point at a time')
end

nt=n+1;
alpha(nt)=0;
beta(nt)=0;

% rotation between the first and last line to obtain 
% R_1 (sig 0 ... 0 w)^T = (sig_tilde 0 ... 0)^T
if ud == -1
 [c,s,sigt,u]=mmq_givenshaf(sig,w);
 if isnan(sigt)
  error('MMQ_RHRUD_GIVF: error in rotation')
 end
else
 [c,s,sigt,u,v]=mmq_givensaf(sig,w);
end
sw=sig^2+ud*w^2;
if sw <= 0
 nt=0;
 disp('MMQ_RHRUD_GIVF: pb sig^2+ud*w^2 <= 0')
 return
end
sigt=sqrt(sw);

sig=sigt;
% apply the rotation (from left and right) to the augmented tridiagonal
if ud == -1
 % dowdating
 ii=sqrt(-1);
 if n == 1
  % the matrix is 2 x 2
  C=[c ii*s; -ii*s c];
  S=[1 0; 0 -1];
  T=[alpha(1) 0; 0 x];
  TR=T*S+2*(T*conj(u))*u.';
  T=S*TR+2*u*(u'*TR);
  alpha(1)=T(1,1);
  alpha(nt)=T(2,2);
  teta1=imag(T(2,1));
 else
  % general case, the matrix is 3 x 3
  C=[c 0 ii*s; 0 1 0; -ii*s 0 c];
  S=[1 0 0; 0 1 0; 0 0 -1];
  uu=[u(1); 0; u(2)];
  T=[alpha(1) beta(1) 0; beta(1) alpha(2) 0; 0 0 x];
  TR=T*S+2*(T*conj(uu))*uu.';
  T=S*TR+2*uu*(uu'*TR);
  alpha(1)=T(1,1);
  alpha(nt)=T(3,3);
  beta(1)=T(2,1);
  teta1=imag(T(3,1));
  teta2=imag(T(3,2));
 end
else
 % updating
 if n == 1
  % the matrix is 2 x 2
  C=[c s; -s c];
  T=[alpha(1) 0; 0 x];
  T=C*T*C';
  alpha(1)=T(1,1);
  alpha(nt)=T(2,2);
  teta1=T(2,1);
 else
  % general case, the matrix is 3 x 3
  C=[c 0 s; 0 1 0; -s 0 c];
  T=[alpha(1) beta(1) 0; beta(1) alpha(2) 0; 0 0 x];
  T=C*T*C';
  alpha(1)=T(1,1);
  alpha(nt)=T(3,3);
  beta(1)=T(2,1);
  teta1=T(3,1);
  teta2=T(3,2);
 end
end

% apply the rotation to d augmented by w*y
if ud == -1
 d(nt)=c*w*y-s*d(1);
 d(1)=c*d(1)+ud*s*w*y;
else
 dd=[c s; -s c]*[d(1); w*y];
 d(1)=dd(1);
 d(nt)=dd(2);
end

for i=2:nt-1
 % rotation to annihilate teta_1 in the last line
 % between row i and row nt
 if ud == -1
  % downdating
  [c,s,rr,u]=mmq_givenshaf(beta(i-1),teta1);
  if isnan(rr)
   nt=i-1;
   alphat=alpha(1:nt);
   betat=beta(1:nt-1);
   dt=d(1:nt);
   return
 end
  % apply the rotation from left and right
  if i == nt -1
   % the rows of interest are only nt-2, nt-1 and nt
   C=[1 0 0; 0 c ii*s; 0 -ii*s c];
   S=[1 0 0; 0 1 0; 0 0 -1];
   uu=[0; u(1); u(2)];
   T=[alpha(i-1) beta(i-1) ii*teta1; beta(i-1) alpha(i) ii*teta2; ii*teta1 ii*teta2 alpha(nt)];
   TR=S*T*S;
   T=TR+2*(uu*(uu'*T))*S+2*S*((T*conj(uu))*uu.')+4*uu*(uu'*T*conj(uu))*uu.';
   alpha(i)=T(2,2);
   alpha(nt)=T(3,3);
   teta1=imag(T(3,2));
   beta(i-1)=T(2,1);
  else
   % general case, the matrix is 4 x 4
   old_bet=beta(i);
   C=[1 0 0 0; 0 c 0 ii*s; 0 0 1 0; 0 -ii*s 0 c];
   S=[1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 -1];
   uu=[0; u(1); 0; u(2)];
   T=[alpha(i-1) beta(i-1) 0 ii*teta1; beta(i-1) alpha(i) beta(i) ii*teta2; 0 beta(i) alpha(nt-1) 0; ii*teta1 ii*teta2 0 alpha(nt)];
   TR=S*T*S;
   T=TR+2*(uu*(uu'*T))*S+2*S*((T*conj(uu))*uu.')+4*uu*(uu'*T*conj(uu))*uu.';
   alpha(i)=T(2,2);
   alpha(nt)=T(4,4);
   teta1=imag(T(4,2));
   teta2=imag(T(4,3));
   beta(i)=T(3,2);
   beta(i-1)=T(2,1);
  end
 else 
  % updating
  [c,s,rr,u,v]=mmq_givensaf(beta(i-1),teta1);
  % apply the rotation from left and right
  if i == nt -1
   % the rows of interest are only nt-2, nt-1 and nt
   C=[1 0 0; 0 c s; 0 -s c];
   T=[alpha(i-1) beta(i-1) teta1; beta(i-1) alpha(i) teta2; teta1 teta2 alpha(nt)];
   T=C*T*C';
   alpha(i)=T(2,2);
   alpha(nt)=T(3,3);
   teta1=T(3,2);
   beta(i-1)=T(2,1);
  else
   % general case, the matrix is 4 x 4
   old_bet=beta(i);
   C=[1 0 0 0; 0 c 0 s; 0 0 1 0; 0 -s 0 c];
   T=[alpha(i-1) beta(i-1) 0 teta1; beta(i-1) alpha(i) beta(i) teta2; 0 beta(i) alpha(nt-1) 0; teta1 teta2 0 alpha(nt)];
   T=C*T*C';
   alpha(i)=T(2,2);
   alpha(nt)=T(4,4);
   teta1=T(4,2);
   teta2=T(4,3);
   beta(i)=T(3,2);
   beta(i-1)=T(2,1);
  end
 end
 
 % apply rotation to d
 if ud == -1
  t=d(i);
  d(i)=c*t+ud*s*d(nt);
  d(nt)=c*d(nt)-s*t;
 else
  dd=[c s; -s c]*[d(i); d(nt)];
  d(i)=dd(1);
  d(nt)=dd(2);
 end
 
end % for i

if teta1 == 0
 disp('MMQ_RHRUD_GIVF: teta1 = 0')
end
if ud == -1
 beta(nt-1)=abs(teta1);
 ni=nt-1;
end
if ud == -1 
 nt=n-1;
 %nt=n;
else
 beta(nt-1)=abs(teta1);
 d(nt)=sign(teta1)*d(nt);
end

alphat=alpha(1:nt);
if nt > 1
 betat=beta(1:nt-1);
else
 betat=[];
end
dt=d(1:nt);

