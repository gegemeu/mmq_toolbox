function tr=mmq_est_tria_mod_rand(a,k,p,lmin,lmax);
%MMQ_EST_TRIA_MOD_RAND estimate of the trace of the inverse of a (mod moments + Monte Carlo)
% computes 2k+1 modified moments and uses the Golub and Welsch algorithm
% Monte Carlo for computing the trace of the Chebyshev matrices
% p random vectors
% lmin, lmax estimates of the smallest and largest eigenvalues of a
%
% Author G. Meurant
% July 2008
%

n=size(a,1);
km=2*k;
rand('state',0)
randn('state',0)

% p random vectors
for i=1:p
  z(:,i)=mmq_rand_pmone(n);
end
  
  mom=zeros(km,1);
  % computes the 2k moments of a
  [mom,bc,ac,cc]=mmq_trace_chebyshiftz(k,a,z,lmin,lmax);
  
  % compute the Jacobi matrix (monic polynomials) using modified moments
  [gamma,aa,b,mu0]=mmq_modifcheb(k,mom,1,0,bc,ac,cc,1);
  
  % symmetrize
  b=sqrt(b);
  
  % compute the nodes and weights
  [t,w]=mmq_gaussquadrule_m(aa,b,mu0);
  
  % compute the integral of 1/x
  tr=sum(w./t);
  
