function [q,e]=mmq_dqds(q,e,sigma);
%MMQ_DQDS progressive QD algorithm with shift sigma;
% Fernando and Parlett, from Laurie's paper
% based on Rutishauser's qd algorithm

% Author G. Meurant
% June 2007
%

n=length(q);
if length(e) < n-1
 error('MMQ_DQDS: error, length(e) too small')
end

d=q(1)-sigma;
for k=1:n-1
 q(k)=d+e(k);
 f=q(k+1)/q(k);
 e(k)=f*e(k);
 d=f*d-sigma;
end
q(n)=d;

