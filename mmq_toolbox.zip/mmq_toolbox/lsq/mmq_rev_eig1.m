function [nt,sigt,alphat,betat,dt,cc,ss]=mmq_rev_eig1(n,alpha,beta,sig,d,x,w,y,qq);
%MMQ_REV_EIG1 least squares downdating with an eigenvector
% from Elhay, Golub and Kautsky with some corrections
% qq is the eigenvector corresponding to x found with the Parlett-Dhillon
% algorithm (function teigv)
% simplified version, q is removed from mmq_rev_eig
%
% Author G. Meurant
% June 2007
%

if length(x) ~= 1 | length(w) ~= 1 | length(y) ~= 1
 error('MMQ_REV_EIG1: must add one point at a time')
end

nt=n-1;
sw=sig^2-w^2;
if sw <= eps
 disp('MMQ_REV_EIG1: sig^2-w^2 < eps')
 nt=0;
 sigt=0;
 alphat=[];
 betat=[];
 dt=[];
 return
end
sigt=sqrt(sw);
if qq(n) < 0
  qq=-qq;
end

u=qq(n-1);
u_new=qq(n);
rnormsq=u_new^2+u^2;
uu=sqrt(rnormsq);
c=u_new/uu;
cc(nt)=c;
s=-u/uu;
ss(nt)=s;
c2=u_new^2/rnormsq;
s2=u^2/rnormsq;
cs=-(u_new*u)/rnormsq;
atmp=alpha(nt+1);
if nt > 1
 p=-s*beta(nt-1);
end
r=cs*(atmp-alpha(nt))+(c2-s2)*beta(nt);
alpha(nt+1)=c2*atmp+s2*alpha(nt)-2*cs*beta(nt);
alpha(nt)=c2*alpha(nt)+2*cs*beta(nt)+s2*atmp;
if nt > 1
 beta(nt-1)=c*beta(nt-1);
end
beta(nt)=0;
% apply the rotations to d
dtmp=c*d(nt)+s*d(nt+1);
d(nt+1)=-s*d(nt)+c*d(nt+1);
d(nt)=dtmp;
for j=nt-1:-1:1
 s=r;
 c=beta(j);
 s2=s^2;
 c2=c^2;
 rnormsq=c2+s2;
 br=sqrt(rnormsq);
 s2=s2/rnormsq;
 c2=c2/rnormsq;
 cs=(c*s)/rnormsq;
 s=s/br;
 c=c/br;
 % storing and returning the rotations is useless
 % kept for compatibility
 cc(j)=c;
 ss(j)=s;
 atmp=alpha(nt+1);
 alpha(nt+1)=c2*atmp+s2*alpha(j)-2*cs*p;
 beta(j)=c*beta(j)+s*r;
 r=c*s*(atmp-alpha(j))+(c^2-s^2)*p;
 alpha(j)=c2*alpha(j)+2*cs*p+s2*atmp;
 if j > 1
  p=-s*beta(j-1);
  beta(j-1)=c*beta(j-1);
 end
 % apply the rotations to d
 dtmp=c*d(j)+s*d(nt+1);
 d(nt+1)=-s*d(j)+c*d(nt+1);
 d(j)=dtmp;
end
nt=n-1;
alphat=alpha(1:nt);
if nt > 1
 betat=beta(1:nt-1);
else 
 betat=[];
end
dt=d(1:nt);