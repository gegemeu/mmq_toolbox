%
% Contents of Tests
%
% MMQ_GEN_SMALL_LARGE generates a test matrix for GCV
% MMQ_NOISY add noise to the vector y
% MMQ_NOISYR add noise to the vector y
% MMQ_RUN_TEST_GCV test problems for mmq_test_gcv
% MMQ_RUN_TEST_GCV1 test problems for mmq_test_gcv
% MMQ_RUN_TEST_GCV2 test problems for mmq_test_gcv
% MMQ_RUN_TEST_GCV_BAART run GCV for the Baart problem
% MMQ_RUN_TEST_GCV_BAART_LARGE run GCV for the Baart problem
% MMQ_RUN_TEST_GCV_BLUR run GCV for the Blur problem
% MMQ_RUN_TEST_GCV_DERIV2 run GCV for the deriv2 problem
% MMQ_RUN_TEST_GCV_FOXGOOD run GCV for the Foxgood problem
% MMQ_RUN_TEST_GCV_FOXGOOD_LARGE run GCV for the Foxgood problem
% MMQ_RUN_TEST_GCV_HEAT run GCV for the Heat problem
% MMQ_RUN_TEST_GCV_ILAPLACE run GCV for the Inverse Laplace problem
% MMQ_RUN_TEST_GCV_LARGE run GCV for the large von Matt problem
% MMQ_RUN_TEST_GCV_LARGE1 run GCV for the large von Matt problem
% MMQ_RUN_TEST_GCV_PARALLAX run GCV for the parallax problem
% MMQ_RUN_TEST_GCV_PHILLIPS run GCV for the Phillips problem
% MMQ_RUN_TEST_GCV_PHILLIPS_LARGE run GCV for the Phillips problem
% MMQ_RUN_TEST_GCV_SHAW run GCV for the Shaw problem
% MMQ_RUN_TEST_GCV_SHAW_LARGE run GCV for the Shaw problem
% MMQ_RUN_TEST_GCV_SMALL run GCV for the small von Matt problem
% MMQ_RUN_TEST_GCV_SMALL_SMALL run GCV for the very small von Matt problem
% MMQ_RUN_TEST_GCV_SPIKES run GCV for the spikes problem
% MMQ_RUN_TEST_GCV_URSELL run GCV for the Ursell problem
% MMQ_RUN_TEST_GCV_WING run GCV for the Wing problem
% MMQ_RUN_TEST_L_CORNER test problems for mmq_test_l_corner
% MMQ_RUN_TEST_L_RIBBON test problems for mmq_test_l_ribbon
% MMQ_RUN_TEST_L_RIBBON_BAART run L-ribbon for the Baart problem
% MMQ_RUN_TEST_L_RIBBON_FOXGOOD run L-ribbon for the Foxgood problem
% MMQ_RUN_TEST_L_RIBBON_ILAPLACE run L-ribbon for the ILaplace problem
% MMQ_RUN_TEST_L_RIBBON_PHILLIPS run L-ribbon for the Phillips problem
% MMQ_RUN_TEST_L_RIBBON_SHAW run L-ribbon for the Shaw problem
% MMQ_RUN_TEST_L_RIBBON_SMALL run L-ribbon for the small von Matt problem
% MMQ_RUN_TEST_TRACE_EST run the test for the trace estimator
% MMQ_SOLIPP solution of an ill-posed problem using the SVD (u, s, v)
% MMQ_SOLSHAW Test problem: one-dimensional image restoration model 
% MMQ_TEST_GCV compute the regularization parameters
% MMQ_TEST_L_CORNER compute the regularization parameters
% MMQ_TEST_L_RIBBON compute the regularization parameters
% MMQ_TEST_TRACE_EST test for the trace estimator
% MMQ_USIN computes a sine vector