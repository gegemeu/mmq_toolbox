function [mu, lambda1, success, iter] = mmq_gcv_lanczos_m_log(K,y);
%MMQ_GCV_LANCZOS_M_LOG find the GCV reg param mu by Lanczos bidiagonalization
% from the Golub and von Matt paper
% save as mmq_gcv_lanczos, but for a general matrix K
% use the log of the GCV function for min-max
%
% Author  G. Meurant Dec 2006
% developed from a code by Urs von Matt
%
%
% communication among
% mmq_gcv_lanczos, mmq_gcv_l_Bounds, mmq_gcv_l_Lt0, mmq_gcv_l_Lt1,
% mmq_gcv_l_Ut0, mmq_gcv_l_Ut1, mmq_test_gcv_Vt
%
global gcv_l_m gcv_l_n gcv_l_normy gcv_l_normK gcv_l_normKTy ...
 gcv_l_u gcv_l_normu ...
gcv_l_gamma_y gcv_l_delta_y gcv_l_gamma_u gcv_l_delta_u;

global gcv_func_min gcv_func_max;

[m,n]=size(K);
if m < n
 error ('MMQ_GCV_LANCZOS_M_LOG: The case  m < n  is not covered.');
end

plots = 0;
iter=0;

normK=norm(K,'fro');

lambda = 0;
success = 0;

gcv_l_m = m;
gcv_l_n = n;
gcv_func_min=0;
gcv_func_max=0;
[m_y, n_y] = size (y);
if (m_y ~= m) | (n_y ~= 1)
 error ('MMQ_GCV_LANCZOS_M_LOG: y is not an mx1-vector.');
end
gcv_l_normy = norm (y, 2);
if gcv_l_normy == 0
 error ('MMQ_GCV_LANCZOS_M_LOG: y = 0');
end

gcv_l_normK = normK;
gcv_l_u = [];
gcv_l_gamma_y = [];
gcv_l_delta_y = [];
gcv_l_gamma_u = [];
gcv_l_delta_u = [];

% initialize Hutchinson's trace estimator
% nu = number of random vectors u
nu = 1;
% initialize Matlab 4 random numbers
rand ('seed', 0);
% initialize Matlab 6,... random numbers
%rand('state',0);

gcv_l_u = rand (nu * n, 1);
gcv_l_u = 2 * (gcv_l_u > 0.5) - 1;
gcv_l_u = gcv_l_u / sqrt (nu);
gcv_l_normu = sqrt (n);

% initialize bidiagonalizations
bidiag_u = 1;
bidiag_y = 1;
k_u = 0;
k_y = 0;
% minimum number of Lanczos iterations
kmin = ceil (3 * log (min (m, n)));
% maximum number of iterations
kmax = 2 * min (m, n);

bidiag_tol = 10 * max (m, n) * eps * normK;

% useful range for lambda
lambdamax = (normK / eps)^2 / m;
if isinf (lambdamax)
 error ('MMQ_GCV_LANCZOS_M_LOG: (normK / eps)^2 / m == Inf');
end
lambdamin = (eps * normK)^2 / m;
if lambdamin <= 0
 error ('MMQ_GCV_LANCZOS_M_LOG: (eps * normK)^2 / m == 0');
end
lambda=realmin;

end_of_Lanczos = 0;

% store the upper bidiagonal matrix in bu
bu=sparse(m,m);

% start Lanczos iterations

while ~(end_of_Lanczos | success)
 %fprintf (1, 'k_u = %4i,   k_y = %4i\r', k_u, k_y);
 
 % update bidiagonalizations
 if bidiag_u
  % bidiagonalization with u as starting vector
  if k_u == 0
   q_u = gcv_l_u / gcv_l_normu;
   p_u = K * q_u;
   gcv_l_gamma_u (1) = norm (p_u, 2);
   if abs (gcv_l_gamma_u (1)) <= bidiag_tol
    bidiag_u = 0;
    fprintf (1, 'MMQ_GCV_LANCZOS_M_LOG: bidiag_u = 0\n');
   else
    p_u = p_u / gcv_l_gamma_u (1);
    bu(1,1)=gcv_l_gamma_u(1);
   end
   k_u = 1;
  else
   q_u = K' * p_u - gcv_l_gamma_u (k_u) * q_u;
   gcv_l_delta_u (k_u) = norm (q_u, 2);
   bu(k_u,k_u+1)=gcv_l_delta_u(k_u);
   if abs (gcv_l_delta_u (k_u)) <= bidiag_tol
    gcv_l_delta_u = gcv_l_delta_u (1:k_u-1);
    bidiag_u = 0;
    fprintf (1, 'MMQ_GCV_LANCZOS_M_LOG: bidiag_u = 0\n');
   else
    k_u = k_u + 1;
    q_u = q_u / gcv_l_delta_u (k_u-1);
    p_u = K * q_u - gcv_l_delta_u (k_u-1) * p_u;
    gcv_l_gamma_u (k_u) = norm (p_u, 2);
    if abs (gcv_l_gamma_u (k_u)) <= bidiag_tol
     bidiag_u = 0;
     fprintf (1, 'MMQ_GCV_LANCZOS_M_LOG: bidiag_u = 0\n');
    else
     p_u = p_u / gcv_l_gamma_u (k_u);
     bu(k_u,k_u)=gcv_l_gamma_u(k_u);
    end
   end
  end
 end
 
 if bidiag_y
  % bidiagonalization with y as starting vector
  if k_y == 0
   p_y = y / gcv_l_normy;
   q_y = K' * p_y;
   gcv_l_gamma_y (1) = norm (q_y, 2);
   gcv_l_normKTy = gcv_l_gamma_y (1) * gcv_l_normy;
   if abs (gcv_l_gamma_y (1)) <= bidiag_tol
    fprintf (1, 'MMQ_GCV_LANCZOS_M_LOG: || K'' y || <= c * eps * || y ||\n');
    lambda = lambdamax;
    success = 1;
    return;
   else
    q_y = q_y / gcv_l_gamma_y (1);
    p_y = K * q_y - gcv_l_gamma_y (1) * p_y;
    gcv_l_delta_y (1) = norm (p_y, 2);
    if abs (gcv_l_delta_y (1)) <= bidiag_tol
     bidiag_y = 0;
     fprintf (1, 'MMQ_GCV_LANCZOS_M_LOG: bidiag_y = 0\n');
    else
     p_y = p_y / gcv_l_delta_y (1);
    end
    k_y = 1;
   end
  else
   q_y = K' * p_y - gcv_l_delta_y (k_y) * q_y;
   gcv_l_gamma_y (k_y+1) = norm (q_y, 2);
   if abs (gcv_l_gamma_y (k_y+1)) <= bidiag_tol
    gcv_l_gamma_y = gcv_l_gamma_y (1:k_y);
    bidiag_y = 0;
    fprintf (1, 'MMQ_GCV_LANCZOS_M_LOG: bidiag_y = 0\n');
   else
    k_y = k_y + 1;
    q_y = q_y / gcv_l_gamma_y (k_y);
    p_y = K * q_y - gcv_l_gamma_y (k_y) * p_y;
    gcv_l_delta_y (k_y) = norm (p_y, 2);
    if abs (gcv_l_delta_y (k_y)) <= bidiag_tol
     bidiag_y = 0;
     fprintf (1, 'MMQ_GCV_LANCZOS_M_LOG: bidiag_y = 0\n');
    else
     p_y = p_y / gcv_l_delta_y (k_y);
    end
   end
  end
 end
 
 end_of_Lanczos = (~bidiag_u & ~bidiag_y) | (max (k_u, k_y) >= kmax);
 
 if end_of_Lanczos | (max (k_u, k_y) >= kmin)
  % the minimum number of iterations has been done
  % evaluate termination criterion
  % determine smallest local minimizer of Ut0 (lambda)
  
  %lambda = mmq_gcv_l_GlobalMin_l ('mmq_gcv_l_Ut0_l', lambdamin, lambdamax); 
  lambda = mmq_gcv_l_GlobalMin_lm ('mmq_gcv_l_Ut0_l', lambdamin, lambdamax); 
  
  if lambda <= lambdamin
   success = 1;
  else
   %lambda1 = mmq_gcv_l_GlobalMax_l ('mmq_gcv_l_Lt0_l', lambdamin, lambda);
   lambda1 = mmq_gcv_l_GlobalMax_lm ('mmq_gcv_l_Lt0_l', lambdamin, lambda);
   g=10^(mmq_gcv_l_Lt0_l (log10(lambda)));
   g1=10^(mmq_gcv_l_Lt0_l (log10(lambda1)));
   success = (g1 > g);
  end
 end
end

mu=m*lambda;
iter=max(k_u,k_y);

%if success
 % display results
 fprintf (1, '\n');
 fprintf (1, 'MMQ_GCV_LANCZOS_M_LOG\n'); 
 fprintf (1, 'nu     = %11.4e  mu = %11.4e\n', lambda,m*lambda);
 fprintf (1, '%4i Lanczos iterations\n\n', iter);
%end
