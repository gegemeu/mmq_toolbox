function nb=mmq_stagestb(b,l,dd1,x,precond);
%MMQ_STAGESTB computes a quantity for estimation of the maximum accuracy
%
% Author G. Meurant
% April 2001
%

switch precond
 
case {'no'}
 nb=norm(b);
 
otherwise
 w=l\b;
 y=w./dd1;
 nb=norm(y);
 
end
