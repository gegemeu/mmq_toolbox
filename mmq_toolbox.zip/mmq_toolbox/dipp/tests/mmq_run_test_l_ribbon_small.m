%MMQ_RUN_TEST_L_RIBBON_SMALL run L-ribbon for the small von Matt problem
%
% Author G. Meurant 
% Feb 2007
%

warning off

% Small test problem with exponential singular value distribution

gcase = 0;
m = 200;
n = 100;
%m=200000;
%n=100000;
c = -0.03;
%c=-20*3/m;

noise = 1e-1;
mmq_test_l_ribbon;

pause

noise = 1E0;
mmq_test_l_ribbon;

pause

noise = 10;
mmq_test_l_ribbon;


warning on