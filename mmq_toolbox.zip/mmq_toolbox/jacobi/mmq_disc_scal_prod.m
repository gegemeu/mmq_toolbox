function sp=mmq_disc_scal_prod(f,g,w);
%MMQ_DISC_SCAL_PROD discrete scalar product
% sum_1^m f(x_k) g(x_k) w_k^2
% f and g are vectors containing the values f(x_k), and g(x_k)
% w is the weight vector

%
% Author G. Meurant
% June 2007
%

lf=length(f);
lg=length(g);
lw=length(w);

if lf ~= lg | lf ~= lw | lg ~= lw
 error('MMQ_DISC_SCAL_PROD: uncompatible dimensions')
end

lf=size(f,1);
if lf == 1
 f=f';
end
lg=size(g,1);
if lg == 1
 g=g';
end
lw=size(w,1);
if lw == 1
 w=w';
end

sp=sum(f.*g.*w.^2);

