function [alpha,beta]=mmq_ab_lanczos(x,w,orth);
%MMQ_AB_LANCZOS test using the Lanczos algorithm 
% to compute the orthogonal polynomials
% given the nodes x and weights w
% orth= 'or' uses double reorthogonalization
%     = 'no' Paige version
%     = 'st' standard Lanczos
%
% Author G. Meurant
% June 2007
%

N=length(x);
x=x(:);

a=spdiags(x,0,N,N);
x0=zeros(N,1);
w=w(:);
% caution
w=sqrt(w);

b=w;
kmax=N;

switch orth
  case 'or'
    [q,t,vts,dts]=mmq_lanczdor(a,b,x0,kmax);
    alpha=diag(t);
    beta=diag(t,-1);
  case 'no'
    [q,t,vts,dts]=mmq_lanczo(a,b,x0,kmax);
    alpha=diag(t);
    beta=diag(t,-1);
  case 'st'
    [q,t,vts,dts]=mmq_lanczost(a,b,x0,kmax);
    alpha=diag(t);
    beta=diag(t,-1);
 otherwise
  error('MMQ_AB_LANCZOS: wrong value of orth')
end
alpha=full(alpha);
beta=full(beta(1:kmax-1));



