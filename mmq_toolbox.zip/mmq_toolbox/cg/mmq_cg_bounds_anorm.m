function [res,x,nit,bg,bgrl,bgru,bgl,bag,bav]=mmq_cg_bounds_anorm(a,b,x0,epss,nitmax,lmin,lmax,delay,gag0);
%MMQ_CG_BOUNDS_ANORM conjugate gradient with estimates of the A-norm, Gauss and anti-Gauss estimates
% matrix a (symmetric), rhs b, x0 init vect, lmin, lmax estimates of extreme eigenvalues of a
% no preconditioning (see mmq_cg_bounds_acc)
%
% estimates of the A-norm of the error  = sqrt( r'*A^(-1)*r )
%
% stopping criteria relative norm of the residual < epss
% nitmax max number of iterations
% delay (max) at iteration k compute bounds for iteration k-delay
% gag0 is the starting value of gamma for the anti-Gauss rule
%
% bg, bgrl, bgru, bgl : Gauss, Gauss-Radau min and max, Gaus-Lobatto
% bag : anti-Gauss
% bav : average of Gauss and anti-Gauss
%
% res gives the norms of  the residual
% x is the approximate solution at convergence
% nit number of iterations
%
%
% Author G. Meurant
% July 2008
%

told=zeros(delay,1);
n=size(a,1);
x=x0;

r=b-a*x;
p=r;
r0=r'*r;
rtr=r0;
nit=0;
eps2=epss*epss*r0;
resid=realmax;
alp1=1.;
bet1=0.;
gam2=1.;
c2=1;
r00=r0;
gag0=min(1,gag0);
gag = gag0;

% CG iterations
while resid >= eps2 & nit < nitmax
 % parameter of the anti-Gauss rule
 
 nit=nit+1;
 ap=a*p;
 alp=rtr/(p'*ap);
 om=1/alp+bet1/alp1;
 if nit == 1 
  told(1)=1/om;
  d=om;
  dbar=om-lmax;
  dhat=om-lmin;
  ag=0;
 else
  c2=c2*gam2/d^2;
  dold=d;
  % Cholesky entry for anti-Gauss
  dp=om-2*gam2/dold;
  % Cholesky entry for Gauss
  d=om-gam2/d;
  tnew=c2/d;
  
  % anti-Gauss estimate
  if dp < 0
   gag=gag0;
   %disp('dp < 0')
   % fix up, decrease the value of gamma (gag)
   for j=1:9
    gag=gag-0.1;
    dp=om-(1+gag)*gam2/dold;
    if dp > 0
     break
    end
   end
   % if it is still < 0 use Gauss instead (gamma=0)
   if dp < 0
    gag=0;
   end
  end
  ag=(1+gag)*c2/dp;
  
  if nit < delay
   told(nit)=tnew;
  else
   told(delay)=tnew;
  end
  dbar=om-lmax-gam2/dbar;
  dhat=om-lmin-gam2/dhat;
 end
 
 alp1=alp;
 
 x=x+alp*p;
 r=r-alp*ap;
 rk=r'*r;
 resid=rk;
 res(nit)=sqrt(resid);
 
 bet=rk/rtr;
 rtr=rk;
 gam2=bet/alp^2;
 ombar=lmax+gam2/dbar;
 omhat=lmin+gam2/dhat;
 bbar=(gam2*c2)/(d*(ombar*d-gam2));
 bhat=(gam2*c2)/(d*(omhat*d-gam2));
 bgr0(nit)=sqrt(r00*bhat);
 dd=dhat*dbar/(dbar-dhat);
 omt=dd*(lmax/dhat-lmin/dbar);
 gamt2=dd*(lmax-lmin);
 btch=(gamt2*c2)/(d*(omt*d-gamt2));
 if nit > delay
  est=sum(told(1:delay));
  
  % Gauss, Gauss-Radau, Gauss-Lobatto
  bg(nit-delay)=sqrt(r00*est);
  bgrl(nit-delay)=sqrt(r00*(bbar+est));
  bgru(nit-delay)=sqrt(r00*(bhat+est));
  bgl(nit-delay)=sqrt(r00*(btch+est));
  
  % anti-Gauss
  if ag+est > 0
   bag(nit-delay)=sqrt(r00*(ag+est));
  else
   if nit-delay-1 > 0
    bag(nit-delay)=bag(nit-delay-1);
   else
    bag(nit-delay)=sqrt(rr00*est);
   end
  end
 end
 
 % shift of array told
 if nit >= delay
  temp=told(2:delay);
  told(1:delay-1)=temp;
 end
 
 bet1=bet;
 p=r+bet*p;
 
end

% average of Gauss and anti-Gauss
% it is not correct if we have changed the value of gamma
% during the iterations
% in this case return Gauss
nag=length(bag);
bav(1)=bag(1);
bav(2:nag)=(bag(2:nag)+gag0*bg(1:nag-1))/(1+gag0);
if gag < gag0
 bav=bg;
end

