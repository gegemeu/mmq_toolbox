function tt=mmq_jacobi(a,b);
%MMQ_JACOBI Jacobi matrix [b a b]
% a vector of the diagonal
% b vector of the sub-diagonal
%
% Author G. Meurant
%

a=a(:);
b=b(:);
c=[0; b(1:end-1)];
n=length(a);
if length(b) == n-1
 c=[0; b];
 b=[b; 0];
end
 
tt=spdiags([b a c], -1:1,n,n);
