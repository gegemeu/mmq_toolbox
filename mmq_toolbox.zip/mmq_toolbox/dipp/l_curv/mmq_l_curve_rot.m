function reg_corner=mmq_l_curve_rot(a,y);
%MMQ_L_CURVE_ROT locates the corner of the l-curve by rotation
%
% Author G. Meurant
% Jan 2007
%
% compute the SVD

[u,s,v]=svd(a);
s=diag(s);
maxs=max(s);

normK=norm(a,'fro');
% useful range for lambda
lambdamax = maxs^2;
lambdamin = (eps * normK);

reg_corner = mmq_l_corner ('mmq_fcorner', lambdamin, lambdamax, y, u, s, v);