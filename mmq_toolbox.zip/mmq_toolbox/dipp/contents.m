% 
% Contents of DIPP
%
% computation of the Tikhonov regularization parameter 
% for discrete ill-posed problems
%
% bidia   Bidiagonalization algorithms
% gcva    Generalized Cross Validation
% l_curv  L_curve
% tests   examples of use of the codes
% tikh    several other ways to compute the regularization parameter

