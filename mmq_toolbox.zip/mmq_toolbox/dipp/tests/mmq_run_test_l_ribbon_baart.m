%MMQ_RUN_TEST_L_RIBBON_BAART run L-ribbon for the Baart problem
%
% Author G. Meurant Dec 2006
%

warning off


% Test problem: Fredholm integral equation of the first kind
% (regutools/baart)

gcase = 2;
m = 100;
n = 100;

noise = 1E-7;
mmq_test_l_ribbon;

pause

noise = 1E-5;
mmq_test_l_ribbon;

pause

noise = 1E-3;
mmq_test_l_ribbon;

pause

noise = 1E-1;
mmq_test_l_ribbon;

pause

noise = 1E1;
mmq_test_l_ribbon;


warning on