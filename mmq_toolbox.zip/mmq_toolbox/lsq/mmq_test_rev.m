function [n,sig,alpha,beta,d]=mmq_test_rev(N,ix);
%MMQ_TEST_REV test for the function mmq_rev
% update and from 1 to N and then downdate
% compares the downdating results to what was obtained when updating
% plots the results
%
% Author G. Meurant
% April 2007
%

warning off

[x,w,y,ier]=mmq_pwv(N,ix);
if ier == 1
 disp('MMQ_TEST_REV: Unknown problem, abort')
 return
end

% recursively build the solution
sig=abs(w(1));
alpha(1)=x(1);
beta(1)=0;
d(1)=y(1)*sig;
n=1;
sigup=zeros(1,N);
alphaup=zeros(N,N);
betaup=zeros(N,N-1);
dup=zeros(N,N);
sigup(1)=sig;
alphaup(1,1)=alpha(1);
dup(1)=d(1);
nup(1)=1;
n=1;
for i=1:N-1
 % update
 [n,sig,alpha,beta,d]=mmq_rhrud(i,alpha,beta,sig,d,x(i+1),w(i+1),y(i+1),1);
 if n ~= i+1
  disp('MMQ_TEST_REV: pb in updating')
  [i n]
 end
 nup(n)=n;
 sigup(n)=sig;
 alphaup(n,:)=[alpha zeros(1,N-i-1)];
 betaup(n,:)=[beta zeros(1,N-i-1)];
 dup(n,:)=[d zeros(1,N-i-1)];
 disp('update rhrud-----------------------')
 n
 ni=n;
 J=spdiags([[beta(1:ni-1)'; 0] alpha(1:ni)' [0; beta(1:ni-1)']], -1:1, ni,ni);
 eigJ=sort(eig(full(J)));
 errJ=abs(sort(x(1:ni))-eigJ)./abs(sort(x(1:ni)));
 err_abs=abs(sort(x(1:ni))-eigJ)'
 err_rel=errJ'
 pause
end


n=N;
for i=N:-1:2
 % downdate
 [nout,sig,alpha,beta,d]=mmq_rev(n,alpha,beta,sig,d,x(n),w(n),y(n));
 disp('downdate rev---------------------')
 nout
 if nout ~= n-1
  disp('MMQ_TEST_REV: cannot downdate correctly')
  [n nout]
  return
 else
  n=nout;
 end
 ni=n;
 J=spdiags([[beta(1:ni-1)'; 0] alpha(1:ni)' [0; beta(1:ni-1)']], -1:1, ni,ni);
 eigJ=sort(eig(full(J)));
 errJ=abs(sort(x(1:ni))-eigJ)./abs(sort(x(1:ni)));
 err_abs=abs(sort(x(1:ni))-eigJ)'
 err_rel=errJ'
 err_sig=abs(sig-sigup(n))/sigup(n);
 err_sigi(nout)=err_sig;
 err_alpha=norm(alpha-alphaup(n,1:n))/norm(alphaup(n,1:n));
 err_alphai(nout)=err_alpha;
 if norm(betaup(n,1:n-1)) > 0
  err_beta=norm(beta-betaup(n,1:n-1))/norm(betaup(n,1:n-1));
 else
  err_beta=0;
 end
 err_betai(nout)=err_beta;
 err_d=norm(d-dup(n,1:n))/norm(dup(n,1:n));
 err_di(nout)=err_d;
 disp(' err_sig err_alpha err_beta err_d:')
 [err_sig err_alpha err_beta err_d]
 pause
end

% figure
figure
plot(log10(err_sigi))
hold on
plot(log10(err_alphai),'--')
plot(log10(err_betai),'-.')
plot(log10(err_di),':')
legend('err sig','err alpha','err beta','err d')
title('Rev: relative errors in downdating')
hold off
warning on