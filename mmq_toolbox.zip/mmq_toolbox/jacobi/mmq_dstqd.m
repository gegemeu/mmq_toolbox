function [q,e]=mmq_dstqd(q,e,sigma);
%MMQ_DSTQD stationary QD algorithm with shift sigma
% Fernando and Parlett, from Laurie's paper
% based on Rutishauser's qd algorithm

% Author G. Meurant
% June 2007
%

n=length(q);
if length(e) < n-1
 error('MMQ_DSTQD: error, length(e) too small')
end

t=-sigma;
for k=1:n-1
 u=q(k);
 q_old=q(k);
 q(k)=q(k)+t;
 f=e(k)/q(k);
 if isinf(f)
  n1=n-1
  sigma
  q
  k
  q_old
  t
  error('MMQ_DSTQD: error f infinite')
 end
 e(k)=f*u;
 t=t*f-sigma;
end
q(n)=q(n)+t;

