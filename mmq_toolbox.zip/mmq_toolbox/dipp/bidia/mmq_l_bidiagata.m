function cl=mmq_l_bidiagata(a,y,k);
%MMQ_L_BIDIAGATA compute the Lanczos bidiagonalization on A' A and a right hand side A'y
%
% cl lower bidiagonal
%
% Author G. Meurant
% Feb 2007
%
cl=sparse(k,k);

% init
w=a'*y;
v_old=w/norm(w);
w=a*v_old;
cl(1,1)=norm(w);
u_old=w/cl(1,1);

for i=2:k
 w=a'*u_old-cl(i-1,i-1)*v_old;
 cl(i,i-1)=norm(w);
 v=w/cl(i,i-1);
 
 w=a*v-cl(i,i-1)*u_old;
 cl(i,i)=norm(w);
 u=w/cl(i,i);
 
 u_old=u;
 v_old=v;
end
