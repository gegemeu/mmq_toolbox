%MMQ_RUN_TEST_GCV2 test problems for test_gcv
%
% Author Urs von Matt
%

warning off

% Large test problem with exponential singular value distribution
% (large)

gcase = 1;
m = 2000;
n = 1000;
c = -0.03;

noise = 1e-2;
mmq_test_gcv;

% (larger)
m = 20000;
n = 2000;
c = -0.003;
 
noise = 1e-2;
mmq_test_gcv;

warning on