function [alpha,beta]=mmq_test_plslr(N,ix);
%MMQ_TEST_PLSLR use the Reichel procedure to compute the Jacobi matrix
% for the discrete scalar product defined by nodes x_k and weights w_k^2

%
% Author G. Meurant
% June 2007
%

% computation of the nodes and weights and solution
[alpha,beta,d]=mmq_plslr(N,N,ix);

% computation of the eigenvalues and eigenvectors of the Jacobi matrix
ni=N;
J=spdiags([[beta(1:ni-1)'; 0] alpha(1:ni)' [0; beta(1:ni-1)']], -1:1, ni,ni);
[V,d]=eig(full(J));
eigJ=diag(d);
[eigJ,ind]=sort(eigJ);
V=V(:,ind);

[x,w,y,ier]=mmq_pwv(N,ix);
% the eigenvalues must be equal to the points
% errors on the points
errp=norm(x-eigJ)/norm(x);
disp(' Error in the eigenvalues')
errp

% errors on the first elements of the eigenvectors
% the first components of the eigenvectors must be equal to the weights
errw=norm(w'-abs(V(1,:)))/norm(w);
disp(' Error in the 1rst components')
errw
