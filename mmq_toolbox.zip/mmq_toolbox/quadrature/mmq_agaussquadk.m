function int=mmq_agaussquadk(t,mu0);
%MMQ_AGAUSSQUADK computes the anti-Gauss of  the integral of 1/x approximation for k=1,...
%
% Author G. Meurant
% April 2008
%

n=size(t,1);
int=zeros(n,1);

for k=2:n
 int(k)=mmq_agaussquad(t(1:k,1:k),mu0);
end
