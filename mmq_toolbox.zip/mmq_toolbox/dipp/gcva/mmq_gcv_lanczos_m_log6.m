function [mu, lambda1, success, iter] = mmq_gcv_lanczos_m_log6(K,y);
%MMQ_GCV_LANCZOS_M_LOG6 find the GCV reg param mu by Lanczos bidiagonalization
% from the Golub and von Matt paper
% for a general matrix K
% use the log of the GCV function for min-max
% test the convergence on only one point before computing the minimum
%
% use the SVD of B_k
%
%
% Author  G. Meurant 
% Jan 2007
% developed from a code by Urs von Matt
%
 
% communication among
% mmq_gcv_lanczos, mmq_gcv_l_Bounds, mmq_gcv_l_Lt0, mmq_gcv_l_Lt1,
% mmq_gcv_l_Ut0, mmq_gcv_l_Ut1, mmq_test_gcv_Vt
%

global gcv_l_m gcv_l_n gcv_l_normy gcv_l_normK gcv_l_normKTy ...
 gcv_l_u gcv_l_normu ...
gcv_l_gamma_y gcv_l_delta_y gcv_l_gamma_u gcv_l_delta_u;

global test_gcv_case test_gcv_sigma test_gcv_KU test_gcv_u ...
       test_gcv_KV test_gcv_v test_gcv_y;

global gcv_func_min gcv_func_max;

global S_y U_y S_u V_u;

global uyn2;

[m,n]=size(K);

% be careful, using plotapps=1 for plots computes the SVD of K
plotapps =0;
iter=0;

normK=norm(K,'fro');

lambda = 0;
success = 0;

gcv_l_m = m;
gcv_l_n = n;
gcv_func_min=0;
gcv_func_max=0;
[m_y, n_y] = size (y);
if (m_y ~= m) | (n_y ~= 1)
 error ('MMQ_GCV_LANCZOS_M_LOG6: y is not an mx1-vector.');
end
gcv_l_y=y;
gcv_l_normy = norm (y, 2);
if gcv_l_normy == 0
 error ('MMQ_GCV_LANCZOS_M_LOG6: y = 0');
end

gcv_l_normK = normK;
gcv_l_u = [];
gcv_l_gamma_y = [];
gcv_l_delta_y = [];
gcv_l_gamma_u = [];
gcv_l_delta_u = [];

% initialize Hutchinson's trace estimator
% nu = number of random vectors u
nu = 1;
% initialize Matlab 4 random numbers
rand ('seed', 0);
% initialize Matlab 6,... random numbers
%rand('state',0);

gcv_l_u = rand (nu * n, 1);
gcv_l_u = 2 * (gcv_l_u > 0.5) - 1;
gcv_l_u = gcv_l_u / sqrt (nu);
gcv_l_normu = sqrt (n);

% initialize bidiagonalizations
bidiag_u = 1;
bidiag_y = 1;
k_u = 0;
k_y = 0;
% minimum number of Lanczos iterations
%kmin = ceil (3 * log (min (m, n)));
kmin=2;
% maximum number of iterations
kmax = 2 * min (m, n); % this may be too large

bidiag_tol = 10 * max (m, n) * eps * normK;

% useful range for lambda
lambdamax = (normK / eps)^2 / m;
if isinf (lambdamax)
 error ('MMQ_GCV_LANCZOS_M_LOG6: (normK / eps)^2 / m == Inf');
end
lambdamin = (eps * normK)^2 / m;
if lambdamin <= 0
 error ('MMQ_GCV_LANCZOS_M_LOG6: (eps * normK)^2 / m == 0');
end
lambda=realmin;
g=realmin;
g1p=g;
ig=0;

if plotapps == 1
  samples = 300;
  [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
  test_gcv_sigma = diag (test_gcv_sigma);
  test_gcv_y = y;
  test_gcv_case=2; % Baart pb, must be > 1
  c = log (lambdamax / lambdamin) / (samples - 1);
  lambdas = zeros (samples, 1);
 lambdas (1) = lambdamin;
 lambdas (2:samples-1) = lambdamin * exp (c * [1:samples-2]');
 lambdas (samples) = lambdamax;
 [vlambdas, dvlambdas] = mmq_test_gcv_V (lambdas);
 figure
 loglog (lambdas, vlambdas, '-')
 hold on
 [vlambdast, dvlambdast] = mmq_test_gcv_Vt (lambdas);
 loglog (lambdas, vlambdast, 'r--')
 %find min of the V (G) function
 lambdaopt = mmq_gcv_l_GlobalMin ('mmq_test_gcv_V', 0, lambdamax);
 % compute the value at min
 [vlambdaopt, dvlambdaopt] = mmq_test_gcv_V (lambdaopt);
 loglog(lambdaopt,vlambdaopt,'x')
 ming=min(vlambdas);
 maxg=max(vlambdas);
end

end_of_Lanczos = 0;

% store the upper bidiagonal matrix in bu
bu=sparse(m,m);
by=sparse(m,m);

convsamp=0;

% start Lanczos iterations

while ~(end_of_Lanczos | success)
 %fprintf (1, 'k_u = %4i,   k_y = %4i\r', k_u, k_y);
 
 % update bidiagonalizations
 if bidiag_u
  % bidiagonalization with u as starting vector
  if k_u == 0
   q_u = gcv_l_u / gcv_l_normu;
   p_u = K * q_u;
   gcv_l_gamma_u (1) = norm (p_u, 2);
   if abs (gcv_l_gamma_u (1)) <= bidiag_tol
    bidiag_u = 0;
    fprintf (1, 'MMQ_GCV_LANCZOS_M_LOG6: bidiag_u = 0\n');
   else
    p_u = p_u / gcv_l_gamma_u (1);
    bu(1,1)=gcv_l_gamma_u(1);
   end
   k_u = 1;
  else
   q_u = K' * p_u - gcv_l_gamma_u (k_u) * q_u;
   gcv_l_delta_u (k_u) = norm (q_u, 2);
   bu(k_u,k_u+1)=gcv_l_delta_u(k_u);
   if abs (gcv_l_delta_u (k_u)) <= bidiag_tol
    gcv_l_delta_u = gcv_l_delta_u (1:k_u-1);
    bidiag_u = 0;
    fprintf (1, 'MMQ_GCV_LANCZOS_M_LOG6: bidiag_u = 0\n');
   else
    k_u = k_u + 1;
    q_u = q_u / gcv_l_delta_u (k_u-1);
    p_u = K * q_u - gcv_l_delta_u (k_u-1) * p_u;
    gcv_l_gamma_u (k_u) = norm (p_u, 2);
    if abs (gcv_l_gamma_u (k_u)) <= bidiag_tol
     bidiag_u = 0;
     fprintf (1, 'MMQ_GCV_LANCZOS_M_LOG6: bidiag_u = 0\n');
    else
     p_u = p_u / gcv_l_gamma_u (k_u);
     bu(k_u,k_u)=gcv_l_gamma_u(k_u);
    end
   end
  end
 end
 [U_u,S_u,V_u]=svd(full(bu(1:k_u,1:k_u)));
 S_u=diag(S_u);
 
 if bidiag_y
  % bidiagonalization with y as starting vector
  if k_y == 0
   p_y = y / gcv_l_normy;
   q_y = K' * p_y;
   gcv_l_gamma_y (1) = norm (q_y, 2);
   gcv_l_normKTy = gcv_l_gamma_y (1) * gcv_l_normy;
   if abs (gcv_l_gamma_y (1)) <= bidiag_tol
    fprintf (1, 'MMQ_GCV_LANCZOS_M_LOG6: || K'' y || <= c * eps * || y ||\n');
    lambda = lambdamax;
    success = 1;
    return;
   else
    q_y = q_y / gcv_l_gamma_y (1);
    by(1,1)=gcv_l_gamma_y(1);
    p_y = K * q_y - gcv_l_gamma_y (1) * p_y;
    gcv_l_delta_y (1) = norm (p_y, 2);
    if abs (gcv_l_delta_y (1)) <= bidiag_tol
     bidiag_y = 0;
     fprintf (1, 'MMQ_GCV_LANCZOS_M_LOG6: bidiag_y = 0\n');
    else
     p_y = p_y / gcv_l_delta_y (1);
     by(2,1)=gcv_l_delta_y(1);
    end
    k_y = 1;
   end
  else
   q_y = K' * p_y - gcv_l_delta_y (k_y) * q_y;
   gcv_l_gamma_y (k_y+1) = norm (q_y, 2);
   if abs (gcv_l_gamma_y (k_y+1)) <= bidiag_tol
    gcv_l_gamma_y = gcv_l_gamma_y (1:k_y);
    bidiag_y = 0;
    fprintf (1, 'MMQ_GCV_LANCZOS_M_LOG6: bidiag_y = 0\n');
   else
    k_y = k_y + 1;
    q_y = q_y / gcv_l_gamma_y (k_y);
    by(k_y,k_y)=gcv_l_gamma_y(k_y);
    p_y = K * q_y - gcv_l_gamma_y (k_y) * p_y;
    gcv_l_delta_y (k_y) = norm (p_y, 2);
    if abs (gcv_l_delta_y (k_y)) <= bidiag_tol
     bidiag_y = 0;
     fprintf (1, 'MMQ_GCV_LANCZOS_M_LOG6: bidiag_y = 0\n');
    else
     p_y = p_y / gcv_l_delta_y (k_y);
     by(k_y+1,k_y)=gcv_l_delta_y(k_y);
    end
   end
  end
 end
 [U_y,S_y,V_y]=svd(full(by(1:k_y+1,1:k_y)));
 S_y=diag(S_y(1:k_y,1:k_y));
 
 
 end_of_Lanczos = (~bidiag_u & ~bidiag_y) | (max (k_u, k_y) >= kmax);
 
 
 if end_of_Lanczos | (max (k_u, k_y) >= kmin & convsamp)
  % the minimum number of iterations has been done
  % evaluate termination criterion
  % determine smallest local minimizer of Ut0 (lambda)
  
  lmin=lambdamin;
  old_lambda=lambda;
  old_g=g;
  maxsbu=max(S_y);
  if m == n
   lambda = mmq_gcv_l_GlobalMin_lm ('mmq_gcv_l_Ut0_l_by', lmin, maxsbu^2);
   g=10^(mmq_gcv_l_Ut0_l_by (log10(lambda)));
  else
   lambda = mmq_gcv_l_GlobalMin_lm ('mmq_gcv_l_Ut0_l', lmin, lambdamax);
   g=10^(mmq_gcv_l_Ut0_l (log10(lambda)));
  end
  ig=ig+1;
  ll(ig)=lambda;
  gg(ig)=g;
  
  if lambda <= lambdamin
   success = 1;
  else
   lambda1=0;
   epsl=1e-5;
   test_lambda=abs(lambda-old_lambda)/abs(old_lambda);
   test_g=abs(g-old_g)/abs(old_g);
   testlg(ig)=test_lambda+test_g;
   if test_lambda+test_g <= epsl
    lambda1=lambda;
    success = 1;
   end
  end
  
  % plot the upper bound
  if plotapps == 1
   [ut0, dut0] = mmq_gcv_l_Ut0_l_by (log10(lambdas));
   ut0=10.^ut0;
   loglog(lambdas,ut0,'--')
   axis([0.1*lambdas(1) 10*lambdas(end) 0.1*ming 10*maxg])
  end
 end
 
 % compute the function at one chosen point
 if convsamp == 0
  epssamp=1e-2;
  samp=1e-15;
  old_g1p=g1p;
  g1p=10^(mmq_gcv_l_Ut0_l_by (log10(samp)));
  if abs(g1p-old_g1p)/abs(old_g1p) <= epssamp
   %disp(k_u)
   convsamp=1;
  end
 end
end

mu=m*lambda;
iter=max(k_u,k_y);

%if success
 % display results
 fprintf (1, '\n'); 
 fprintf (1, 'MMQ_GCV_LANCZOS_M_LOG6\n\n'); 
 fprintf (1, 'nu     = %11.4e  mu = %11.4e\n', lambda,m*lambda);
 fprintf (1, '%4i Lanczos iterations\n\n', iter);
%end
