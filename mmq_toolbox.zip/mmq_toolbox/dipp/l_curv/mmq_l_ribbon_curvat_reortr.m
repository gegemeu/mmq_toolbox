function [mul,muu]=mmq_l_ribbon_curvat_reortr(a,y,kmax);
%MMQ_L_RIBBON_CURVAT_REORTR computes the curvatures of the L-ribbon approximations
% with reorthogonalization
% use least squares to compute the derivative like in Reichel's code
%
% Lanczos bidiagonalization to compute lower and upper bounds of the L-curve
%
% Author G. Meurant
% Feb 2007
%

ny=norm(y);
naty=norm(a'*y);

% compute the exact L-curve and the limits

np=50;
[rho,eta,mu,lambdamin,lambdamax]=mmq_comp_l_curve1(a,y,np);

aa=log10(lambdamin);
bb=log10(lambdamax);

% t refers to values of log(lambda)
n=50;
t=linspace(aa,bb,n);
mu=10.^t;

% start the Lanczos iterations
% similar to l_bidiagaat

k=kmax;
c=sparse(k+1,k+1);
uu=zeros(length(y),k+1);
vv=uu;

% init
u_old=y/norm(y);
w=a'*u_old;
c(1,1)=norm(w);
v_old=w/c(1,1);
uu(:,1)=u_old;
vv(:,1)=v_old;

for i=2:k+1
 w=a*v_old-c(i-1,i-1)*u_old;
 c(i,i-1)=norm(w);
 u=w/c(i,i-1);
 
 % reorthogonalization
 
 for j=1:i-1
  alpha=u'*uu(:,j);
  u=u-alpha*uu(:,j);
  u=u/norm(u);
 end
 
 w=a'*u-c(i,i-1)*v_old;
 c(i,i)=norm(w);
 v=w/c(i,i);
 
% reorthogonalization

 for j=1:i-1
  alpha=v'*vv(:,j);
  v=v-alpha*vv(:,j);
  v=v/norm(v);
 end
 
 uu(:,i)=u;
 vv(:,i)=v;
 
 u_old=u;
 v_old=v;
 
end
% end of Lanczos iterations

i=k+1;

cc=c(1:i-1,1:i-1);
ccb=c(1:i,1:i-1);
[q,cch]=qr(full(ccb));
cch=cch(1:end-1,:);
if any(diag(cch) < 0)
 cch=-cch;
end
cch=cch';
% remove the last column
cchb=cch(:,1:end-1);

l=size(cch,1);
elp1=zeros(2*l,1); elp1(l+1)=1.0;
elp1b=zeros(2*l+1,1); 
elp1b(l+1)=1.0;

% Starting the loop over the values of the regularization parameter mu^2
p=length(mu);
for j=1:p
 mmu=sqrt(mu(j)); 
 yl = [cc';mmu*eye(l)]\(mmu^(-1)*elp1);
 Glres = mmu^4*ny^2*yl'*yl;
 lbr(j) = Glres;
 ylp1 = [ccb';mmu*eye(l+1)]\(mmu^(-1)*elp1b);
 Rlp1res = mmu^4*ny^2*ylp1'*ylp1;
 ubr(j) = Rlp1res;
 yll = [cch';mmu*eye(l)]\(mmu^(-1)*elp1);
 Glsol = naty^2*yll'*yll;
 lbx(j) = Glsol;
 ylbar = [cchb';mmu*eye(l)]\(mmu^(-1)*elp1(2:end));
 Rlsol = naty^2*ylbar'*ylbar;
 ubx(j) = Rlsol;
 
 yllpad = [zeros(l,1);yll];
 yyl = [cch';mmu*eye(l)]\(mmu^(-1)*yllpad);
 ylbarpad = [zeros(l,1);ylbar];
 yylbar = [cchb';mmu*eye(l)]\(mmu^(-1)*ylbarpad(2:end));
 lbxp(j)= -4*mmu*naty^2*yylbar'*ylbar;
 ubxp(j) = -4*mmu*naty^2*yyl'*yll;
 
 Sigpos = mmu*ubr(j)+mmu^3*ubx(j)+2*lbx(j)*lbr(j)/lbxp(j);
 if (Sigpos >= 0)
  Kpos(j) = (2*mmu*ubx(j)*ubr(j))/(mmu^4*lbx(j)^2+lbr(j)^2)^(1.5) *Sigpos;
 else
  Kpos(j) = (2*mmu*lbx(j)*lbr(j))/(mmu^4*ubx(j)^2+ubr(j)^2)^(1.5) *Sigpos;
 end
 Signeg = mmu*lbr(j)+mmu^3*lbx(j)+2*ubx(j)*ubr(j)/ubxp(j);
 if (Signeg >= 0)
  Kneg(j) = (2*mmu*lbx(j)*lbr(j))/(mmu^4*ubx(j)^2+ubr(j)^2)^(1.5) *Signeg;
 else
  Kneg(j) = (2*mmu*ubx(j)*ubr(j))/(mmu^4*lbx(j)^2+lbr(j)^2)^(1.5) *Signeg;
 end
end

curl=-Kpos;
curu=-Kneg;

plots=1;
if plots
 semilogx(sqrt(mu),curl)
 hold on
 semilogx(sqrt(mu),curu,'r')
 hold off
end

[tmp,kl]=max(curl);
[tmp,ku]=max(curu);

% the corner is given by the corresponding value of t
mul=mu(kl);
muu=mu(ku);





