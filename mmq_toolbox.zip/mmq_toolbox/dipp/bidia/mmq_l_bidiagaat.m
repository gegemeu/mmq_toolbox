function [c,cl,cr]=mmq_l_bidiagaat(a,y,k);
%MMQ_L_BIDIAGAAT compute the Lanczos bidiagonalizations on A A' and a right hand side y
%
% cl lower (k+1 by k) and cr lower (k by k, obtained from QR) bidiagonal 
% c (k by k) lower bidiagonal
%
% Author G. Meurant
% Feb 2007
%

c=sparse(k+1,k+1);

% init
u_old=y/norm(y);
w=a'*u_old;
c(1,1)=norm(w);
v_old=w/c(1,1);

for i=2:k+1
 w=a*v_old-c(i-1,i-1)*u_old;
 c(i,i-1)=norm(w);
 u=w/c(i,i-1);
 
 w=a'*u-c(i,i-1)*v_old;
 c(i,i)=norm(w);
 v=w/c(i,i);
 
 u_old=u;
 v_old=v;
end

cl=c(:,1:k);
c=c(1:k,1:k);
[q,cr]=qr(full(cl),0);
if any(diag(cr) < 0)
 cr=-cr;
end
cr=sparse(cr)';