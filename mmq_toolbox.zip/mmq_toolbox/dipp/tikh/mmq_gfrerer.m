function lambda = mmq_gfrerer (U, s, b, alpha);
%MMQ_GFRERER compute the regularization parameter from the Gfrerer/Raus
% method
%
%
% It computes the parameter  lambda >= 0  such that
%
%     x = (A'*A + lambda*I)^(-1) * A'*b
%
% The m-by-n matrix A must be specified in terms of its singular
% value decomposition  A = U Sigma V'.
%
% Input arguments:
%     U: m-by-p matrix, p >= min (m, n)
%        the left singular vectors of A
%     s: vector of size min (m, n)
%        the singular values of A sorted in decreasing order
%     b: vector of size m
%     alpha: scalar >= 0
%

% Author G. Meurant, Jan 2007
% from a code by
% Urs von Matt, UMIACS, University of Maryland, June 27, 1995

global discrep_c discrep_s discrep_z


% Initialization.
[m, p] = size (U);
if min (size (s)) > 1
  error ('MMQ_GFRERER: s must be a vector');
end
if any (s < 0)
  error ('MMQ_GFRERER: all the entries of s must be nonnegative.');
end
if length (b) ~= m
  error ('MMQ_GFRERER: length (b) ~= m');
end

r = sum (s > 0);
discrep_s = s (1:r);
if norm (U (:, 1), 2) > 1.2
  % U represents a Householder transformation
  z = b - U * (U' * b);
  z = z (1:r);
else
  z = U (:, 1:r)' * b;
end
discrep_z = z;
res2 = norm (b, 2)^2 - norm (z, 2)^2;

%res2=0;

if res2 >= alpha^2
  lambda = 0;
elseif alpha >= norm (b, 2)
  lambda = Inf;
else
  % lower bound on lambda
  lambda1 = (alpha^2 / sqrt(sum (z.^2 ./ s (1:r).^6)))^(1/3);

  % upper bound on lambda
  lambda2 = s (1)^2 *(alpha^2/ norm (b, 2)^2)^(1/3);

  discrep_c = res2 - alpha^2;
  lambda = mmq_l_Newton ('mmq_gfrerer_f', lambda1, lambda2);
end


