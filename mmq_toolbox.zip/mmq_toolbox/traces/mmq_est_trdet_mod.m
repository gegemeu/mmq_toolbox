function tr=mmq_est_trdet_mod(a,k,lmin,lmax);
%MMQ_EST_TRDET_MOD estimate of the determinant of a using modified moments
% computes 2k+1 moments and uses the Golub and Welsch algorithm
% lmin, lmax are estimates of the smallest and largest eigenvalues of a
%
% Author G. Meurant
% March 2008
%

% computes the 2k moments of a
[mom,bc,ac,cc]=mmq_trace_chebyshift(k,a,lmin,lmax);

% compute the Jacobi matrix (monic polynomials)
[gamma,aa,b,mu0]=mmq_modifcheb(k,mom,1,0,bc,ac,cc,1);

% symmetrize
b=sqrt(b);

% compute the nodes and weights
[t,w]=mmq_gaussquadrule_m(aa,b,mu0);

% compute the integral of log(x) and take the exponential
tr=exp(sum(w.*log(t)));
