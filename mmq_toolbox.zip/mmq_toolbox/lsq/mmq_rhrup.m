function [n,sig,alpha,beta,d]=mmq_rhrup(x,w,y);
%MMQ_RHRUP recursively computes the ls solution with N points using RHRud
% in updating mode
%
% Author G. Meurant
% June 2007
%

N=length(x);

% recursively build the solution
sig=abs(w(1));
alpha(1)=x(1);
beta(1)=0;
d(1)=y(1)*sig;
n=1;

for i=1:N-1
 % update with rhrud
 [n,sig,alpha,beta,d]=mmq_rhrud(i,alpha,beta,sig,d,x(i+1),w(i+1),y(i+1),1);
 if n ~= i+1
  disp('MMQ_RHRUP: pb in updating')
  [i n]
 end
end
 