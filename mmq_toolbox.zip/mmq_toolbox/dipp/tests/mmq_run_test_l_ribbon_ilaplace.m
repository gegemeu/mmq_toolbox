%MMQ_RUN_TEST_L_RIBBON_ILAPLACE run L-ribbon for the ILaplace problem
%
% Author G. Meurant Dec 2006
%

warning off

% Test problem: Fredholm integral equation of the first kind
% (regutools/ilaplace)

gcase = 6;
m = 100;
n = 100;


noise = 1E-5;
mmq_test_l_ribbon;

pause

noise = 1E-3;
mmq_test_l_ribbon;

pause

noise = 1E-1;
mmq_test_l_ribbon;

pause

noise = 1E1;
mmq_test_l_ribbon;



warning on