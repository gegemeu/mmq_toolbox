function [res,x,nit,bg,bgrl,bgru,bgl,lmin_est]=mmq_cg_bounds_adapt(a,b,x0,epss,nitmax,lmin,lmax,delay);
%MMQ_CG_BOUNDS_ADAPT conjugate gradient for a matrix a, switch when lmin has converged
% matrix a (symmetric), rhs b, x0 init vect, lmin, lmax estimates of extreme eigenvalues of a
% no preconditioning
%
% estimates of the A-norm of the error  = sqrt( r'*A^(-1)*r )
% adaptative algorithm, estimate of lmin by inverse iteration during CG iterations
% switch when lmin has converged
%
% stopping criteria relative norm of the residual < epss
% nitmax max number of iterations
% delay (max) at iteration k compute bounds for iteration k-delay
%
% bg, bgrl, bgru, bgl : Gauss, Gauss-Radau min and max, Gaus-Lobatto
%
% lmin_est : CG estimate of the smallest eigenvalue
%
% res gives the norms of  the residual
% x is the approximate solution at convergence
% nit number of iterations
%
%
% Author G. Meurant
%

told=zeros(delay,1);
lminold=1;
ilmin=0;
n=size(a,1);

x=x0;
r=b-a*x;

p=r;
r0=r'*r;
rtr=r0;
r0n(1)=r0;
nit=0;
eps2=epss*epss*r0;
resid=1;
alp1=1.;
bet1=0.;
gam2=1.;
c2=1;
r00=r0;

% CG iterations
while resid >= eps2 & nit <= nitmax
 nit=nit+1;
 ap=a*p;
 alp=rtr/(p'*ap);
 om=1./alp+bet1/alp1;
 t(nit,nit)=om;
 if nit == 1 
  told(1)=1./om;
  d=om;
  dbar=om-lmax;
  dhat=om-lmin;
 else
  tnew=(gam2*c2)/(d*(om*d-gam2));
  if nit < delay
   told(nit)=tnew;
  else
   told(delay)=tnew;
  end
  %
  %estimation of lmin by inverse iteration
  %
  if ilmin == 0
   % do npw iterations at most
   npw=5;
   qq=ones(nit,1);
   invt=inv(t(1:nit,1:nit));
   zz=invt*qq;
   for ii=1:npw
    qq=zz/sqrt(zz'*zz);
    zz=invt*qq;
    llmin=qq'*zz;
   end
   llmin=1/llmin;
   eplmin=1e-4;
   if abs(llmin-lminold) <= eplmin*lminold
    % convergence of inverse iteration
    % from now on use the new value of lmin
    lmin=llmin;
    lmin_est=llmin;
    ilmin=1;
   else
    lminold=llmin;
   end
  end
  
  c2=c2*gam2/d^2;
  d=om-gam2/d;
  dbar=om-lmax-gam2/dbar;
  dhat=om-lmin-gam2/dhat;
 end
 
 alp1=alp;
 x=x+alp*p;
 r=r-alp*ap;
 rk=r'*r;
 resid=rk;
 res(nit)=sqrt(resid);

 bet=rk/rtr;
 rtr=rk;
 gam2=bet/alp^2;
 gam=sqrt(gam2);
 t(nit,nit+1)=gam;
 t(nit+1,nit)=gam;
 ombar=lmax+gam2/dbar;
 omhat=lmin+gam2/dhat;
 bbar=(gam2*c2)/(d*(ombar*d-gam2));
 bhat=(gam2*c2)/(d*(omhat*d-gam2));
 dd=dhat*dbar/(dbar-dhat);
 omt=dd*(lmax/dhat-lmin/dbar);
 gamt2=dd*(lmax-lmin);
 btch=(gamt2*c2)/(d*(omt*d-gamt2));
 
 if nit > delay
  est=sum(told(1:delay));
  bg(nit-delay)=sqrt(r00*est);
  bgrl(nit-delay)=sqrt(r00*(bbar+est));
  bgru(nit-delay)=sqrt(r00*(bhat+est));
  bgl(nit-delay)=sqrt(r00*(btch+est));
 end
 %
 % shift of array told
 if nit >= delay
  temp=told(2:delay);
  told(1:delay-1)=temp;
 end
 
 bet1=bet;
 p=r+bet*p;
 
end
