%MMQ_RUN_TEST_GCV_PHILLIPS run GCV for the Phillips problem
%
% Author G. Meurant Dec 2006
%

warning off

% Phillips''s "famous" test problem
% (regutools/phillips)

gcase = 8;
m = 200;
n = 200;


noise = 1E-5;
mmq_test_gcv;

pause

noise = 1E-3;
mmq_test_gcv;

pause

noise = 1E-1;
mmq_test_gcv;

pause

noise = 1E1;
mmq_test_gcv;


warning on