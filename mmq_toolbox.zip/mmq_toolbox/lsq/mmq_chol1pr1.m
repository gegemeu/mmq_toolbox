function [ld,ld1]=mmq_chol1pr1(u);
%MMQ_CHOL1PR1 computes diagonals of the Cholesky decomposition of I + u u^T
%
% Author G. Meurant
% May 2007
%

n=length(u);

% compute the sum of the squares of the components of u
u2=u.^2;
s=cumsum(u2)+1;

ld=zeros(n,1);
ld(1)=s(1);
ld(2:n)=s(2:n)./s(1:n-1);
ld=sqrt(ld);
ld1=zeros(n-1,1);
s=sqrt(s);
uu=u(2:n).*u(1:n-1);
if size(s,1) == 1
  s=s';
end
ss=[1; s(1:n-1)];
s2=s.*ss;
ld1=uu./s2(1:n-1);

