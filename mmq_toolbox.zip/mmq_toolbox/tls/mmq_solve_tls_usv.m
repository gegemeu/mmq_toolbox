function xtls=mmq_solve_tls_usv(uu,s,v,y,s_tls,Tk);
%MMQ_SOLVE_TLS_USV compute the TLS solution by bidiagonalization
% doing kmax iterations
% Lanczos bidiagonalization I = Bidiag2
% u=K'y as a starting vector
% Tk (tridiagonal) has already been computed when evaluating the TLS
% parameter. It is used to avoid computing the Lanczos vectors twice
% The matrix K is defined by uu, s, v

% Author G. Meurant
% Oct 2007


bidiag_tol=1e-15;
%u=K'*y;
u=mmq_pmatat(uu,s,v,y);
normu=norm(u);
nu2=normu^2;
q_u = u / normu;
%p_u = K * q_u;
p_u=mmq_pmata(uu,s,v,q_u);
gamma_u (1) = norm (p_u, 2);
if abs (gamma_u (1)) <= bidiag_tol
 bidiag_y = 0;
 fprintf (1, 'MMQ_SOLVE_TLS_USV: bidiag_u = 0\n');
else
 p_u = p_u / gamma_u (1);
end
k_u = 1;

kmax=size(Tk,1);
% Tk is tridiagonal
e1=zeros(kmax,1);
e1(1)=1;
z=(Tk-s_tls^2*speye(kmax))\(normu*e1);
xtls=zeros(length(v),1);

while k_u <= kmax
 
 xtls=xtls+z(k_u)*q_u;
 
 % update bidiagonalization I with u as starting vector
 
 %q_u = K' * p_u - gamma_u (k_u) * q_u;
 q_u = mmq_pmatat(uu,s,v,p_u) - gamma_u (k_u) * q_u;
 delta_u (k_u) = norm (q_u, 2);
 if abs (delta_u (k_u)) <= bidiag_tol
  delta_u = delta_u (1:k_u-1);
  bidiag_y = 0;
  fprintf (1, 'MMQ_SOLVE_TLS_USV: bidiag_u = 0\n');
 else
  k_u = k_u + 1;
  q_u = q_u / delta_u (k_u-1);
  %p_u = K * q_u - delta_u (k_u-1) * p_u;
  p_u = mmq_pmata(uu,s,v,q_u) - delta_u (k_u-1) * p_u;
  gamma_u (k_u) = norm (p_u, 2);
  if abs (gamma_u (k_u)) <= bidiag_tol
   bidiag_y = 0;
   fprintf (1, 'MMQ_SOLVE_TLS_USV: bidiag_u = 0\n');
  else
   p_u = p_u / gamma_u (k_u);
  end
 end
end


 
