function int=mmq_quadgaussex(iex,n);
%MMQ_QUADGAUSSEX examples of computations of integrals with Gauss quadrature
%
% Author G. Meurant
% March 2008
%


switch(iex)
 case 1
  % Legendre weight function, f(x)=x^20
  [a,b,mu0]=mmq_classicorthopoly('le',n,0,0);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=t.^(20);
  %ft=t.^(5);
  
 case 2
  % Legendre weight function, f(x)=exp(x)
  [a,b,mu0]=mmq_classicorthopoly('le',n,0,0);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=exp(t);
  
 case 3
  % Legendre weight function, f(x)=1/(1+10 x^2)
  [a,b,mu0]=mmq_classicorthopoly('le',n,0,0);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=1./(1+10*t.^2);
  
 case 4
  % Legendre weight function, f(x)=exp(-1/x^2)
  [a,b,mu0]=mmq_classicorthopoly('le',n,0,0);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=exp(-1./t.^2);
  
 case 5
  % Legendre weight function, f(x)=(1-x^2)^(-1/2)
  [a,b,mu0]=mmq_classicorthopoly('le',n,0,0);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=1./sqrt(1-t.^2);
  
 case 6
  % Chebyshev weight function, f(x)=(1-x^2)^(-1/2)
  [a,b,mu0]=mmq_classicorthopoly('c1',n,0,0);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=ones(1,n);
  
 case 7
  % Legendre weight function, f(x)=(1-x^2)^(1/2)/(2+x)^(1/2)
  [a,b,mu0]=mmq_classicorthopoly('le',n,0,0);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
%   [t,w]=mmq_gaussquadrule_m(a,b,mu0);
  
  ft=sqrt(1-t.^2)./sqrt(2+t);
  
   case 8
  % Chebyshev second kind weight function, f(x)=1/(2+x)^(1/2)
  [a,b,mu0]=mmq_classicorthopoly('c2',n,0,0);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=1./sqrt(2+t);
  
 otherwise
  error('MMQ_QUADGAUSSEX: Unknown example')
  int=0;
  return
  
end

int=sum(w.*ft);