function int=mmq_gaussquadk(t,mu0);
%MMQ_GAUSSQUADK computes the Gauss approximation of the integral of 1/x for k=1,...
%
% Author G. Meurant
% April 2008
%

n=size(t,1);
int=zeros(n,1);

for k=1:n
 int(k)=mmq_gaussquad(t(1:k,1:k),mu0);
end
