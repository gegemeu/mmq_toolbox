function [tr,b,a,c]=mmq_trace_chebyshiftz(n,A,z,lmin,lmax);
%MMQ_TRACE_CHEBYSHIFTZ product z' C_l z given by the shifted Chebyshev recurrence
% compute 2n moments
%
% Author G. Meurant
% March 2008
%

% number of random vectors
p=size(z,2);
m=2*n;
tr=zeros(m,1);
trx=zeros(m,p);

na=size(A,1);

% coefficients of the polynomial recurrence
[b,a,c]=mmq_chebyshift(m,lmin,lmax);

for i=1:p
 trx(1,i)=z(:,i)'*z(:,i);
 
 oldc=z(:,i);
 newc=(A-a(1)*speye(na))*z(:,i)/b(1);
 trx(2,i)=z(:,i)'*newc;
 
 for k=1:m-2
  cc=((A-a(k+1)*speye(na))*newc-c(k)*oldc)/b(k+1);
  oldc=newc;
  newc=cc;
  trx(k+2,i)=z(:,i)'*cc;
 end
 
end

% average the results
for i=1:m
 tr(i)=sum(trx(i,:))/p;
end
