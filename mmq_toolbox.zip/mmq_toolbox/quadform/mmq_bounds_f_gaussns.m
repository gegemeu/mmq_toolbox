function [bg,bgrl,bgru,bgl]=mmq_bounds_f_gaussns(fonc,a,i,l,kmax,lmin,lmax,del);
%MMQ_BOUNDS_F_GAUSSNS computation of bounds for the element (i,l) of the function fonc
% of a symmetric matrix a
% nonsymmetric Lanczos algorithm
%
% estimate of fonc(a)_(ii)+fonc(a)_(il)/delta
%
% kmax iterations
% lmin and lmax are the lower and upper bounds for the smallest and largest eigenvalues
%
%  bg :         Gauss
%  bgrl, bgru : Gauss-Radau
%  bgl :        Gauss-Lobatto
%
% Author G. Meurant
% March 2008
%
if l > i
 ii=i;
 i=l;
 l=ii;
end

if i == l
 [bg,bgrl,bgru,bgl]=mmq_bounds_f_gauss(fonc,a,i,lmin,lmax,kmax);
 return
end

if del <= eps
 del=1;
end

bg=zeros(kmax,1);
bgrl=zeros(kmax,1);
bgru=zeros(kmax,1);
bgl=zeros(kmax,1);

jj=sparse(kmax,kmax);
n=size(a,1);
ei=zeros(n,1);
ei(i)=1;
el=zeros(n,1);
el(l)=1;
x1=zeros(n,1);
xt1=zeros(n,1);
x=ei/del;
xt=el+del*ei;
gam=0;
bet=0;
ax=a*x;
axt=a*xt;
om=xt'*ax;
jj(1,1)=om;
bg(1)=feval(fonc,om);
r=ax-om*x;
rt=axt-om*xt;
gamb=rt'*r;
gabet=sqrt(abs(gamb));
gam=gabet;
bet=gabet;
if gamb < 0
 bet=-gabet;
end
x1=x;
xt1=xt;
x=r/gam;
xt=rt/bet;

% non symmetric Lanczos iterations
if kmax > 1
 for k=2:kmax
  gam1=gam;
  bet1=bet;
  gamb1=gamb;
  ax=a*x;
  axt=a*xt;
  om=xt'*ax;
  r=ax-om*x-bet*x1;
  rt=axt-om*xt-gam*xt1;
  gamb=rt'*r;
  gabet=sqrt(abs(gamb));
  gam=gabet;
  bet=gabet;
  if gamb < 0
   bet=-gabet;
  end
  x1=x;
  xt1=xt;
  if gabet == 0
   error('MMQ_BOUNDS_F_GAUSSNS: breakdown')
  end
  x=r/gam;
  xt=rt/bet;
  jj(k,k)=om;
  jj(k,k-1)=bet1;
  jj(k-1,k)=gam1;
  
  % Gauss
  % computation of the eigenvalues and eigenvectors
  [vj,dj]=eig(full(jj(1:k,1:k)));
  tjj=diag(dj);
  [uj,dj]=eig(full(jj(1:k,1:k)'));
  % normalization of the eigenvectors
  for kk=1:k
   uv=sqrt(vj(:,kk)'*uj(:,kk));
   vj(1,kk)=vj(1,kk)/uv;
   uj(1,kk)=uj(1,kk)/uv;
  end
  s=vj(1,:)';
  st=uj(1,:)';
  ftjj=feval(fonc,tjj);
  bg(k)=sum(ftjj.*s.*st);
  
  % Gauss-Radau
  r=(a-om*eye(n))*x-bet*x1;
  rt=(a-om*eye(n))*xt-gam*xt1;
  gabet=sqrt(abs(rt'*r));
  gamm=gabet;
  bett=gabet;
  if rt'*r <= 0
   bett=-gabet;
  end
  if gabet == 0
   error('MMQ_BOUNDS_F_GAUSSNS: breakdown')
  end
  b=zeros(k,1);
  b(k)=gamm*bett;
  dmax=(jj(1:k,1:k)-lmin*eye(k))\b;
  omm=lmin+dmax(k);
  delk=zeros(1,k);
  delk(k)=gamm;
  dell=zeros(1,k);
  dell(k)=bett;
  jt=zeros(k+1);
  jt=[jj(1:k,1:k) delk';dell omm];
  
  [vj,dj]=eig(full(jt(1:k+1,1:k+1)));
  tjj=diag(dj);
  [uj,dj]=eig(full(jt(1:k+1,1:k+1)'));
  % normalization of the eigenvectors
  for kk=1:k+1
   uv=sqrt(vj(:,kk)'*uj(:,kk));
   vj(1,kk)=vj(1,kk)/uv;
   uj(1,kk)=uj(1,kk)/uv;
  end
  s=vj(1,:)';
  st=uj(1,:)';
  ftjj=feval(fonc,tjj);
  bgru(k)=sum(ftjj.*s.*st);
  dmin=(jj(1:k,1:k)-lmax*eye(k))\b;
  omm=lmax+dmin(k);
  jt(k+1,k+1)=omm;
  jt=[jj(1:k,1:k) delk';dell omm];
  
  [vj,dj]=eig(full(jt(1:k+1,1:k+1)));
  tjj=diag(dj);
  [uj,dj]=eig(full(jt(1:k+1,1:k+1)'));
  % normalization of the eigenvectors
  for kk=1:k+1
   uv=sqrt(vj(:,kk)'*uj(:,kk));
   vj(1,kk)=vj(1,kk)/uv;
   uj(1,kk)=uj(1,kk)/uv;
  end
  s=vj(1,:)';
  st=uj(1,:)';
  ftjj=feval(fonc,tjj);
  bgrl(k)=sum(ftjj.*s.*st);
  
  % Gauss-Lobatto
  b=zeros(k,1);
  b(k)=1;
  dmin=(jj(1:k,1:k)-lmin*eye(k))\b;
  ga=dmin(k);
  dmax=(jj(1:k,1:k)-lmax*eye(k))\b;
  gb=dmax(k);
  pol=[1 -ga; 1 -gb];
  yy=pol\[lmin ; lmax];
  omm=yy(1);
  gabet=sqrt(abs(yy(2)));
  gamm=gabet;
  bett=gabet;
  if yy(2) <= 0
   bett=-gabet;
  end
  dell=zeros(1,k);
  dell(k)=gamm;
  delk=zeros(1,k);
  delk(k)=bett;
  jt=zeros(k+1);
  jt=[jj(1:k,1:k) dell';delk omm];
  
  [vj,dj]=eig(full(jt(1:k+1,1:k+1)));
  tjj=diag(dj);
  [uj,dj]=eig(full(jt(1:k+1,1:k+1)'));
  % normalization of the eigenvectors
  for kk=1:k+1
   uv=sqrt(vj(:,kk)'*uj(:,kk));
   vj(1,kk)=vj(1,kk)/uv;
   uj(1,kk)=uj(1,kk)/uv;
  end
  s=vj(1,:)';
  st=uj(1,:)';
  ftjj=feval(fonc,tjj);
  bgl(k)=sum(ftjj.*s.*st);
  
 end
end
