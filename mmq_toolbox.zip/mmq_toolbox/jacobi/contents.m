%
% Contents of Jacobi
%
% Computation of the Jacobi matrix from the nodes and weights
% of a quadrature rule and vice versa
%
% MMQ_AB_LANCZOS test using the Lanczos algorithm 
% MMQ_CONVQR computes the Jacobi matrix from the nodes t and weights w
% MMQ_DISC_SCAL_PROD discrete scalar product
% MMQ_DQDS progressive QD algorithm with shift sigma;
% MMQ_DSTQD stationary QD algorithm with shift sigma
% MMQ_GAUSSQL  QL algorithm to compute the eigenvalues of a tridiagonal matrix
% MMQ_GAUSSQR  QR algorithm to compute the eigenvalues of a tridiagonal matrix
% MMQ_GIVENS computes Givens rotation to zero b
% MMQ_GIVENSU Givens rotation for chasing up
% MMQ_INV_PROBLEM check exactness of methods for the inverse problem
% MMQ_INV_PROBLEM2 check exactness of methods for the inverse problem
% MMQ_LANCZDOR Lanczos iteration for a matrix a with double full reorthogonalization 
% MMQ_LANCZO lanczos iteration for a matrix a 
% MMQ_LANCZOSOPQ Lanczos algorithm from OPQ = RKPW
% MMQ_LANCZOST Lanczos iteration for a matrix a, standard version
% MMQ_LANCZOS_RAT Rational Lanczos iteration for a diagonal matrix a, standard version
% MMQ_PFTOQD computes the augmented QD row of a partial fraction
% MMQ_PFTOQD1 computes the augmented QD row of a partial fraction
% MMQ_QLGAUSS given the nodes t and the Jacobi matrix 
% MMQ_QLSWEEP one step of implicit shift QL with shift sigma
% MMQ_QLSWEEPCS one step of implicit shift QL with shift sigma
% MMQ_QRGAUSS given the nodes t and the Jacobi matrix 
% MMQ_QRSWEEP one step of implicit shift QR with shift sigma
% MMQ_QRSWEEP1 one step of implicit shift QR with shift sigma
% MMQ_RKPW implements the Kahan Pal Walker procedure 
% MMQ_SQLGAUSS given the nodes t and the Jacobi matrix 
% MMQ_STIELTJ implements the Stieltjes procedure 
% MMQ_STIELTJES_MONIC implements the Stieltjes procedure 
% MMQ_STIELTJES_ORTHO implements the Stieltjes procedure 
% MMQ_STRAKOS generates the diagonal Strakos matrix
% MMQ_TEST_CONVQR implements the Laurie's procedure Convqr
% MMQ_TEST_GAUSSQL test program for mmq_gaussql
% MMQ_TEST_GAUSSQR test program for mmq_gaussqr
% MMQ_TEST_Lanczos test using the Lanczos algorithm 
% MMQ_TEST_LANCZOSOPQ implements the RKPW procedure 
% MMQ_TEST_PFTOQD implements the Laurie's procedure 
% MMQ_TRIDIAG  Tridiagonal matrix (sparse)

