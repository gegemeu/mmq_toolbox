function x = mmq_l_corner(f, a, b, y, u, s, v);
%MMQ_L_CORNER locates the corner of the l-curve by rotating it
%
% from the SVD u,s,v
% algorithm lc1
% uses the logarithm with a regular mesh
%
% Author  G. Meurant
% Jan 2007
%

global gcv_func_min gcv_func_max;

if a >= b
 error ('MMQ_L_CORNER: a >= b');
end

if a < 0
 error ('MMQ_L_CORNER: a < 0');
end

a=log10(a);
b=log10(b);

% locate the minimum in a few passes (ipass)

% t refers to values of log(lambda)
% number of sample points
n=25;
ipass=3;
iter=0;
fail=0;

while ipass > 0
 iter=iter+1;
 ipass=ipass-1;
 if n <= 0
  disp('MMQ_L_CORNER: failure, n=0')
  fail=1;
  break
 end
 
 t=linspace(a,b,n);
 ft = feval (f, t, y, u, s, v);
 gcv_func_min=gcv_func_min+n;
 [tmp, k] = min (ft);
 
 if k == 1
  % the min is on the boundary
  % look at the angles
  kk=mmq_angle(t,u,s,v,y);
  if kk == 0
   error('MMQ_L_CORNER: unable to find the corner')
  end
  
  if kk == 1
   b=t(2);
  elseif kk == n
   a=t(n-1);
  else
   a=t(kk-1);
   b=t(kk+1);
  end
  
 elseif k == n
  % the min is on the boundary
  % look at the angles
  kk=mmq_angle(t,u,s,v,y);
  if kk == 0
   error('unable to find the corner')
  end
  
  if kk == 1
   b=t(2);
  elseif kk == n
   a=t(n-1);
  else
   a=t(kk-1);
   b=t(kk+1);
  end
  
 else
  % for the next pass look in the interval enclosing the min
  a=t(k-1);
  b=t(k+1);
 end
 
end

if fail == 1
 x=0;
else
 % the corner is given by the corresponding value of t
 x=t(k);
 x=10^x;
end