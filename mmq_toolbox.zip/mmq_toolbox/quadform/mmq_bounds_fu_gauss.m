function [bg,bgrl,bgru,bgl]=mmq_bounds_fu_gauss(fonc,a,u,kmax,lmin,lmax);
%MMQ_BOUNDS_FU_GAUSS computation of lower and upper bounds of u^T fonc(a) u using Lanczos
% symmetric matrix a
%
% kmax iterations
% lmin and lmax are the lower and upper bounds for the smallest and largest eigenvalues
%
% we compute the nodes and weights using the Golub and Welsch algorithm
%
%  bg :         Gauss
%  bgrl, bgru : Gauss-Radau
%  bgl :        Gauss-Lobatto
%  
% Author G. Meurant
% March 2008
%

bg=zeros(kmax,1);
bgrl=zeros(kmax,1);
bgru=zeros(kmax,1);
bgl=zeros(kmax,1);

jj=sparse(kmax,kmax);
n=size(a,1);
nu=norm(u);
nu2=nu^2;
x1=zeros(n,1);
x=u/nu;
gam=0;
ax=a*x;
om=x'*ax;
jj(1,1)=om;
bg(1)=feval(fonc,om);
% bgrl, bgru and bgl are not computed for k=1
r=ax-om*x;
gam2=r'*r;
gam=sqrt(gam2);
x1=x;
x=r/gam;

% Lanczos iterations
if kmax > 1
 for k=2:kmax
  gam1=gam;
  gam21=gam2;
  ax=a*x;
  om=x'*ax;
  jj(k,k)=om;
  jj(k,k-1)=gam;
  jj(k-1,k)=gam;
  r=ax-om*x-gam*x1;
  gam2=r'*r;
  gam=sqrt(gam2);
  x1=x;
  if gam == 0
   error('MMQ_BOUNDS_FU_GAUSS: gamma = 0')
  end
  x=r/gam;
  
  % Gauss
  dijj=diag(jj(1:k,1:k));
  sdijj=diag(jj(1:k,1:k),-1);
  
  [tjj,wjj]=mmq_gaussquadrule(dijj,sdijj,0,1,0);
  
  ftjj=feval(fonc,tjj);
  bg(k)=nu2*sum(ftjj.*wjj);
  
  % Gauss-Radau
  b=zeros(k,1);
  b(k)=gam*gam;
  dmax=(jj(1:k,1:k)-lmin*eye(k))\b;
  omm=lmin+dmax(k);
  del=zeros(1,k);
  del(k)=gam;
  jt=[jj(1:k,1:k) del';del omm];
  dijt=diag(jt(1:k+1,1:k+1));
  sdijt=diag(jt(1:k+1,1:k+1),-1);
  
  [tjj,wjj]=mmq_gaussquadrule(dijt,sdijt,0,1,0);
  
  ftjj=feval(fonc,tjj);
  bgru(k)=nu2*sum(ftjj.*wjj);
  dmin=(jj(1:k,1:k)-lmax*eye(k))\b;
  omm=lmax+dmin(k);
  jt(k+1,k+1)=omm;
  dijt=diag(jt(1:k+1,1:k+1));
  sdijt=diag(jt(1:k+1,1:k+1),-1);
  
  [tjj,wjj]=mmq_gaussquadrule(dijt,sdijt,0,1,0);
  
  ftjj=feval(fonc,tjj);
  bgrl(k)=nu2*sum(ftjj.*wjj);
  
  % Gauss-Lobatto
  bbb=zeros(k,1);
  bbb(k)=1;
  dmin=(jj(1:k,1:k)-lmin*eye(k))\bbb;
  ga=dmin(k);
  dmax=(jj(1:k,1:k)-lmax*eye(k))\bbb;
  gb=dmax(k);
  pol=[1 -ga; 1 -gb];
  yy=pol\[lmin ; lmax];
  omm=yy(1);
  gamm=sqrt(yy(2));
  del=zeros(1,k);
  del(k)=gamm;
  jj1=jj(1:k,1:k);
  jt=[jj1 del';del omm];
  dijt=diag(jt(1:k+1,1:k+1));
  sdijt=diag(jt(1:k+1,1:k+1),-1);
  
  [tjj,wjj]=mmq_gaussquadrule(dijt,sdijt,0,1,0);
  
  ftjj=feval(fonc,tjj);
  bgl(k)=nu2*sum(ftjj.*wjj);
  
 end
end
