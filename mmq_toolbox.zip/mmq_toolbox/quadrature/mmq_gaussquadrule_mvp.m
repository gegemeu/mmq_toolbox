function [t,w]=mmq_gaussquadrule_mvp(a,b,mu0,dig);
%MMQ_GAUSSQUADRULE_MVP computes nodes and weights using the Matlab QR algorithm
% variable precision, needs the Symbolic Toolbox
%

% Author G. Meurant
% April 2008
%

dig_old=digits;
digits(dig)
a=vpa(a);
b=vpa(b);
muzero=vpa(mu0);

if length(a) == 1
 t=a(1);
 w=mu0;
 return
end

J=diag(a)+diag(b,-1)+diag(b,1); 
[V,D]=eig(J);
t=diag(D);
[tt,i]=sort(double(t));
t=t(i);
w=mu0*V(1,i).^2;
t=t';

%t=double(t);
%w=double(w);
digits(dig_old)