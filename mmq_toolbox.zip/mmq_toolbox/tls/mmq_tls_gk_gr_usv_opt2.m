function [s_tls,s_tls2,s_tls_gr1,s_tls_gr12,s_tls_gr2,s_tls_gr22,Scc,itsec,itsecmin,itsecmax, ...
    itsecgr1,itsecgr1min,itsecgr1max,itsecgr2,itsecgr2min,itsecgr2max]=mmq_tls_gk_gr_usv_opt2(uu,s,v,y,epsi);
%MMQ_TLS_GK_GR_USV_OPT2 Golub-Kahan bidiagonalization of K (uu, s, v) for large matrices
% optimized version
% monitor the smallest singular value of K which is computed by solving a secular equation
% at each iteration
% Gauss and Gauss-Radau at the end

% bidiagonalization with y (K' y) as starting vector

warning off

end_of_Lanczos=0;
success=0;
bidiag_tol=1e-15;
itmax=1000;
m=length(uu);
n=length(v);
kmax=max(m,n);
kmax=min(itmax,kmax);
bidiag_y=1;
s_tls_old=1;
itsec=0;
itsecmin=realmax;
itsecmax=realmin;
itsecgr1=0;
itsecgr1min=realmax;
itsecgr1max=realmin;
itsecgr2=0;
itsecgr2min=realmax;
itsecgr2max=realmin;
comp_sec=1;
sc=realmax;
ittridtot=0;

sK=s;
smin=min(sK);
smin=smin^2;
smax=max(sK);
smax=smax^2;
S_min_old=sqrt(realmax);
Sc=realmax;

% init 

% Lanczos bidiagonalization II = Bidiag1
% y as a starting vector

normy=norm(y);
ny2=normy^2;
p_y = y / normy;
%q_y = K' * p_y;
q_y=mmq_pmatat(uu,s,v,p_y);
gamma_y (1) = norm (q_y, 2);
by(1,1)=gamma_y(1);
if abs (gamma_y (1)) <= bidiag_tol
  fprintf (1, 'MMQ_TLS_GK_GR_USV_OPT2: || K'' y || <= c * eps * || y ||\n');
  success = 1;
  return;
end
q_y = q_y / gamma_y (1);
%p_y = K * q_y - gamma_y (1) * p_y;
p_y=mmq_pmata(uu,s,v,q_y)-gamma_y(1)*p_y;
delta_y (1) = norm (p_y, 2);
by(2,1)=delta_y(1);
if abs (delta_y (1)) <= bidiag_tol
  bidiag_y = 0;
  fprintf (1, 'MMQ_TLS_GK_GR_USV_OPT2: bidiag_y = 0\n');
else %if
  p_y = p_y / delta_y (1);
end %if abs(delta
k_y=1;
Bk=[gamma_y(1); delta_y(1)];
Jk=Bk'*Bk;
SJ_min=min(eig(Jk));

% Lanczos bidiagonalization I = Bidiag2
% u=K'y as a starting vector

%u=K'*y;
u=mmq_pmatat(uu,s,v,y);
normu=norm(u);
nu2=normu^2;
q_u = u / normu;
%p_u = K * q_u;
p_u=mmq_pmata(uu,s,v,q_u);
gamma_u (1) = norm (p_u, 2);
bu(1,1)=gamma_u(1);
if abs (gamma_u (1)) <= bidiag_tol
  bidiag_y = 0;
  fprintf (1, 'MMQ_TLS_GK_GR_USV_OPT2: bidiag_u = 0\n');
else
  p_u = p_u / gamma_u (1);
end
k_u = 1;

sc=0;
while ~(end_of_Lanczos | success)
  %fprintf (1, 'MMQ_TLS_GK_GR_USV_OPT2: Lanczos it = %4i, Sc = %12.8e\r', k_y+1,Sc);
  
  % update bidiagonalization II
  
  %q_y = K' * p_y - delta_y (k_y) * q_y;
  q_y=mmq_pmatat(uu,s,v,p_y)-delta_y(k_y)*q_y;
  gamma_y (k_y+1) = norm (q_y, 2);
  if abs (gamma_y (k_y+1)) <= bidiag_tol
    gamma_y = gamma_y (1:k_y);
    bidiag_y = 0;
    fprintf (1, 'MMQ_TLS_GK_GR_USV_OPT2: bidiag_y = 0\n');
  else
    k_y = k_y + 1;
    q_y = q_y / gamma_y (k_y);
    by(k_y,k_y)=gamma_y(k_y);
    %p_y = K * q_y - gamma_y (k_y) * p_y;
    p_y=mmq_pmata(uu,s,v,q_y)-gamma_y(k_y)*p_y;
    delta_y (k_y) = norm (p_y, 2);
    if abs (delta_y (k_y)) <= bidiag_tol
      bidiag_y = 0;
      fprintf (1, 'MMQ_TLS_GK_GR_USV_OPT2: bidiag_y = 0\n');
    else %if
      p_y = p_y / delta_y (k_y);
      by(k_y+1,k_y)=delta_y(k_y);
    end %if abs(delta
  end %if abs(gamma
  alpha=gamma_y(k_y)^2+delta_y(k_y)^2;
  beta=gamma_y(k_y)*delta_y(k_y-1);
  
  compsec=1;
  end_of_Lanczos = (~bidiag_y) | (k_y >= kmax+1);
  
  if comp_sec ==1
    
   % solve the secular equation for the smallest singular value
    epss=epsi/10;
    [SJ_min,ittrid]=mmq_solve_secul_trid(SJ_min,Jk,alpha,beta,epss);
    ittridtot=ittridtot+ittrid;
    
    S_min_new=sqrt(SJ_min);
    Sc=abs(S_min_new^2-S_min_old^2)/abs(S_min_old^2);
    S_min_old=S_min_new;
    
    ek=zeros(k_y-1,1);
    ek(k_y-1)=1;
    Jk=[Jk beta*ek; beta*ek' alpha];

    if Sc <= epsi
      end_of_Lanczos=1;
    end
  end
  Scc(k_y)=Sc;
  
  % Gauss-Radau
  % update bidiagonalization I with u as starting vector
  
  %q_u = K' * p_u - gamma_u (k_u) * q_u;
  q_u=mmq_pmatat(uu,s,v,p_u)-gamma_u(k_u)*q_u;
  delta_u (k_u) = norm (q_u, 2);
  bu(k_u,k_u+1)=delta_u(k_u);
  if abs (delta_u (k_u)) <= bidiag_tol
    delta_u = delta_u (1:k_u-1);
    bidiag_y = 0;
    fprintf (1, 'MMQ_TLS_GK_GR_USV_OPT2: bidiag_u = 0\n');
  else
    k_u = k_u + 1;
    q_u = q_u / delta_u (k_u-1);
    %p_u = K * q_u - delta_u (k_u-1) * p_u;
    p_u=mmq_pmata(uu,s,v,q_u)-delta_u(k_u-1)*p_u;
    gamma_u (k_u) = norm (p_u, 2);
    if abs (gamma_u (k_u)) <= bidiag_tol
      bidiag_y = 0;
      fprintf (1, 'MMQ_TLS_GK_GR_USV_OPT2: bidiag_u = 0\n');
    else
      p_u = p_u / gamma_u (k_u);
      bu(k_u,k_u)=gamma_u(k_u);
    end
  end
  
end %while

% compute Gauss when converged

% computation of the SVD of B_k
[U_y,S_y,V_y]=svd(full(by(1:k_y+1,1:k_y)));
S_y=diag(S_y(1:k_y,1:k_y));
S_min=min(S_y);
S_min_new=S_min;
S_min_old=S_min_new;
S_max=max(S_y);
% order the singular values in ascending order
S_y=S_y(end:-1:1);

% solve the secular equation using BNS1
meth='b1';
%epss=1e-10;
epss=epsi/10;
d=[0; S_y.^2];
e1=zeros(size(U_y,2),1);
e1(1)=1;
c=U_y'*e1;
c=c(end:-1:1);
% 0 is supposed to be the first pole
[s_tls_new,its,xs]=mmq_solve_secul_tls(d,c,ny2,epss,meth);
%fprintf (1, 'MMQ_TLS_GK_GR_USV_OPT2: secul iterations = %4i\r', its);
itsec=itsec+its;
itsecmin=min(itsecmin,its);
itsecmax=max(itsecmax,its);
s_tls=sqrt(s_tls_new);
%fprintf(1,'MMQ_TLS_GK_GR_USV_OPT2: Gauss solution = %21.15e\r',s_tls);

% Gauss-Radau when converged

% compute the SVD of modified bu (upper bidiagonal)
bbu=bu(1:k_u,1:k_u);
% We must modify bu to get the Gauss-Radau rule with a min of sing. val.
% Tk is tridiagonal
Tk=bu(1:k_u-1,1:k_u-1)'*bu(1:k_u-1,1:k_u-1);
ek=zeros(k_u-1,1);
ek(k_u-1)=1;
%% take the min of singular values of K to start
buk2=(gamma_u(k_u-1)*delta_u(k_u-1))^2;
%smi=smin
% Use 0 as the min
%smi=0;
% Use the smallest sing value
smi=S_min^2;
dd=(Tk-smi*speye(k_u-1,k_u-1))\(buk2*ek);
om=smi+dd(k_u-1);
% modify the last diagonal entry of the Cholesky decomposition bu' * bu
gammat=om-delta_u(k_u-1)^2;
but=bbu;
but(k_u,k_u)=sqrt(gammat);

[U_u,S_u,V_u]=svd(full(but));
S_u=diag(S_u);
su2=S_u.^2;
sminu=min(S_u);
e1=zeros(k_u,1);
e1(1)=1;
cc=V_u'*e1;

% solve the TLS secular equation
xs=s_tls_new;
% newt = 1 is Newton iterations
newt=1;
if newt == 1
  [xfgr1,fxfgr1,itgr1]=mmq_solve_secul_tls_gr(su2,cc,nu2,ny2,xs,epss);
else
  [xfgr1,fxfgr1,itgr1]=mmq_solve_secul_tls_gr1(su2,cc,nu2,ny2,xs,epss);
end
itsecgr1=itsecgr1+itgr1;
itsecgr1min=min(itsecgr1min,itgr1);
itsecgr1max=max(itsecgr1max,itgr1);

% We must modify bu to get the Gauss-Radau rule with a max of sing. val.
% take the max of singular values of K to start
buk2=(gamma_u(k_u-1)*delta_u(k_u-1))^2;
%smi=smax;
smi=S_max^2;
% could have used S_max
dd=(Tk-smi*speye(k_u-1,k_u-1))\(buk2*ek);
om=smi+dd(k_u-1);
% modify the Cholesky decomposition bu' * bu
gammat=om-delta_u(k_u-1)^2;
but=bbu;
but(k_u,k_u)=sqrt(gammat);

[U_u,S_u,V_u]=svd(full(but));
S_u=diag(S_u);
su2=S_u.^2;
sminu=min(S_u);
e1=zeros(k_u,1);
e1(1)=1;
cc=V_u'*e1;

% solve the secular equation
if newt == 1 
  [xfgr2,fxfgr2,itgr2]=mmq_solve_secul_tls_gr(su2,cc,nu2,ny2,xs,epss);
else
  [xfgr2,fxfgr2,itgr2]=mmq_solve_secul_tls_gr1(su2,cc,nu2,ny2,xs,epss);
end
itsecgr2=itsecgr2+itgr2;
itsecgr2min=min(itsecgr1min,itgr2);
itsecgr2max=max(itsecgr2max,itgr2);

s_tls2=s_tls_new;
s_tls_gr12=xfgr1;
s_tls_gr1=sqrt(xfgr1);
s_tls_gr22=xfgr2;
s_tls_gr2=sqrt(xfgr2);

fprintf(1,'   \r')
fprintf (1, 'MMQ_TLS_GK_GR_USV_OPT2: TLS Lanczos it = %4i\r', k_y);
fprintf(1,'   \r')
fprintf (1, 'Total secul trid it = %6i\r', ittridtot);
fprintf(1,'   \r')

fprintf(1,'Min singular value = %21.15e\r',S_min);
fprintf(1,'   \r')

fprintf(1,'Gauss solution = %21.15e\r',s_tls);
fprintf(1,'   \r')
fprintf(1,'Gauss-Radau solution 1 = %21.15e\r',s_tls_gr1);
fprintf(1,'   \r')
fprintf(1,'Gauss-Radau solution 2 = %21.15e\r',s_tls_gr2);
fprintf(1,'   \r')

fprintf (1, 'total secul it Gauss = %4i\r', itsec);
fprintf(1,'   \r')
fprintf (1, 'total secul it Gauss-Radau 1 = %4i\r', itsecgr1);
fprintf(1,'   \r')
fprintf (1, 'total secul it Gauss-Radau 2 = %4i\r', itsecgr2);

function y=ft(x,xi,d,nc,natc);
%FT function f(x)
%
k=length(x);
for i=1:k
  z=xi(:)./(d(:)-x(i));
  y(i)=x(i)-nc+natc*sum(z(1:end));
end

warning on