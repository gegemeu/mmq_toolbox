function [t,w]=mmq_antigaussquadrule_m(a,b,mu0);
%MMQ_ANTIGAUSSQUADRULE_M computes nodes and weights of the anti-Gauss rule
% using the Matlab QR algorithm (eig)
% a and b are the elements of the diagonal and subdiagonal of the Jacobi
% matrix for the orthonormal polynomials associated with the measure
% and mu0 the moment of order zero
%

% Author G. Meurant
% June 2007
%

n=length(a);
if n == 1
  t=a(1);
  w=mu0;
  return
end

% modify the last element in b to obtain the Anti-Gauss rule
% from the Gauss Jacobi matrix
b(n-1)=sqrt(2)*b(n-1);

J=diag(a)+diag(b,-1)+diag(b,1); 
J=full(J);
[V,D]=eig(J);
t=diag(D);
[t,i]=sort(t);
w=mu0*V(1,i).^2;
t=t';