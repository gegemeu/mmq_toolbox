function [nt,sigt,alphat,betat,dt]=mmq_tldudsfus(n,alpha,beta,sig,d,x,w,y,ud);
%MMQ_TLDUDSFUS least squares updating or downdating
% Triangular Lanczos method with special form of L, unscaled
% from Elhay, Golub and Kautsky 
%
% ud =1 if updating, -1 if downdating
%
%
% Author G. Meurant
% May 2007
%

if n == 1
 [nt,sigt,alphat,betat,dt]=mmq_rhrud(n,alpha,beta,sig,d,x,w,y,ud);
 return
end

nt=n+1;
q=w/sig;
sw=sig^2+ud*w^2;
p=(x-alpha(1))*q/beta(1);
if sw < 0
 disp('MMQ_TLDUDSFUS: Pb sw < 0 ------------')
 nt=0;
 alphat=[];
 betat=[];
 dt=[];
 return
end
sigt=sqrt(sw);
t=1+ud*q^2;
z=1-ud*q^2/t;
dh=d(1)+ud*w*y*q;
d(1)=dh/sqrt(t);
teta=p*q/t;
alpha(1)=alpha(1)+ud*teta*beta(1);
sf=dh*q/t;
dh=d(2)+ud*p*(w*y-sf);
beta(n)=1;

for i=2:nt-1
 t_new=1+ud*p^2*z;
 if t_new <= 0
  disp('MMQ_TLDUDSFUS: Pb t_new <= 0 ---------------')
  i
  t_new
  nt=i-1;
  alphat=alpha(1:nt);
  betat=beta(1:nt-1);
  dt=d(1:nt);
  return
 end % if t_new
 beta_new=beta(i-1)*sqrt(t_new/t);
 t=t_new;
 r=q;
 q=p;
 if beta(i) == 0
  disp('MMQ_TLDUDSFUS: beta(i) = 0')
  i
 end
 p=((x-alpha(i))*q-beta(i-1)*r)/beta(i);
 d(i)=dh/sqrt(t);
 sf=sf+dh*q*z/t;
 if i == n
  dh=ud*p*(w*y-sf);
 else
  dh=d(i+1)+ud*p*(w*y-sf);
 end
 alpha(i)=alpha(i)-ud*teta*beta(i-1);
 teta=p*q*z/t;
 z=z/t;
 alpha(i)=alpha(i)+ud*teta*beta(i);
 beta(i-1)=beta_new;
end % for i
pt=abs(p)*z/t;
if pt <= 0
 disp('MMQ_TLDUDSFUS: Pb pt <= 0 -------------')
end
if ud == -1 | pt <= 0
 nt=n-1;
 alphat=alpha(1:nt);
 betat=beta(1:nt-1);
 dt=d(1:nt);
 return
else
 alpha(nt)=x-teta*beta(n);
 beta(n)=beta(n)*abs(p)*sqrt(z/t);
 d(nt)=dh/(abs(p)*sqrt(z));
 alphat=alpha(1:nt);
 betat=beta(1:nt-1);
 dt=d(1:nt);
end

