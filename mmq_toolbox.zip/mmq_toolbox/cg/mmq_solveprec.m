function z=mmq_solveprec(r,a,d,l,precond,param);
%MMQ_SOLVEPREC solves M z = r
% a symmetric matrix
% the preconditioner comes from mmq_initprec
%
% d and l computed by mmq_initprec
%
% precond - type of preconditioning
%  ='no' M=I
%  ='sc' diagonal
%  ='ic' IC(0)
%  ='ch' IC(epsilon)
%  ='ss' SSOR
%
% param - parameter needed by some preconditioners
%  = nothing for 'no' and 'ic'
%  = epsilon for 'ch' 
%
% output
%  z - solution of M z = r
%
% Author G. Meurant
% Feb 2001
%
n=size(a,1);

switch precond
 
case 'no'
 z=r;
 
case 'sc'
 z=r./d;
 
case {'ic','ch','ss'}
 y=l\r;
 z=l'\(d.*y);
 
otherwise
 error('MMQ_SOLVEPREC: error, this preconditioner does not exist')
 
end


