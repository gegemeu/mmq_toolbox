function gr=mmq_comp_l_ribbon(mu,u,s,v);
%MMQ_COMP_L_RIBBON computes one point of the L-ribbon 
% computed by using the SVD (u, s, v)
%
% Author G. Meurant
% Feb 2007
%

m=size(u,1);
n=size(v,1);

d=u'*eye(m,1);

for i = 1:length(mu)
 
 mmu = mu(i);
 
 % compute (e_1)^T(C C^T + mu I)^(-2) e_1 using the singular values
 
 t = s.^2 + mmu;
 num=  sum ((d(1:n) ./ t).^2)+sum((d(n+1:m)/mmu).^2);
 
 gr(i)=num;
 
end