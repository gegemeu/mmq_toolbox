function [alpha,beta]=mmq_test_lanczosopq(N,ix);
%MMQ_TEST_LANCZOSOPQ implements the RKPW procedure 
% for  the discrete scalar
% product defined by nodes x_k and weights w_k^2

% uses the lanczosopq function from OPQ of W. Gautschi

%
% Author G. Meurant
% June 2007
%

% computation of the nodes and weights
[x,w,y,ier]=mmq_pwv(N,ix);
if ier == 1
 error('MMQ_TEST_LANCZOSOPQ: Unknown problem, abort')
end

ab=mmq_lanczosopq(N,[x w.^2]);

alpha=ab(:,1)';
beta=sqrt(ab(2:N,2)');

% computation of the eigenvalues and eigenvectors
 ni=N;
 J=spdiags([[beta(1:ni-1)'; 0] alpha(1:ni)' [0; beta(1:ni-1)']], -1:1, ni,ni);
 [V,d]=eig(full(J));
 eigJ=diag(d);
 [eigJ,ind]=sort(eigJ);
 V=V(:,ind);
 
% errors on the points
% eigenvalues of t in dts
errp=norm(x-eigJ)/norm(x);
disp('MMQ_TEST_LANCZOSOPQ: Error in the eigenvalues')
errp

% errors on the first elements of the eigenvectors
% eigenvectors in vts
errw=norm(w'-abs(V(1,:)))/norm(w);
disp('MMQ_TEST_LANCZOSOPQ: Error in the 1rst components')
errw
