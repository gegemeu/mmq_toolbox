function [nt,sigt,alphat,betat,dt]=mmq_rhrud(n,alpha,beta,sig,d,x,w,y,ud);
%MMQ_RHRUD least squares updating or downdating
% from Elhay, Golub and Kautsky with some corrections
%
% ud =1 if updating, -1 if downdating
%
% Author G. Meurant
% April 2007
%

if length(x) ~= 1 | length(w) ~= 1 | length(y) ~= 1
 error('MMQ_RHRUD: must add one point at a time')
end

nt=n+1;
%if ud == -1
% nt=n;
%end
c2=sig^2;
s2=w^2;
sw=c2+ud*s2;
if sw <= 0
 nt=0;
 disp('MMQ_RHRUD: pb sig^2+ud*w^2 <= 0')
 return
end
sigt=sqrt(sw);
% rotation between the first and last line to obtain 
% R_1 (sig 0 ... 0 w)^T = (sig_tilde 0 ... 0)^T
c2=c2/sw;
s2=s2/sw;
cs=(sig*w)/sw;
% CAUTION
c=sig/sigt;
s=w/sigt;
sig=sigt;
teta1=cs*(x-alpha(1));
alpha(nt)=c2*x+ud*s2*alpha(1);
alpha(1)=c2*alpha(1)+ud*s2*x;
if n > 1
 teta2=-s*beta(1);
 beta(1)=c*beta(1);
end
d(nt)=c*w*y-s*d(1);
d(1)=c*d(1)+ud*s*w*y;

for i=2:nt-1
 c2=beta(i-1)^2;
 s2=teta1^2;
 bt=c2+ud*s2;
 if bt <= 0
  bt
  nt=i-1;
  disp('MMQ_RHRUD: pb beta(i-1)^2+ud*teta1^2 <= 0')
  alphat=alpha(1:nt);
  betat=beta(1:nt-1);
  dt=d(1:nt);
  return
 end % if bt
 xi=sqrt(bt);
 % rotation to annihilate teta_1 in the last line
 c2=c2/bt;
 s2=s2/bt;
 cs=(beta(i-1)*teta1)/bt;
 c=beta(i-1)/xi;
 s=teta1/xi;
 % CAUTION
 beta(i-1)=xi;
 cs2=2*cs*teta2;
 if ud == -1
  t=alpha(i)-cs2+s2*(alpha(i)-alpha(nt));
  r=alpha(i)+alpha(nt)-t;
 else
  t=c2*alpha(i)+s2*alpha(nt)+cs2;
  r=c2*alpha(nt)-cs2+s2*alpha(i);
 end
 teta1=cs*alpha(nt)-(cs*alpha(i)-teta2*(c2-ud*s2));
 if ud == -1
  teta1=cs*alpha(nt)-(cs*alpha(i)-teta2*(1+2*s2));
 end
 alpha(i)=t;
 alpha(nt)=r;
 if i ~= nt-1 
  teta2=-s*beta(i);
  old_bet=beta(i);
  beta(i)=c*beta(i);
 end % if i
 t=d(i);
 d(i)=c*t+ud*s*d(nt);
 d(nt)=c*d(nt)-s*t;
end % for i
if teta1 == 0
 disp('MMQ_RHRUD: teta1 = 0')
end
if ud == -1
 beta(nt-1)=abs(teta1);
 ni=nt-1;
end
if ud == -1 
 nt=n-1;
 %nt=n;
else
 beta(nt-1)=abs(teta1);
 d(nt)=sign(teta1)*d(nt);
end

alphat=alpha(1:nt);
if nt > 1
 betat=beta(1:nt-1);
else
 betat=[];
end
dt=d(1:nt);

