function [xf,it,xs]=mmq_solve_secul_bk(d,c,epss,meth);
%MMQ_SOLVE_SECUL_BK solves the Backward Error secular equation
% algorithm 'meth'
%
% Author G. Meurant
% august 2008
%

global lm;

warning off
ny2=1;
ny21=1/ny2;
k=length(d);
n=k;
m=length(c);

% 0 is the first pole
ii=1;
del(1)=0;
del(2:n+1)=d;
d_old=d;
d=del;

% we need the components squared
xi(1)=sum(c(n+1:m).^2);
xi(2:n+1)=c(1:n).^2;

% find the starting point (Melman)

% find an approximation of tf(t)
h0=ht(xi,d,0,ii);
del=d(2);
hd=ht(xi,d,del,ii);
q=del*hd/(hd-h0);
p=h0*q;
% find the zero of the interpolant i.e. the starting point 
tft0=tft(0,xi(1),xi(2),del,p,q,ny21);
tftd=tft(del-1e-12,xi(1),xi(2),del,p,q,ny21);
if isnan(tft0) | isnan(tftd) | isinf(tft0) | isinf(tftd) | tft0*tftd > 0
 tftd2=tft(del/2,xi(1),xi(2),del,p,q,ny21);
 [xs,fs,exitf]=fzero(@tft,del/2,[],xi(1),xi(2),del,p,q,ny21);
 if isnan(xs)
  xs=del/2;
 end
else
 [xs,fs,exitf]=fzero(@tft,[0 del-1e-12],[],xi(1),xi(2),del,p,q,ny21);
end

del=0;

itmax=50;
it=0;
sc=1;
x_old=xs;

while it < itmax & sc > epss
 it=it+1;
 % compute the interpolants
 % function and derivative of psi at the interpolation point x_old
 %[yx_psi,yxp_psi]=secul1(xi,d,x_old,ii);
 % function and derivative of phi at the interpolation point x_old
 [yx_phi,yxp_phi]=secul2(xi,d,x_old,ii);
 
 switch meth
  
  case 'b1'
   % parameters of BNS1
   %q=x_old+yx_psi/yxp_psi;
   q=0;
   %p=yx_psi^2/yxp_psi;
   p=xi(1);
   % interpolant is p/x
   r=yx_phi-(d(2)-x_old)*yxp_phi;
   s=(d(2)-x_old)^2*yxp_phi;
   % interpolant is r+s/(d-x)
   % solve the quadratic equation 1+p/(q-x)+r+s/(d-x)
   % quadratic equation
   aa=r-1;
   bb=aa*del+p+s;
   cc=p*del;
   
  case 'b2'
   % parameters of BNS2
   q=x_old+yx_phi/yxp_phi;
   p=yx_phi^2/yxp_phi;
   % interpolant is p/(q-x)
   r=yx_psi-(-x_old)*yxp_psi;
   s=(-x_old)^2*yxp_psi;
   % interpolant is r+s/(d-x)
   % quadratic equation
   %aa=r+1;
   aa=r+ny21;
   dell=0;
   bb=aa*q+p+s;
   cc=s*q;
   
  case 'mw'
   % parameters of BNS1 for phi
   rr=yx_phi-(d(2)-x_old)*yxp_phi;
   ss=(d(2)-x_old)^2*yxp_phi;
   % interpolant is rr+ss/(d-x)
   % parameters of BNS2 for psi
   r=yx_psi-(-x_old)*yxp_psi;
   s=(-x_old)^2*yxp_psi;
   % interpolant is r+s/(-x)
   aa=rr+r+ny21;
   dell=d(2);
   bb=aa*dell+ss+s;
   cc=s*dell;
   
  case 'f1'
   % parameters of FW1
   xi1=xi(1);
   ft=ny21+yx_psi+yx_phi;
   ftp=yxp_psi+yxp_phi;
   dt=del-x_old;
   xx=xi1/x_old^2;
   r=ft-dt*ftp+del*xx;
   s=dt^2*(ftp-xx);
   % interpolant is \bar r+\bar s/(d-x)+r+s/(-x)
   aa=r;
   bb=aa*del+xi1+s;
   cc=xi1*del;
   
  case 'f2'
   % parameters of FW2
   xi1=xi(1);
   ft=ny21+yx_psi+yx_phi;
   ftp=yxp_psi+yxp_phi;
   dt=del-x_old;
   xx=xi1/(del-x_old)^2;
   r=ft+x_old*ftp-del*xx;
   s=-x_old^2*(ftp-xx);
   % the interpolant is\bar r+\bar s/(d-x)+r+s/(-x)
   aa=r;
   bb=aa*del-s+xi1;
   cc=-s*del;
   
  case 'gr'
   % parameters of Gragg
   % second derivative of psi at the interpolation point x_old
   yxpp_psi=secul3(xi,d,x_old,ii);
   % second derivative of phi at the interpolation point x_old
   yxpp_phi=secul4(xi,d,x_old,ii);
   xi1=xi(1);
   ft=ny21+yx_psi+yx_phi;
   ftp=yxp_psi+yxp_phi;
   ftpp=yxpp_psi+yxpp_phi;
   dt=del-x_old;
   c=dt^3*ftp/del+x_old*dt^3*ftpp/(2*del);
   b=(ftpp*dt-2*ftp)*x_old^3/(2*del);
   a=ft-ftpp*x_old*(del-x_old)/2+(2*x_old-del)*ftp;
   % the interpolant is \bar r+\bar s/(d-x)+r+s/(-x)
   aa=a;
   bb=aa*del-b+c;
   cc=-b*del;
   
  otherwise
   error('MMQ_SOLVE_SECUL_BK: this method does not exist')
 end
 
 % solution of the quadratic equation
 delta=bb^2-4*aa*cc;
 if delta < 0
  disp('MMQ_SOLVE_SECUL_BK: quadratic equation has no real solution')
  return
 end
 delta=sqrt(delta);
 xm=(bb-delta)/(2*aa);
 xp=(bb+delta)/(2*aa);
 x_new=min(xm,xp);
 sc=abs(x_new-x_old)/abs(x_old);
 x_old=x_new;
end
xf=x_new;
fxf=1+xi(1)/xf-secul2(xi,d,xf,ii);
flm=1+xi(1)/lm-secul2(xi,d,lm,ii);

% check by dichotomy
if xf >= 0
 xf=-0.1;
 fxf=1+xi(1)/xf-secul2(xi,d,xf,ii);
 idiv=1;
 while  fxf < 0 & idiv < 100
  idiv=idiv+1;
  xf=xf*2;
  fxf=1+xi(1)/xf-secul2(xi,d,xf,ii);
 end
end
xl=xf;
yl=fxf;
xr=-1e-16;
yr=1+xi(1)/xr-secul2(xi,d,xr,ii);
if yl*yr < 0
 disp('MMQ_SOLVE_SECUL_BK: dichotomy')
 itdmax=100;
 sc=1;
 itd=0;
 
 while itd <= itdmax & sc > epss
  itd=itd+1;
  xm=(xl+xr)/2;
  ym=1+xi(1)/xm-secul2(xi,d,xm,ii);
  if yl*ym < 0
   xr=xm;
  else
   xl=xm;
  end
  sc=abs(xr-xl)/abs((xr+xl)/2);
 end
 S_min=(xl+xr)/2;
 if itd >= itdmax
  disp('MMQ_SOLVE_SECUL_BK: no conv solve_dich_secul_bk')
 else
  xf=S_min;
  fxf=1+xi(1)/xf-secul2(xi,d,xf,ii);
 end
end

warning on

function y=tft(x,xi1,xi2,del,p,q,ny21);
%TFT function x f(x)
%
%y=x-(xi1+xi2)+(del*xi2)./(del-x)+(p*x)./(q-x);
y=x*ny21-(xi1+xi2)+(del*xi2)./(del-x)+(p*x)./(q-x);

function y=ht(xi,dts,x,ii);
%HT function for starting point
%
k=length(x);
for i=1:k
 z=xi(:)./(dts(:)-x(i));
 y=sum(z(ii+2:end));
end

function [y,yp]=secul1(xi,dts,x,ii);
%SECUL1 function f and f'
%
k=length(x);
for i=1:k
 z=-xi(1)./x(i);
 y(i)=z;
 zp=xi(1)./x(i).^2;
 yp(i)=zp;
end

function [y,yp]=secul2(xi,dts,x,ii);
%SECUL2 function f and f'
%
k=length(x);
for i=1:k
 z=xi(:)./(dts(:)-x(i));
 y(i)=sum(z(ii+1:end));
 zp=xi(:)./(dts(:)-x(i)).^2;
 yp(i)=sum(zp(ii+1:end));
end

function ypp=secul3(xi,dts,x,ii);
%SECUL3  f''
%
k=length(x);
for i=1:k
 zpp=xi(:)./(dts(:)-x(i)).^3;
 ypp(i)=sum(zpp(1:ii));
end

function ypp=secul4(xi,dts,x,ii);
%SECUL4 f''
%
k=length(x);
for i=1:k
 zpp=xi(:)./(dts(:)-x(i)).^3;
 ypp(i)=sum(zpp(ii+1:end));
end