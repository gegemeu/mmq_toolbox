function [alpha,beta]=mmq_stieltjes_monic(N,ix);
%MMQ_STIELTJES_MONIC implements the Stieltjes procedure 
% for monic orthogonal polynomials and the discrete scalar
% product defined by nodes x_k and weights w_k^2

% uses the Stieltjes function from OPQ of W. Gautschi

%
% Author G. Meurant
% June 2007
%

% computation of the nodes and weights
[x,w,y,ier]=mmq_pwv(N,ix);
if ier == 1
 error('MMQ_STIELTJES_MONIC: Unknown problem, abort')
end

ab=stieltjes(N,[x w.^2]);

alpha=ab(:,1)';
beta=sqrt(ab(2:N,2)');


