function x=mmq_solipp(mu,u,s,v,y);
%MMQ_SOLIPP solution of an ill-posed problem using the SVD (u, s, v)
% mu is the regularization parameter as in (A^T A+mu I)x=y
%
% Author G. Meurant
% Jan 2007
%
r=length(y);
  x = u(:, 1:r)' * y;
  x = (s .* x) ./ (s.^2 + mu);
  x = v(:, 1:r) * x;