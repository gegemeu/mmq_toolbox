function [lbx,ubx,lbr,ubr]=mmq_l_ribbon_reort(a,y,kmax);
%MMQ_L_RIBBON_REORT computes the L-ribbon from the paper by Calvetti, Hansen and Reichel
% ETNA 2002
%
% Lanczos bidiagonalization to compute lower and upper bounds of the L-curve
% with reorthogonalization
%
% Author G. Meurant
% Feb 2007
%

ny=norm(y);
naty=norm(a'*y);

% compute the exact L-curve and the limits

np=50;
[rho,eta,mu,lambdamin,lambdamax]=mmq_comp_l_curve1(a,y,np);

iplot=0;
if iplot == 1
 hr=figure;
 plot(log10(mu),log10(rho))
 hold on 
 
 hx=figure;
 plot(log10(mu),log10(eta))
 hold on 
 
 hl=figure;
 plot(log10(rho),log10(eta))
 hold on
 plot(log10(rho),log10(eta),'xr')
 
 hl1=figure;
 plot(log10(rho),log10(eta))
 rmin=1.1*log10(min(rho));
 xmin=1.1*log10(min(eta));
 rmax=1.1*log10(max(rho));
 xmax=1.1*log10(max(eta));
 axis([rmin rmax xmin xmax])
 hold on
 pause
end

% start the Lanczos iterations
% similar to l_bidiagaat

k=kmax;
c=sparse(k+1,k+1);
uu=zeros(length(y),k+1);
vv=uu;

% init
u_old=y/norm(y);
w=a'*u_old;
c(1,1)=norm(w);
v_old=w/c(1,1);
uu(:,1)=u_old;
vv(:,1)=v_old;

for i=2:k+1
 w=a*v_old-c(i-1,i-1)*u_old;
 c(i,i-1)=norm(w);
 u=w/c(i,i-1);
 
 % reorthogonalization
 
 for j=1:i-1
  alpha=(u'*uu(:,j))/(uu(:,j)'*uu(:,j));
  u=u-alpha*uu(:,j);
 end
 
 w=a'*u-c(i,i-1)*v_old;
 c(i,i)=norm(w);
 v=w/c(i,i);
 
 % reorthogonalization
 
 for j=1:i-1
  alpha=(v'*vv(:,j))/(vv(:,j)'*vv(:,j));
  v=v-alpha*vv(:,j);
 end
 uu(:,i)=u;
 vv(:,i)=v;
 
 u_old=u;
 v_old=v;
 
 if i > 3
  cc=c(1:i-1,1:i-1);
  ccb=c(1:i,1:i-1);
  [q,cch]=qr(full(ccb),0);
  if any(diag(cch) < 0)
   cch=-cch;
  end
  cch=cch';
  % remove the last column
  cchb=cch(:,1:end-1);
  
  % compute the approximations using SVDs rather than
  % solving least squares problems
  [ucc,scc,vcc]=svd(full(cc));
  scc=diag(scc);
  [uccb,sccb,vccb]=svd(full(ccb));
  sccb=diag(sccb);
  [ucch,scch,vcch]=svd(full(cch));
  scch=diag(scch);
  [ucchb,scchb,vcchb]=svd(full(cchb));
  scchb=diag(scchb);
  
  gcc=mmq_comp_l_ribbon(mu,ucc,scc,vcc);
  lbr=ny^2*mu.^2.*gcc;
  
  gccb=mmq_comp_l_ribbon(mu,uccb,sccb,vccb);
  ubr=ny^2*mu.^2.*gccb;
  
  gcch=mmq_comp_l_ribbon(mu,ucch,scch,vcch);
  lbx=naty^2*gcch;
  
  gcchb=mmq_comp_l_ribbon(mu,ucchb,scchb,vcchb);
  ubx=naty^2*gcchb;
  
  lbr=sqrt(lbr);
  ubr=sqrt(ubr);
  lbx=sqrt(lbx);
  ubx=sqrt(ubx);
  
  if iplot == 1
   figure(hr);
   if mod(i,2) == 0
    plot(log10(mu),log10(lbr),'r')
    plot(log10(mu),log10(ubr),'g')
   else
    plot(log10(mu),log10(lbr),'m--')
    plot(log10(mu),log10(ubr),'c--')
   end
   
   figure(hx);
   if mod(i,2) == 0
    plot(log10(mu),log10(lbx),'r')
    plot(log10(mu),log10(ubx),'g')
   else
    plot(log10(mu),log10(lbx),'m--')
    plot(log10(mu),log10(ubx),'c--')
   end
   
   figure(hl1);
   if mod(i,2) == 0
    plot(log10(ubr),log10(ubx),'g')
    plot(log10(lbr),log10(lbx),'r')
   else
    plot(log10(ubr),log10(ubx),'g--')
    plot(log10(lbr),log10(lbx),'r--')
   end
   axis([rmin rmax xmin xmax])
  end
  
 end
end

if iplot == 1
 figure(hr);
 hold off
 figure(hx);
 hold off
 figure(hl1);
 plot(log10(lbr),log10(lbx),'m')
 plot(log10(ubr),log10(ubx),'c')
 axis([rmin rmax xmin xmax])
 hold off
 
 figure(hl);
 for j=1:length(mu)
  plot([log10(lbr(j)) log10(lbr(j))],[log10(lbx(j)) log10(ubx(j))],'r')
  plot([log10(lbr(j)) log10(ubr(j))],[log10(ubx(j)) log10(ubx(j))],'r')
  plot([log10(ubr(j)) log10(ubr(j))],[log10(lbx(j)) log10(ubx(j))],'r')
  plot([log10(lbr(j)) log10(ubr(j))],[log10(lbx(j)) log10(lbx(j))],'r')
  plot(log10(lbr(j)),log10(lbx(j)),'om')
 end
 hold off
end

