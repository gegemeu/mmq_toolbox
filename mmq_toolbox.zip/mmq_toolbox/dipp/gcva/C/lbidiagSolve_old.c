/* lbidiagSolve.c, MATLAB Version 4

   The calling syntax is:

       x = lbidiagSolve (gamma, delta, b)

   This procedure solves the linear system  L * x = b,
   where L is an n-by-n lower bidiagonal matrix:

           [ gamma(1)                                 ]
           [ delta(1)  ...                            ]
       L = [           ...  ...                       ]
           [                ...     ...               ]
           [                     delta(n-1)  gamma(n) ]

   Urs von Matt, October 27, 1994 */



#include <math.h>
#include "mex.h"



static void lbidiagSolve (n, gamma, delta, b, x)
  int    n;
  double *gamma, *delta, *b, *x;

{ int i;

  x [0] = b [0] / gamma [0];
  for (i = 1; i < n; i++) {
    x [i] = (b [i] - delta [i-1] * x [i-1]) / gamma [i];
  }
}



#define max(A, B)  ((A) > (B) ? (A) : (B))
#define min(A, B)  ((A) < (B) ? (A) : (B))

/* Input Arguments */
#define	gamma prhs[0]
#define	delta prhs[1]
#define	b     prhs[2]

/* Output Arguments */
#define	x plhs[0]

extern mexFunction (nlhs, plhs, nrhs, prhs)
  int    nlhs, nrhs;
  Matrix *plhs[], *prhs[];

{ int n;

  /* Check for proper number of arguments */
  if (nrhs != 3) {
    mexErrMsgTxt ("lbidiagSolve requires three input arguments.");
  } else if (nlhs != 1) {
    mexErrMsgTxt ("lbidiagSolve requires one output argument.");
  }

  /* Check the dimensions of gamma. */
  n = max (mxGetM (gamma), mxGetN (gamma));
  if (min (mxGetM (gamma), mxGetN (gamma)) != 1) {
    mexErrMsgTxt ("gamma must be an n-by-1 or a 1-by-n matrix.");
  }

  /* Check the dimensions of delta. */
  if (n > 1) {
    if ((min (mxGetM (delta), mxGetN (delta)) != 1) ||
        (max (mxGetM (delta), mxGetN (delta)) != n-1)) {
      mexErrMsgTxt ("delta must be an (n-1)-by-1 or a 1-by-(n-1) matrix.");
    }
  }

  /* Check the dimensions of b. */
  if ((mxGetM (b) != n) || (mxGetN (b) != 1)) {
    mexErrMsgTxt ("b must be an n-by-1 matrix.");
  }

  /* Create vector for the return arguments. */
  x = mxCreateFull (n, 1, REAL);

  /* Do the actual computations in a subroutine. */
  lbidiagSolve (n, mxGetPr (gamma), mxGetPr (delta), mxGetPr (b),
                mxGetPr (x));
}
