function [a,b,mu0]=mmq_corthopolgl(swt,n,alpha,beta,node1,node2);
%MMQ_CORTHOPOLGL computes the Jacobi matrix for classical orthogonal
% polynomials for the Gauss-Lobatto rule with  preassigned nodes
% node 1 and node2 which must be outside of the given interval
% modification  of the last diagonal coefficient

% Author G. Meurant
% March 2008

% compute the Gauss Jacobi matrix
[a,b,mu0]=mmq_classicorthopoly(swt,n,alpha,beta);

% modify the last element diagonal element and the last subdiagonal element

% tridiagonal solve of (J_{n-1}- node I) delta = (0 0 ... 1)^T

t=spdiags([b' a(1:n-1)' [0 b(1:n-2)]'], -1:1, n-1, n-1);

e=zeros(n-1,1);
e(n-1)=1;
d1=(t-node1*speye(n-1))\e;
d2=(t-node2*speye(n-1))\e;

x=[1 -d1(n-1); 1 -d2(n-1)]\[node1; node2];

a(n)=x(1);
b(n-1)=sqrt(x(2));

