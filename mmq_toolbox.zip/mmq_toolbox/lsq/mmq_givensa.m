function [c,s,c2,s2,cs,r]=mmq_givensa(a,b);
%MMQ_GIVENSA computes Givens rotation to zero b, E. Anderson version
%
% The rotation matrix is 
%  |  c  s |
%  | -s  c |
%

% Author G. Meurant
% nov 2007

if b == 0
 c=sign(a);
 s=0;
 r=abs(a);
elseif a == 0
 c=0;
 s=sign(b);
 r=abs(b);
elseif abs(a) > abs(b)
 t=b/a;
 u=sign(a)*sqrt(1+t^2);
 c=1/u;
 s=t*c;
 r=a*u;
else
 t=a/b;
 u=sign(b)*sqrt(1+t^2);
 s=1/u;
 c=t*s;
 r=b*u;
end

c2=c^2;
s2=s^2;
cs=c*s;
