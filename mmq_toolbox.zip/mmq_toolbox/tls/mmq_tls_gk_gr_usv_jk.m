 function [s_tls,s_tls2,s_tls_gr1,s_tls_gr12,s_tls_gr2,s_tls_gr22,Scc,Jk]=mmq_tls_gk_gr_usv_jk(uu,s,v,y,epsi);
%MMQ_TLS_GK_GR_USV_JK Golub-Kahan bidiagonalization of K (given by uu, s, v) for large matrices
% similar to mmq_tls_gk_gr_usv_opt6 but returns jk
% optimized version
% monitor the convergence of the tls parameter
%  Gauss and Gauss-Radau at the end by solving tridiagonal systems

% bidiagonalization with y (K' y) as starting vector

warning off

end_of_Lanczos=0;
success=0;
bidiag_tol=1e-15;
itmax=1500;
m=length(uu);
n=length(v);
%kmax=max(m,n);
kmax=itmax;
kmax=min(itmax,kmax);
bidiag_y=1;
s_tls_old=1;
itsec=0;
itsecmin=realmax;
itsecmax=realmin;
itsecgr1=0;
itsecgr1min=realmax;
itsecgr1max=realmin;
itsecgr2=0;
itsecgr2min=realmax;
itsecgr2max=realmin;
comp_sec=1;
sc=realmax;
ittridtot=0;


S_min_old=sqrt(realmax);
Sc=realmax;

% init 

% Lanczos bidiagonalization II = Bidiag1
% y as a starting vector

normy=norm(y);
ny2=normy^2;
nay2=norm(mmq_pmatat(uu,s,v,y))^2;
p_y = y / normy;
q_y=mmq_pmatat(uu,s,v,p_y);
gamma_y (1) = norm (q_y, 2);
by(1,1)=gamma_y(1);
if abs (gamma_y (1)) <= bidiag_tol
  fprintf (1, 'MMQ_TLS_GK_GR_USV_JK: || K'' y || <= c * eps * || y ||\n');
  success = 1;
  return;
end
q_y = q_y / gamma_y (1);
p_y=mmq_pmata(uu,s,v,q_y)-gamma_y(1)*p_y;
delta_y (1) = norm (p_y, 2);
by(2,1)=delta_y(1);
if abs (delta_y (1)) <= bidiag_tol
  bidiag_y = 0;
  fprintf (1, 'MMQ_TLS_GK_GR_USV_JK: bidiag_y = 0\n');
else %if
  p_y = p_y / delta_y (1);
end %if abs(delta
k_y=1;
Bk=[gamma_y(1); delta_y(1)];
Jk=Bk'*Bk;
SJ_min=min(eig(Jk));

% Lanczos bidiagonalization I = Bidiag2
% u=K'y as a starting vector

%u=K'*y;
u=mmq_pmatat(uu,s,v,y);
normu=norm(u);
nu2=normu^2;
q_u = u / normu;
%p_u = K * q_u;
p_u=mmq_pmata(uu,s,v,q_u);
gamma_u (1) = norm (p_u, 2);
bu(1,1)=gamma_u(1);
if abs (gamma_u (1)) <= bidiag_tol
  bidiag_y = 0;
  fprintf (1, 'MMQ_TLS_GK_GR_USV_JK: bidiag_u = 0\n');
else
  p_u = p_u / gamma_u (1);
end
k_u = 1;

sc=0;
while ~(end_of_Lanczos | success)
  %fprintf (1, 'MMQ_TLS_GK_GR_USV_OPT6: Lanczos it = %4i, Sc = %12.8e\r', k_y+1,Sc);
  
  % update bidiagonalization II
  
  q_y=mmq_pmatat(uu,s,v,p_y)-delta_y(k_y)*q_y;
  gamma_y (k_y+1) = norm (q_y, 2);
  if abs (gamma_y (k_y+1)) <= bidiag_tol
    gamma_y = gamma_y (1:k_y);
    bidiag_y = 0;
    fprintf (1, 'MMQ_TLS_GK_GR_USV_JK: bidiag_y = 0\n');
  else
    k_y = k_y + 1;
    q_y = q_y / gamma_y (k_y);
    by(k_y,k_y)=gamma_y(k_y);
    p_y=mmq_pmata(uu,s,v,q_y)-gamma_y(k_y)*p_y;
    delta_y (k_y) = norm (p_y, 2);
    if abs (delta_y (k_y)) <= bidiag_tol
      bidiag_y = 0;
      fprintf (1, 'MMQ_TLS_GK_GR_USV_JK: bidiag_y = 0\n');
    else %if
      p_y = p_y / delta_y (k_y);
      by(k_y+1,k_y)=delta_y(k_y);
    end %if abs(delta
  end %if abs(gamma
  alpha=gamma_y(k_y)^2+delta_y(k_y)^2;
  beta=gamma_y(k_y)*delta_y(k_y-1);
  
  compsec=1;
  
  end_of_Lanczos = (~bidiag_y) | (k_y >= kmax+1);
  
  if comp_sec ==1
    
    epss=epsi/10;
    [SJ_min,ittrid]=mmq_solve_secul_trid(SJ_min,Jk,alpha,beta,epss);
    ittridtot=ittridtot+ittrid;
    
    S_min_new=sqrt(SJ_min);
    Sc=abs(S_min_new^2-S_min_old^2)/abs(S_min_old^2);
    S_min_old=S_min_new;
    
    ek=zeros(k_y-1,1);
    ek(k_y-1)=1;
    Jk=[Jk beta*ek; beta*ek' alpha];
    
    JJk=by(1:k_y+1,1:k_y)'*by(1:k_y+1,1:k_y);
    % solve the secular equation  by rational approximation method
    epss=epsi/10;
    % S_min is supposed to be the first pole
    e1=zeros(k_y+1,1);
    e1(1)=1;
    yy=by(1:k_y+1,1:k_y)'*e1;
    S_min=S_min_new;
    [s_tls_new,its]=mmq_solve_secul_rat(S_min^2,JJk,yy,ny2,ny2,epss);
    Sc=abs(s_tls_new-s_tls_old)/abs(s_tls_old);
    %fprintf (1, 'MMQ_TLS_GK_GR_USV_JK: secul iterations = %4i\r', its);
    itsec=itsec+its;
    itsecmin=min(itsecmin,its);
    itsecmax=max(itsecmax,its);
    s_tls=sqrt(s_tls_new);
    s_tls_old=s_tls_new;
    
    if Sc <= epsi
     end_of_Lanczos=1;
    end

  end
  Scc(k_y)=Sc;
  
  % Gauss-Radau
  % update bidiagonalization I with u as starting vector
  
  q_u=mmq_pmatat(uu,s,v,p_u)-gamma_u(k_u)*q_u;
  delta_u (k_u) = norm (q_u, 2);
  bu(k_u,k_u+1)=delta_u(k_u);
  if abs (delta_u (k_u)) <= bidiag_tol
    delta_u = delta_u (1:k_u-1);
    bidiag_y = 0;
    fprintf (1, 'MMQ_TLS_GK_GR_USV_JK: bidiag_u = 0\n');
  else
    k_u = k_u + 1;
    q_u = q_u / delta_u (k_u-1);
    p_u=mmq_pmata(uu,s,v,q_u)-delta_u(k_u-1)*p_u;
    gamma_u (k_u) = norm (p_u, 2);
    if abs (gamma_u (k_u)) <= bidiag_tol
      bidiag_y = 0;
      fprintf (1, 'MMQ_TLS_GK_GR_USV_JK: bidiag_u = 0\n');
    else
      p_u = p_u / gamma_u (k_u);
      bu(k_u,k_u)=gamma_u(k_u);
    end
  end
  
end %while

% compute Gauss when converged

% computation of the SVD of B_k
Jk=by(1:k_y+1,1:k_y)'*by(1:k_y+1,1:k_y);
% the smallest and largest eigenvalue should be computed
% using secular equations
% we use this temporarily for S_max which is not computed above
eigJk=eig(full(Jk));
S_max=sqrt(max(eigJk));

S_min=S_min_new;

% solve the secular equation  by rational approximation method
meth='gr';
epss=epsi/10;
% S_min is supposed to be the first pole
e1=zeros(k_y+1,1);
e1(1)=1;
yy=by(1:k_y+1,1:k_y)'*e1;
[s_tls_new,its]=mmq_solve_secul_rat(S_min^2,Jk,yy,ny2,ny2,epss);
%fprintf (1, 'MMQ_TLS_GK_GR_USV_JK: secul iterations = %4i\r', its);
itsec=itsec+its;
itsecmin=min(itsecmin,its);
itsecmax=max(itsecmax,its);
s_tls=sqrt(s_tls_new);
%fprintf(1,'MMQ_TLS_GK_GR_USV_JK: Gauss solution = %21.15e\r',s_tls);

% Gauss-Radau when converged

% compute the SVD of modified bu (upper bidiagonal)
bbu=bu(1:k_u,1:k_u);
% We must modify bu to get the Gauss-Radau rule with a min of sing. val.
% Tk is tridiagonal
Tk=bu(1:k_u-1,1:k_u-1)'*bu(1:k_u-1,1:k_u-1);
ek=zeros(k_u-1,1);
ek(k_u-1)=1;
%% take the min of singular values of K to start
buk2=(gamma_u(k_u-1)*delta_u(k_u-1))^2;
%smi=smin
% Use 0 as the min
%smi=0;
% Use the smallest sing value
smi=S_min^2;
dd=(Tk-smi*speye(k_u-1,k_u-1))\(buk2*ek);
om=smi+dd(k_u-1);
% modify the last diagonal entry of the Cholesky decomposition bu' * bu
gammat=om-delta_u(k_u-1)^2;
but=bbu;
but(k_u,k_u)=sqrt(gammat);
Jk=but'*but;

% solve the secular equation
yy=zeros(k_u,1);
yy(1)=1;
[xfgr1,itgr1]=mmq_solve_secul_rat(S_min^2,Jk,yy,ny2,nay2,epss);
itsecgr1=itsecgr1+itgr1;
itsecgr1min=min(itsecgr1min,itgr1);
itsecgr1max=max(itsecgr1max,itgr1);

% We must modify bu to get the Gauss-Radau rule with a max of sing. val.
% take the max of singular values of K to start
buk2=(gamma_u(k_u-1)*delta_u(k_u-1))^2;
%smi=smax;
smi=S_max^2;
dd=(Tk-smi*speye(k_u-1,k_u-1))\(buk2*ek);
om=smi+dd(k_u-1);
% modify the Cholesky decomposition bu' * bu
gammat=om-delta_u(k_u-1)^2;
but=bbu;
but(k_u,k_u)=sqrt(gammat);
Jk=but'*but;

% solve the secular equation
[xfgr2,itgr2]=mmq_solve_secul_rat(S_min^2,Jk,yy,ny2,nay2,epss);
itsecgr2=itsecgr2+itgr2;
itsecgr2min=min(itsecgr1min,itgr2);
itsecgr2max=max(itsecgr2max,itgr2);

s_tls2=s_tls_new;
s_tls_gr12=xfgr1;
s_tls_gr1=sqrt(xfgr1);
s_tls_gr22=xfgr2;
s_tls_gr2=sqrt(xfgr2);

fprintf(1,'   \r')
fprintf (1, 'MMQ_TLS_GK_GR_USV_JK: TLS Lanczos it = %4i\r', k_y);
fprintf(1,'   \r')
fprintf (1, 'Total secul trid it = %6i\r', ittridtot);
fprintf(1,'   \r')

fprintf(1,'Min singular value = %21.15e\r',S_min);
fprintf(1,'   \r')

fprintf(1,'Gauss solution = %21.15e\r',s_tls);
fprintf(1,'   \r')
fprintf(1,'Gauss-Radau solution 1 = %21.15e\r',s_tls_gr1);
fprintf(1,'   \r')
fprintf(1,'Gauss-Radau solution 2 = %21.15e\r',s_tls_gr2);
fprintf(1,'   \r')

fprintf (1, 'total secul it Gauss = %4i, min = %4i, max = %4i, av. = %4.2f\r', itsec,itsecmin,itsecmax,itsec/(k_y+1));
fprintf(1,'   \r')
fprintf (1, 'total secul it Gauss-Radau 1 = %4i\r', itsecgr1);
fprintf(1,'   \r')
fprintf (1, 'total secul it Gauss-Radau 2 = %4i\r', itsecgr2);

warning off

