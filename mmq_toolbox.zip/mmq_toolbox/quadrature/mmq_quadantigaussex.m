function int=mmq_quadantigaussex(iex,n);
%MMQ_QUADANTIGAUSSEX examples of computations of integrals with Anti-Gauss quadrature
%
% Author G. Meurant
% March 2008
%


switch(iex)
 case 1
  % Legendre weight function, f(x)=x^20
  [a,b,mu0]=mmq_corthopolag('le',n,0,0);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=t.^(20);
  
 case 2
  % Legendre weight function, f(x)=exp(x)
  [a,b,mu0]=mmq_corthopolag('le',n,0,0);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=exp(t);
  
 case 3
  % Legendre weight function, f(x)=1/(1+10 x^2)
  [a,b,mu0]=mmq_corthopolag('le',n,0,0);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=1./(1+10*t.^2);
  
 case 4
  % Legendre weight function, f(x)=exp(-1/x^2)
  [a,b,mu0]=mmq_corthopolag('le',n,0,0);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=exp(-1./t.^2);
  
 case 5
  % Legendre weight function, f(x)=(1-x^2)^(-1/2)
  [a,b,mu0]=mmq_corthopolag('le',n,0,0);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=1./sqrt(1-t.^2);
  
 case 6
  % Chebyshev weight function, f(x)=(1-x^2)^(-1/2)
  [a,b,mu0]=mmq_corthopolag('c1',n,0,0);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=ones(1,n);
  
 case 7
  % Legendre weight function, f(x)=(1-x^2)^(1/2)/(2+x)^(1/2)
  [a,b,mu0]=mmq_corthopolag('le',n,0,0);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=sqrt(1-t.^2)./sqrt(2+t);
  
   case 8
  % Chebyshev second kind weight function, f(x)=1/(2+x)^(1/2)
  [a,b,mu0]=mmq_corthopolag('c2',n,0,0);
  [t,w]=mmq_gaussquadrule(a,b,0,mu0,0);
  
  ft=1./sqrt(2+t);
  
 otherwise
  error('MMQ_QUADANTIGAUSSEX: Unknown example')
  int=0;
  return
  
end

int=sum(w.*ft);