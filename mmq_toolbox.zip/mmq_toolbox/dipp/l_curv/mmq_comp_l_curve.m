function [rho,eta,mu,err]=mmq_comp_l_curve(a,y,np,x0);
%MMQ_COMP_L_CURVE computes the l-curve 
% computed by using the SVD of a
%
% rho : norm of r
% eta : norm of x
% mu  : values of the parameter
% err : norm of the error with the solution x0 of the unperturbed pb 
%
% Author G. Meurant
% Feb 2007
%
% compute the SVD

[u,s,v]=svd(a);
s=diag(s);
maxs=max(s);
m=size(a,1);

normK=norm(a,'fro');
% useful range for lambda
lambdamax = maxs^2;
lambdamin = (eps * normK);
lambdamin=lambdamin/10;

a=log10(m*lambdamin);
b=log10(m*lambdamax);

n=np;
tt=linspace(a,b,n);

d=u'*y;

for i = 1:n
 
 mmu = 10^tt (i);
 mu(i)=mmu;
 
 % compute the norm of c-Ax using the singular values of A
 
 t = s.^2 + mmu;
 num=  sum ((mmu*d ./ t).^2);
 
 % norm of x
 
 den=sum((s .* d ./ t).^2);
 
 nri=sqrt(num);
 nxi=sqrt(den);
 
 rho(i)=nri;
 eta(i)=nxi;
 
 sol=mmq_solipp(mmu,u,s,v,y);
 err(i)=norm(sol-x0);
 
end