%MMQ_RUN_TEST_GCV_URSELL run GCV for the Ursell problem
%
% Author G. Meurant Dec 2006
%

warning off

% Test problem: integral equation with no square integrable solution
% (regutools/ursell)

gcase = 11;
m = 64;
n = 64;

noise = 1E-5;
mmq_test_gcv;

pause

noise = 1E-3;
mmq_test_gcv;

pause

noise = 1E-1;
mmq_test_gcv;

pause

noise = 1;
mmq_test_gcv;


warning on