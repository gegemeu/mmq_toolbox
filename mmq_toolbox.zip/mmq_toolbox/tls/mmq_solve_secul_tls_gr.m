function [xf,fxf,it]=mmq_solve_secul_tls_gr(d,c,rho,beta,xs,epss);
%MMQ_SOLVE_SECUL_TLS_GR solves the Total Least Squares secular equation for Gauss-Radau
% Newton's method 
% xs: Melman starting point  (comes from the Gauss rule)
% rho > 0
%
% Author G. Meurant
% august 2007
%

warning off

k=length(d);
if length(c) ~= k
  error('MMQ_SOLVE_SECUL_TLS_GR: c does not have the right length')
end
if length(find(d<0)) ~= 0
  error('MMQ_SOLVE_SECUL_TLS_GR: d has negative components')
end

% put the first pole to zero
dmin=min(d);
del=(d(:)-dmin)/rho;
d_old=d;
d=del;
alpha=dmin-beta;

% we  need the components squared
xi=(c(:).^2);

itmax=50;
it=0;
sc=1;
x_old=(xs-dmin)/rho;

while it <=itmax & sc > epss
  it=it+1;
  % compute the interpolants
  % function and derivative of at the interpolation point x_old
  
  [yx,yxp]=seculgr(xi,d,alpha,rho,x_old);
  
  % Newton's method
  x_new=x_old-yx/yxp;
  
  sc=abs(x_new-x_old)/abs(x_old);
  x_old=x_new;
end

% translate back
xf=dmin+rho*x_new;
[yx,yxp]=seculgr(xi,d,alpha,rho,x_new);
fxf=yx;

warning on

function [y,yp]=seculgr(xi,dts,alpha,rho,x);
%SECULgr function f and f'
%
k=length(x);
for i=1:k
  z=xi(:)./(dts(:)-x(i));
  y(i)=alpha+rho*x(i)+sum(z(1:end));
  zp=xi(:)./(dts(:)-x(i)).^2;
  yp(i)=rho+sum(zp(1:end));
end

