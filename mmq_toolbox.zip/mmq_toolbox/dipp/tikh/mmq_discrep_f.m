function [f, df] = mmq_discrep_f (lambda)
%MMQ_DISCREP_F used by discrep in mmq_l_newton
%
% From Urs von Matt
%
global discrep_c discrep_s discrep_z

f = lambda^2 * sum ((discrep_z ./ (discrep_s.^2 + lambda)).^2) + discrep_c;
df = 2 * lambda * ...
     sum ((discrep_s .* discrep_z).^2 ./ (discrep_s.^2 + lambda).^3);
