function [spb,checka,checkb]=mmq_inv_problem(nmax,dig);
%MMQ_INV_PROBLEM check exactness of methods for the inverse problem
% reconstruction of the Jacobi matrix from the nodes and weights
% Laguerre weight function
% dig number of decimal digits for the computation of the nodes and weights
% needs the Symbolic Toolbox

% nmax : maximum number of points
%
% spb : problem dimension
% checka, b : max relative error on the diagonal and sub-diagonal
% divided by the unit round-off
%

% Author G. Meurant
% July 2008
%

warning off

u=eps/2;
aex=zeros(nmax,1);
bex=aex;
spb=aex;
% Laguerre exact weights
for i=1:nmax
  aex(i)=2*i-1;
  bex(i)=i;
end

m=0;
for n=0:5:nmax
  if n == 0
    n=1;
  end
  m=m+1;
  spb(m)=n;
  
  % compute the nodes and weights in variable precision
  [t,w]=mmq_laguerre_mvp(n,dig);
  % round to double
  t=double(t);
  w=double(w);
  
  % Lanczos with reorth
  [a,b]=mmq_ab_lanczos(t,w,'or');
  % relative error
  checka(m,1)=max(abs(1-a./aex(1:n)))/u;
  if n ~= 1
    checkb(m,1)=max(abs(1-b./bex(1:n-1)))/u;
  else
    checkb(m,1)=0;
  end
  
   % Lanczos Paige
  [a,b]=mmq_ab_lanczos(t,w,'no');
  % relative error
  checka(m,2)=max(abs(1-a./aex(1:n)))/u;
  if n ~= 1
    checkb(m,2)=max(abs(1-b./bex(1:n-1)))/u;
  else
    checkb(m,2)=0;
  end
  
   % Lanczos standard
  [a,b]=mmq_ab_lanczos(t,w,'st');
  % relative error
  checka(m,3)=max(abs(1-a./aex(1:n)))/u;
  if n ~= 1
    checkb(m,3)=max(abs(1-b./bex(1:n-1)))/u;
  else
    checkb(m,3)=0;
  end
  
  % CONVQR
  [a,b]=mmq_convqr(t,w);
  % relative error
  checka(m,4)=max(abs(1-a./aex(1:n)))/u;
  if n ~= 1
    checkb(m,4)=max(abs(1-b./bex(1:n-1)))/u;
  else
    checkb(m,4)=0;
  end
  
  % Lanczos OPQ = RKPW
  xw(1:n,1)=t';
  xw(1:n,2)=w';
  ab=mmq_lanczosopq(n,xw);
  a=ab(:,1);
  b=sqrt(ab(2:n,2));
  % relative error
  checka(m,5)=max(abs(1-a./aex(1:n)))/u;
  if n ~= 1
    checkb(m,5)=max(abs(1-b./bex(1:n-1)))/u;
  else
    checkb(m,5)=0;
  end
  
  % PFTOQD
  [q,e,e0,a,b]=mmq_pftoqd(t,w);
  a=a';
  b=b';
  % relative error
  checka(m,6)=max(abs(1-a./aex(1:n)))/u;
  if n ~= 1
    checkb(m,6)=max(abs(1-b./bex(1:n-1)))/u;
  else
    checkb(m,6)=0;
  end
  
  % Stieltjes
  [a,b]=mmq_stieltj(t,w);
  % relative error
  checka(m,7)=max(abs(1-a./aex(1:n)))/u;
  if n ~= 1
    checkb(m,7)=max(abs(1-b./bex(1:n-1)))/u;
  else
    checkb(m,7)=0;
  end
  
  % Rational Lanczos 
  [a,b]=mmq_lanczos_rat(t,sqrt(w));
  % relative error
  checka(m,8)=max(abs(1-a./aex(1:n)))/u;
  if n ~= 1
    checkb(m,8)=max(abs(1-b./bex(1:n-1)))/u;
  else
    checkb(m,8)=0;
  end
  
end
checka=checka(1:m,:);
checkb=checkb(1:m,:);
spb=spb(1:m);

warning on

  