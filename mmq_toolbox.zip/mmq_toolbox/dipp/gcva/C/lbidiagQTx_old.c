/* lbidiagQTx.c, MATLAB Version 4

   The calling syntax is:

       y = lbidiagQTx (Q, x)

   This procedure computes the product

       y = Q' * x.

   The matrix Q must originate from the procedure lbidiagQR.

   Urs von Matt, October 26, 1994 */



#include <math.h>
#include "mex.h"
#include "blas.c"



static void lbidiagQTx (n, Q, x, y)
  int    n;
  double *Q, *x, *y;

{ int i, ldQ;

  ldQ = 2*n;
  for (i = 0; i <= 2*n; i++) {
    y [i] = x [i];
  }
  for (i = 0; i < n; i++) {
    rot (&y [i], &y [n+1+i], Q [2*i], Q [2*i + ldQ]);
    rot (&y [i], &y [i+1], Q [2*i+1], Q [2*i+1 + ldQ]);
  }
}



/* Input Arguments */
#define	Q prhs[0]
#define	x prhs[1]

/* Output Arguments */
#define	y plhs[0]

extern mexFunction (nlhs, plhs, nrhs, prhs)
  int    nlhs, nrhs;
  Matrix *plhs[], *prhs[];

{ int n;

  /* Check for proper number of arguments */
  if (nrhs != 2) {
    mexErrMsgTxt ("lbidiagQTx requires two input arguments.");
  } else if (nlhs != 1) {
    mexErrMsgTxt ("lbidiagQTx requires one output argument.");
  }

  /* Check the dimensions of x. */
  n = (mxGetM (x) - 1) / 2;
  if ((mxGetM (x) != 2*n+1) || (mxGetN (x) != 1)) {
    mexErrMsgTxt ("x must be an (2*n+1)-by-1 matrix.");
  }

  /* Check the dimensions of Q. */
  if ((mxGetM (Q) != 2*n) || (mxGetN (Q) != 2)) {
    mexErrMsgTxt ("Q must be an (2*n)-by-2 matrix.");
  }

  /* Create matrices for the return arguments. */
  y = mxCreateFull (2*n+1, 1, REAL);

  /* Do the actual computations in a subroutine. */
  lbidiagQTx (n, mxGetPr (Q), mxGetPr (x), mxGetPr (y));
}
