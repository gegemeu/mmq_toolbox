%MMQ_TEST_L_RIBBON compute the regularization parameters
% finding the maximum of the curvature of the L-curve
%
% Needs Regutools
%
% Author G. Meurant 
% Feb 2007
%
%
global test_gcv_case test_gcv_sigma test_gcv_KU test_gcv_u ...
 test_gcv_KV test_gcv_v test_gcv_u test_gcv_y;

global gcv_func_min gcv_func_max;

% clear all figures
close all

fprintf (1, '\n\nMMQ_TEST_L_RIBBON\n--------\n\n');

% reset random number generators
% the choice affects the noise which is added
% to reproduce the results of the Golub and von Matt paper
% choose the Matlab 4 generator

% Matlab 4 random number generator
rand ('seed', 0);
% Matlab 6,... random number generator
%rand('state',0);
randn ('seed', 0);
%randn('state',0);

test_gcv_case = gcase;
r = min (m, n);

reort=0;
plotsol = 0;
% L-ribbon
lr=1;
% L-curvature
lc=1;

if gcase == 0
 fprintf (1, 'Test problem with linear singular value distribution\n');
 fprintf (1, '(c = %11.4e)\n', c);
 
 % generate the singular values 
 aa=(1000*eps-1)/(r-1);
 % linear distribution
 test_gcv_sigma=aa*([1:r]'-1)+1;
 % generate  vectors
 test_gcv_u = mmq_usin (m);
 test_gcv_u = (sqrt (2) / norm (test_gcv_u, 2)) * test_gcv_u;
 test_gcv_v = mmq_usin (n);
 test_gcv_v = (sqrt (2) / norm (test_gcv_v, 2)) * test_gcv_v;
 normK = max (test_gcv_sigma);
 
 % use the solution of the Shaw problem
 x0 = mmq_solshaw (n);

 % matrix vector product using the SVD
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);

elseif gcase == 1
 fprintf (1, 'Test problem with exponential singular value distribution\n');
 fprintf (1, '(c = %11.4e)\n', c);
 
 % generate the singular values using c (set in run_test_gcv...)
 test_gcv_sigma = exp (-abs (c) * [1:r]');
 % generate random vectors
 test_gcv_u = randn (m, 1);
 test_gcv_u = (sqrt (2) / norm (test_gcv_u, 2)) * test_gcv_u;
 test_gcv_v = randn (n, 1);
 test_gcv_v = (sqrt (2) / norm (test_gcv_v, 2)) * test_gcv_v;
 normK = max (test_gcv_sigma);
 
 x0 = randn (n, 1);
 % matrix vector product using the SVD
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 2
 fprintf (1, 'Test problem: Fredholm integral equation of the first kind\n');
 fprintf (1, '(regutools/baart)\n');
 if m ~= n
  error ('MMQ_TEST_L_RIBBON: m ~= n');
 end
 
 % generate the problem using regutools
 [K, y, x0] = baart (n);
 % compute the SVD
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 3
 fprintf (1, 'Test problem: computation of the second derivative\n');
 fprintf (1, '(regutools/deriv2)\n');
 if m ~= n
  error ('MMQ_TEST_L_RIBBON: m ~= n');
 end
 
 [K, y, x0] = deriv2 (n, 1);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 4
 fprintf (1, 'Severely ill-posed test problem.\n');
 fprintf (1, '(regutools/foxgood)\n');
 if m ~= n
  error ('MMQ_TEST_L_RIBBON: m ~= n');
 end
 
 [K, y, x0] = foxgood (n);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 5
 fprintf (1, 'Test problem: inverse heat equation\n');
 fprintf (1, '(regutools/heat)\n');
 if m ~= n
  error ('MMQ_TEST_L_RIBBON: m ~= n');
 end
 
 kappa = 1;
 [K, y, x0] = heat (n, kappa);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 6
 fprintf (1, 'Test problem: inverse Laplace transformation\n');
 fprintf (1, '(regutools/ilaplace)\n');
 if m ~= n
  error ('MMQ_TEST_L_RIBBON: m ~= n');
 end
 
 example = 1;
 [K, y, x0] = ilaplace (n, example);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 7
 fprintf (1, 'Stellar parallax problem with 28 fixed, real observations\n');
 fprintf (1, '(regutools/parallax)\n');
 
 [K, y0] = parallax (n);
 % the exact solution x0 is unknown
 x0 = zeros (n, 1);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 
elseif gcase == 8
 fprintf (1, 'Phillips''s "famous" test problem\n');
 fprintf (1, '(regutools/phillips)\n');
 if m ~= n
  error ('MMQ_TEST_L_RIBBON: m ~= n');
 end
 
 [K, y, x0] = phillips (n);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 9
 fprintf (1, 'Test problem: one-dimensional image restoration model\n');
 fprintf (1, '(regutools/shaw)\n');
 if m ~= n
  error ('MMQ_TEST_L_RIBBON: m ~= n');
 end
 
 [K, y, x0] = shaw (n);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 10
 fprintf (1, 'Test problem with a "spiky" solution\n');
 fprintf (1, '(regutools/spikes)\n');
 if m ~= n
  error ('MMQ_TEST_L_RIBBON: m ~= n');
 end
 
 t_max = 5;
 [K, y, x0] = spikes (n, t_max);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
elseif gcase == 11
 fprintf (1, 'Test problem: integral equation with no square integrable solution\n');
 fprintf (1, '(regutools/ursell)\n');
 if m ~= n
  error ('MMQ_TEST_L_RIBBON: m ~= n');
 end
 
 [K, y0] = ursell (n);
 % there is no square integrable solution
 x0 = zeros (n, 1);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 
elseif gcase == 12
 fprintf (1, 'Test problem with a discontinuous solution\n');
 fprintf (1, '(regutools/wing)\n');
 if m ~= n
  error ('MMQ_TEST_L_RIBBON: m ~= n');
 end
 
 t1 = 1/3;
 t2 = 2/3;
 [K, y, x0] = wing (n, t1, t2);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
 
elseif gcase == 13
 fprintf (1, 'Test problem with a blurred image\n');
 fprintf (1, '(regutools/blur\n');
 if m ~= n
  error ('MMQ_TEST_L_RIBBON: m ~= n');
 end
 
 [K, y, x0] = blur (n);
 K=full(K);
 [m,n]=size(K);
 [test_gcv_KU, test_gcv_sigma, test_gcv_KV] = svd (K);
 test_gcv_sigma = diag (test_gcv_sigma);
 r=rank(K);
 normK = norm (K, 'fro');
 y0 = mmq_test_gcv_Kprod ('N', m, n, x0);
 
else
 error ('MMQ_TEST_L_RIBBON: invalid value of gcase');
end

tmp=test_gcv_sigma;
ntmp=length(tmp);
tmp=sort(tmp);
test_gcv_sigma=tmp(ntmp:-1:1);

fprintf (1, 'm          = %5i\n', m);
fprintf (1, 'n          = %5i\n', n);
fprintf (1, 'sigma (1)  = %11.4e    sigma (%i) = %11.4e\n', ...
 test_gcv_sigma (1), r, test_gcv_sigma (r));
fprintf (1, 'cond (K)   = %11.4e\n', ...
 test_gcv_sigma (1) / test_gcv_sigma (r));
fprintf (1, 'noise      = %11.4e\n\n', noise);

% generate the noise and the perturbed right hand side
y=mmq_noisy(y0,noise);
test_gcv_y = y;

if plotsol == 1
 figure
 plot(x0)
 title(['solution, noise = ' num2str(noise)])
 hold on
end

% compute the L-curve
if gcase <= 1
 [rho,eta,mu,err]=mmq_comp_l_curve2(test_gcv_u,test_gcv_sigma,test_gcv_v,y,200,x0);
else
 [rho,eta,mu,err]=mmq_comp_l_curve(K,y,200,x0);
end

[tmp,ind]=min(err);
mu_opt=mu(ind)/m;
fprintf (1, '\n');
fprintf (1, 'Optimal l_curve: nu = %11.4e  mu = %11.4e\n\n', mu_opt,m*mu_opt);
fprintf (1, '\n');
% compute the regularized solution  x (lambda) using the SVD
if gcase <= 1
 % large test problem
 x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
 x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * mu_opt);
 x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
else
 % small test problem
 x = test_gcv_KU (:, 1:r)' * y;
 x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * mu_opt);
 x = test_gcv_KV (:, 1:r) * x;
end
% compute the norm  of the residual and the error
fprintf (1, '|| y - K * x (lambda) ||_2 = %11.4e\n', ...
 norm (y - mmq_test_gcv_Kprod ('N', m, n, x)));
fprintf (1, '|| x (lambda) - x0 ||_2    = %11.4e\n', norm (x - x0, 2));
fprintf (1, '|| x (lambda) ||_2    = %11.4e\n', norm (x, 2));


if lr == 1
 % compute the regularization parameter from the L-ribbon
 % 
 disp('-----------------------')
 if gcase <= 1
  kmax=2*m;
  %kmax=1000;
  if reort == 1
   [mul,muu,iter]=mmq_l_ribbon_corner_reort_it_g(test_gcv_u,test_gcv_sigma,test_gcv_v,y,kmax);
  else
   [mul,muu,iter]=mmq_l_ribbon_corner_it_g(test_gcv_u,test_gcv_sigma,test_gcv_v,y,kmax);
  end
 else
  kmax=2*m;
  %kmax=1000;
  [mul,muu,iter]=mmq_l_ribbon_corner_reort_it(K,y,kmax);
 end
 reg_l_ribbon = mul / m;
 fprintf (1, '\n');
 fprintf (1, 'L_ribbon: nu = %11.4e  mu = %11.4e  it = %5i\n\n', reg_l_ribbon,m*reg_l_ribbon,iter);
 
 if reg_l_ribbon > 0
  % compute the regularized solution  x (lambda) using the SVD
  if gcase <= 1
   % large test problem
   x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * reg_l_ribbon);
   x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
  else
   % small test problem
   x = test_gcv_KU (:, 1:r)' * y;
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * reg_l_ribbon);
   x = test_gcv_KV (:, 1:r) * x;
  end
  % compute the norm  of the residual and the error
  fprintf (1, '|| y - K * x (lambda) ||_2 = %11.4e\n', ...
   norm (y - mmq_test_gcv_Kprod ('N', m, n, x)));
  fprintf (1, '|| x (lambda) - x0 ||_2    = %11.4e\n', norm (x - x0, 2));
  fprintf (1, '|| x (lambda) ||_2    = %11.4e\n', norm (x, 2));
  
  if plotsol == 1
   plot(x,':+')
  end
 else
  fprintf (1, 'lambda <= 0\n');
 end
 if plotsol == 1
  pause
 end
end 


if lc == 1
 % compute the regularization parameter from the L-curve (curvature)
 % 
 disp('-----------------------')
 if gcase <= 1
  kmax=m;
  if reort == 1
   [mul,muu,iter]=mmq_l_ribbon_curvat_reort_it_g(test_gcv_u,test_gcv_sigma,test_gcv_v,y,kmax);
  else
   [mul,muu,iter]=mmq_l_ribbon_curvat_it_g(test_gcv_u,test_gcv_sigma,test_gcv_v,y,kmax);
  end
 else
  kmax=m;
  if reort == 1
   [mul,muu,iter]=mmq_l_ribbon_curvat_reort_it(K,y,kmax);
  else
   [mul,muu,iter]=mmq_l_ribbon_curvat_it(K,y,kmax);
  end
 end
 reg_l_curvat = mul / m;
 fprintf (1, '\n');
 fprintf (1, 'L_curvature: nu = %11.4e  mu = %11.4e  it = %5i\n\n', reg_l_curvat,m*reg_l_curvat,iter);
 
 if reg_l_curvat > 0
  % compute the regularized solution  x (lambda) using the SVD
  if gcase <= 1
   % large test problem
   x = y (1:r) - test_gcv_u (1:r) * (test_gcv_u' * y);
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * reg_l_curvat);
   x = [x; zeros(n-r,1)] - test_gcv_v * (test_gcv_v (1:r)' * x);
  else
   % small test problem
   x = test_gcv_KU (:, 1:r)' * y;
   x = (test_gcv_sigma .* x) ./ (test_gcv_sigma.^2 + m * reg_l_curvat);
   x = test_gcv_KV (:, 1:r) * x;
  end
  % compute the norm  of the residual and the error
  fprintf (1, '|| y - K * x (lambda) ||_2 = %11.4e\n', ...
   norm (y - mmq_test_gcv_Kprod ('N', m, n, x)));
  fprintf (1, '|| x (lambda) - x0 ||_2    = %11.4e\n', norm (x - x0, 2));
  fprintf (1, '|| x (lambda) ||_2    = %11.4e\n', norm (x, 2));
  
  if plotsol == 1
   plot(x,':*')
  end
 else
  fprintf (1, 'nu <= 0\n');
 end
 if plotsol == 1
  pause
 end
end 