function [alpha,beta]=mmq_test_pftoqd(N,ix);
%MMQ_TEST_PFTOQD implements the Laurie's procedure 
% for  the discrete scalar
% product defined by nodes x_k and weights w_k^2

%
% Author G. Meurant
% June 2007
%

[x,w,y,ier,mu0]=mmq_pwv(N,ix);

% computation of the nodes and weights and solution
[q,e,e0,alpha,beta]=mmq_pftoqd(x,w.^2);


% computation of the eigenvalues and eigenvectors
ni=N;
J=spdiags([[beta(1:ni-1)'; 0] alpha(1:ni)' [0; beta(1:ni-1)']], -1:1, ni,ni);
[V,d]=eig(full(J));
eigJ=diag(d);
[eigJ,ind]=sort(eigJ);
V=V(:,ind);

if size(x,1) == 1
 x=x';
end

% errors on the points
errp=norm(x-eigJ)/norm(x);
disp('MMQ_TEST_PFTOQD: Error in the eigenvalues')
errp

if size(w,1) == 1
 w=w';
end

V=abs(V)*sqrt(mu0);
% errors on the first elements of the eigenvectors
errw=norm(w'-abs(V(1,:)))/norm(w);
disp('MMQ_TEST_PFTOQD: Error in the 1rst components')
errw
