function [reg_interval,n_interval]=mmq_l_interval(a,y,epsd);
%MMQ_L_INTERVAL locates intervals where the differences of the norms of x and r are
% small i.e. smaller than epsd
%
% n_interval :   nb of intervals
% reg_interval : 1,2 ends of the intervals
%
% Author G. Meurant
% Feb 2007

% compute the L-curve with n points

n=50;
[r,x,mu]=mmq_comp_l_curve(a,y,n,zeros(length(y),1));

% compute the differences of the log of the norms

delx=abs(log10(x(2:end))-log10(x(1:end-1)));
delr=abs(log10(r(2:end))-log10(r(1:end-1)));
delx=log10(delx);
delr=log10(delr);
tt=log10(mu);

fig=0;
if fig == 1
 figure
 plot(tt(2:end),delx)
 hold on
 plot(tt(2:end),delr,'r--')
 %plot(tt,dr,'r--')
 title('log_{10} of differences of log_{10} ||x|| (solid) and ||c-Ax|| (dashed)')
 hold off
end

% find intervals where both delx and delr are smaller than epsd

yx=log10(epsd)-delx;
yr=log10(epsd)-delr;
yx=-yx;
yr=-yr;

%indices for negative values in yx and yr

ii=find(yx <= 0 & yr <= 0);

if length(ii) < 1
 % return the min of the angles
 q=0;
 %
 p=length(x);
 for i=1:p-1
  v=[r(i+1)-r(i);x(i+1)-x(i)];
  nv=norm(v);
  q=q+1;
  vq(:,q)=v/nv;
 end
 for i=1:q-1
  v1=vq(:,i);
  v2=vq(:,i+1);
  ac=acos(v1'*v2);
  dv=v2-v1;
  if dv(1) < 0 | dv(2) < 0
   w(i)=pi+ac;
  else
   w(i)=pi-ac;
  end
 end
 [mw,k]=min(w);
 k=k+1;
 n_interval=1;
 reg_interval(1,1)=mu(k);
 reg_interval(1,2)=mu(k);
 return
end

% look for consecutive indices by computing the difference (1 or more)

dii=ii(2:end)-ii(1:end-1);

% find the differences larger than 1; they give the boundaries of
% consecutive points

nii=find(dii > 1);

n_interval=length(nii)+1;

reg_interval=[];
if n_interval > 0
 reg_interval=zeros(n_interval,2);
 deb_int=ii(1);
 if length(nii) >= 1
  for i=1:length(nii)
   fin_int=ii(nii(i));
   reg_interval(i,1)=mu(deb_int);
   reg_interval(i,2)=mu(fin_int);
   deb_int=ii(nii(i)+1);
  end
  fin_int=ii(nii(length(nii))+1);
  reg_interval(n_interval,1)=mu(deb_int);
  reg_interval(n_interval,2)=mu(fin_int);
 else
  fin_int=ii(end);
  reg_interval(n_interval,1)=mu(deb_int);
  reg_interval(n_interval,2)=mu(fin_int);
 end
end

  
   