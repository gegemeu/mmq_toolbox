% 
% Contents of MMQ (Matrices, moments and Quadrature)
%
% This package contains the Matlab functions written for the book
% 
% Matrices, moments and quadrature with applications
% Gene H. Golub and G�rard Meurant
% Princeton University Press, 2009
%
% See contents of the folders
%
