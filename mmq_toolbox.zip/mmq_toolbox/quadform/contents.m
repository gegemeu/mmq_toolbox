%
% Contents of Quadform
%
% computation of bounds or estimates for bilinear forms u^T f(A) v where A
% is a symmetric matrix
%
% MMQ_BOUNDS_BGAUSS computation of estimates using Gauss block quadrature rules (inverse) 
% MMQ_BOUNDS_BGAUSSE computation of estimates using Gauss block quadrature rules (exponential)
% MMQ_BOUNDS_BGAUSSSQ computation of estimates using Gauss block quadrature rules (sqrt) 
% MMQ_BOUNDS_DTX_GAUSSNS computation of bounds for d^T x with a x=c i.e. d^T inv(a)c
% MMQ_BOUNDS_EXP_GAUSS computation of lower and upper bounds of the element (i,i) of the exponential
% MMQ_BOUNDS_FU_GAUSS computation of lower and upper bounds of u^T fonc(a) u using Lanczos
% MMQ_BOUNDS_F_GAUSS computation of lower and upper bounds of the element (i,i) of the function fonc
% MMQ_BOUNDS_F_GAUSSNS computation of bounds for the element (i,l) of the function fonc
% MMQ_BOUNDS_GAUSS computation of lower and upper bounds of the element (i,i) of the inverse
% MMQ_BOUNDS_GAUSSB computation of a lower bound of a bilinear form with the inverse of a
% MMQ_BOUNDS_GAUSSBREC computation of a lower bound of a bilinear form with the inverse of a
% MMQ_BOUNDS_GAUSSNS computation of bounds for the element (i,l) of the inverse of a symmetric matrix a
% MMQ_BOUNDS_INV_GAUSS computation of lower and upper bounds of the element (i,i) of the inverse
% MMQ_BOUNDS_SQRT_GAUSS computation of lower and upper bounds of the element (i,i) of the square root