function mmq_plotseculbk(d,c);
%MMQ_PLOTSECULBK plots figures of the Backward Error secular equation
%
% Author G. Meurant
% Aug 2008
%

km=length(d);
lmin=min(d(:));
lmin=0;
lmax=max(d(:));
dta=sort(d);
lmm=lmax-lmin;
ymax=10;
ymin=-10;

k=km;
 
% we  need the components squared
xi=(c(:).^2);
figure
hold on

% plot the non zero poles
for i=1:k
  plot([d(i) d(i)],[-ymax ymax],'--')
end

% plot the pole at 0
plot([0 0],[-ymax ymax],'--')

% plot the function between the k+1 poles 
lamb=[lmin-10 0 d(:)' lmax+2];
for i=1:k+2
  epsi1=(lamb(i+1)-lamb(i))*1e-10;
  epsi2=epsi1;
  if i == 1
    epsi1=0;
    epsii=epsi1;
  end
  if i == k+2
    epsi2=0;
  end
  x=linspace(lamb(i)+epsi1,lamb(i+1)-epsi2,50);
  x=x(:);
  
  y=secul(xi,d,x);
  plot(x,y)
  if i == 1
    z=1+xi(1)./x;
    plot(x,z,'r')
  end
end

% plot( the x axis
plot([min(lamb) max(lamb)],[0 0],'-.')
axis([min(lamb) max(lamb) -ymax ymax])
title(['Backward error secular function'])
hold off

x=linspace(-1e-5,-1e-8,200);
y=secul(xi,d,x);
figure
plot(x,y)
title('Zoom')

function y=secul(xi,dts,x);
%SECUL function f
%

k=length(x);
 
for i=1:k
  y(i)=1+xi(1)/x(i)-sum(xi(2:end)./(dts(:)-x(i)));
end
