function [trg,trgrl,trgru,trgl]=mmq_est_trdet_rand(a,k,p,lmin,lmax);
%MMQ_EST_TRDET_RAND estimate of the determinant of a (symmetric) with Monte Carlo and Lanczos
% bounds of z^T log(a) z, z is a random vector with components 1 or -1
% then we take the exponential
% k Lanczos iterations for each vector
% lmin, lmax lower and upper bounds of the smallest and largest eigenvalues of a
% average of the p results

%
% Author G. Meurant
% March 2008
%

% initialize the random number generator
% this can be removed to obtain different bounds at each call of the function
rand('state',0)
randn('state',0)

n=size(a,1);
bg=zeros(p,1);
bgrl=zeros(p,1);
bgru=zeros(p,1);
bgl=zeros(p,1);

% generate p random vectors
for i=1:p
  %z=mmq_rand_pmone(n);
  z=mmq_randn_pmone(n);
  [bgi,bgrli,bgrui,bgli]=mmq_bounds_fu_gauss('log',a,z,k,lmin,lmax);
  bg(i)=bgi(k); bgrl(i)=bgrli(k); bgru(i)=bgrui(k); bgl(i)=bgli(k);
end

% average of the results
trg=sum(bg)/p;
trgrl=sum(bgrl)/p;
trgru=sum(bgru)/p;
trgl=sum(bgl)/p;

trg=exp(trg);
trgrl=exp(trgrl);
trgru=exp(trgru);
trgl=exp(trgl);
