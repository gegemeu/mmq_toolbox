function [alphat,betat,dt]=mmq_plslr1(x,w,y);
%MMQ_PLSLR1 polynomial least squares approximation 
% from L. Reichel (Fast QR decomposition...) given the nodes and weights
% positive weights
% x, w, y points, weights and values
%
%
% Author G. Meurant
% June 2007
%

N=length(x);

m=N;
n=N;

alphat(1)=x(1);
beta0=w(1);
dt(1)=w(1)*y(1);

% l=1, add x_2
tau=beta0;
beta0=sqrt(beta0^2+w(2)^2);
gamma=tau/beta0;
sigma=-w(2)/beta0;
tau=gamma*sigma*(alphat(1)-x(2));
betat(1)=abs(tau);
dt(2)=sign(tau)*(sigma*dt(1)+gamma*w(2)*y(2));
dt(1)=gamma*dt(1)-sigma*w(2)*y(2);
alphat(2)=sigma^2*alphat(1)+gamma^2*x(2);
alphat(1)=gamma^2*alphat(1)+sigma^2*x(2);

% l > 1
for l=2:m-1
 tau=beta0;
 beta0=sqrt(beta0^2+w(l+1)^2);
 gamma=tau/beta0;
 sigma=-w(l+1)/beta0;
 dt(l+1)=sigma*dt(1)+gamma*w(l+1)*y(l+1);
 dt(1)=gamma*dt(1)-sigma*w(l+1)*y(l+1);
 v1=gamma*sigma*(alphat(1)-x(l+1));
 v2=sigma*betat(1);
 v3=gamma^2*x(l+1)+sigma^2*alphat(1);
 alphat(1)=gamma^2*alphat(1)+sigma^2*x(l+1);
 betat(1)=gamma*betat(1);
 for k=1:min(l-2,n-1)
  tau=betat(k);
  betat(k)=sqrt(betat(k)^2+v1^2);
  gamma=tau/betat(k);
  sigma=-v1/betat(k);
  tau=sigma*dt(k+1)+gamma*dt(l+1);
  dt(k+1)=gamma*dt(k+1)-sigma*dt(l+1);
  dt(l+1)=tau;
  tau=alphat(k+1);
  alphat(k+1)=gamma^2*tau+sigma^2*v3-2*gamma*sigma*v2;
  v1=(gamma-sigma)*(gamma+sigma)*v2+gamma*sigma*(tau-v3);
  v3=gamma^2*v3+2*gamma*sigma*v2+sigma^2*tau;
  v2=sigma*betat(k+1);
  betat(k+1)=gamma*betat(k+1);
 end
 if l-1 < n
  tau=betat(l-1);
  betat(l-1)=sqrt(betat(l-1)^2+v1^2);
  gamma=tau/betat(l-1);
  sigma=-v1/betat(l-1);
  tau=(gamma-sigma)*(gamma+sigma)*v2+gamma*sigma*(alphat(l)-v3);
  betat(l)=abs(tau);
  tau=sign(tau)*(sigma*dt(l)+gamma*dt(l+1));
  dt(l)=gamma*dt(l)-sigma*dt(l+1);
  dt(l+1)=tau;
  alphat(l+1)=sigma^2*alphat(l)+2*gamma*sigma*v2+gamma^2*v3;
  alphat(l)=gamma^2*alphat(l)-2*gamma*sigma*v2+sigma^2*v3;
 end
end
alphat=alphat(1:n);
betat=betat(1:n-1);
dt=dt(1:n);



