function [maxy,ny]=mmq_stagest(a,l,dd1,x,precond,maxy);
%MMQ_STAGEST computes  quantities for estimation of the maximum accuracy
%
% Author G. Meurant
% March 2001
%

switch precond
case {'no'}
 ny=norm(x);
 maxy=max([maxy ny]);

otherwise
 y=dd1.*(l'*x);
 ny=norm(y);
 maxy=max([maxy ny]);
 
end
