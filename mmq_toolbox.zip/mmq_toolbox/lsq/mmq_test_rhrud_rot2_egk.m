function [n,sig,alpha,beta,d]=mmq_test_rhrud_rot2_egk(N,M,ns,ix);
%MMQ_TEST_RHRUD_ROT2_EGK test for the function mmq_rhrud_rot2d as in Elhay, Golub and Kautsky
% updating with mmq_rhrud_rot1
% sliding window through the data
%
% Author G. Meurant
% May 2007
%

if ns > M
 disp('MMQ_TEST_RHRUD_ROT2_EGK: ns is larger than M')
 ns=M;
end
[x,w,y,ier]=mmq_pwv(N,ix);
if ier == 1
 error('MMQ_TEST_RHRUD_ROT2_EGK: Unknown problem, abort')
end

% recursively build the solution up to M
sig=abs(w(1));
alpha(1)=x(1);
beta(1)=0;
d(1)=y(1)*sig;
eigvec=zeros(N,N);
eigvec(1,1)=1;
eigval=zeros(N,1);
eigval(1)=x(1);
cc=zeros(N,N);
ss=zeros(N,N);
n=1;
for i=1:M-1
 % update
[n,sig,alpha,beta,d,cc,ss,eigvec,eigval]=mmq_rhrud_rot1(n,alpha,beta,sig,d,x(i+1),w(i+1),y(i+1),cc,ss,eigvec,eigval);
disp('update init rhrud_rot1-----------------------')
n
end

for k=1:N-M
 disp('*********************************')
 k
 % add a point k+M by updating
 [n,sig,alpha,beta,d,cc,ss,eigvec,eigval]=mmq_rhrud_rot1(length(alpha),alpha,beta,sig,d,x(k+M),w(k+M),y(k+M),cc,ss,eigvec,eigval);
 disp('update k+M rhrud_rot1-----------------------')
 n
 % delete the point k by downdating
 [n,sig,alpha,beta,d,eigvec,eigval]=mmq_rhrud_rot2d(length(alpha),alpha,beta,sig,d,x(k),w(k),y(k),eigvec,eigval,1);
 disp('downdate k rhrud_rot2d-----------------------')
 n
 if n ~= M
  disp('MMQ_TEST_RHRUD_ROT2_EGK: cannot downdate correctly, abort')
 end
end
alpha=alpha(1:ns);
beta=beta(1:ns-1);
d=d(1:ns);

%generate directly the solution at the end by updating
sigr=abs(w(N-M+1));
alphar(1)=x(N-M+1);
betar(1)=0;
dr(1)=y(N-M+1)*sigr;
eigvec=zeros(N,N);
eigvec(1,1)=1;
eigval=zeros(N,1);
eigval(1)=x(N-M+1);
cc=zeros(N,N);
ss=zeros(N,N);
for i=1:M-1
 % update
 [n,sigr,alphar,betar,dr,cc,ss,eigvec,eigval]=mmq_rhrud_rot1(i,alphar,betar,sigr,dr,x(N-M+i+1),w(N-M+i+1),y(N-M+i+1),cc,ss,eigvec,eigval);
disp('update ref rhrud_rot1-----------------------')
n
end
alphar=alphar(1:ns);
betar=betar(1:ns-1);
dr=dr(1:ns);
 
 disp('++++++++++++++++++++++')
disp(' Final checks---------')
disp('  ')

% compare the solutions
err_sig=abs(sig-sigr)/abs(sigr);
err_alpha=norm(alpha-alphar)/norm(alphar);
err_beta=norm(beta-betar)/norm(betar);
err_d=norm(d-dr)/norm(dr);
disp(' err_sig err_alpha err_beta err_d:')
[err_sig err_alpha err_beta err_d]

disp('MMQ_TEST_RHRUD_ROT2_EGK: end test')



