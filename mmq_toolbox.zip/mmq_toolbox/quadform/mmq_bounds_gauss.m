function [bg,bgrl,bgru,bgl]=mmq_bounds_gauss(a,i,kmax,lmin,lmax);
%MMQ_BOUNDS_GAUSS computation of lower and upper bounds of the element (i,i) of the inverse
% of a symmetric matrix a using Lanczos
% kmax iterations
%
% lmin and lmax are the lower and upper bounds for the smallest and largest eigenvalues
%
%  bg :         Gauss
%  bgrl, bgru : Gauss-Radau
%  bgl :        Gauss-Lobatto
%  
% Author G. Meurant
% March 2008
%

bg=zeros(kmax,1);
bgrl=zeros(kmax,1);
bgru=zeros(kmax,1);
bgl=zeros(kmax,1);
 
n=size(a,1);
ei=zeros(n,1);
ei(i)=1;
x1=zeros(n,1);
x=ei;
gam=0;
ax=a*x;
om=x'*ax;
b1=1/om;
bg(1)=b1;
d=om;
dbar=om-lmax;
dhat=om-lmin;
c=1;
r=ax-om*x;
gam2=r'*r;
gam=sqrt(gam2);
x1=x;
x=r/gam;

% Lanczos iterations
if kmax > 1
 for k=2:kmax
  gam1=gam;
  gam21=gam2;
  ax=a*x;
  om=x'*ax;
  r=ax-om*x-gam*x1;
  gam2=r'*r;
  gam=sqrt(gam2);
  x1=x;
  if gam == 0
   error('MMQ_BOUNDS_GAUSS: breakdown')
  end
  x=r/gam;
  b1=b1+(gam21*c^2)/(d*(om*d-gam21));
  c=c*gam1/d;
  d=om-gam21/d;
  dbar=om-lmax-gam21/dbar;
  dhat=om-lmin-gam21/dhat;
  ombar=lmax+gam2/dbar;
  omhat=lmin+gam2/dhat;
  bbar=b1+(gam2*c^2)/(d*(ombar*d-gam2));
  bhat=b1+(gam2*c^2)/(d*(omhat*d-gam2));
  dd=dhat*dbar/(dbar-dhat);
  omt=dd*(lmax/dhat-lmin/dbar);
  gamt2=dd*(lmax-lmin);
  btch=b1+(gamt2*c^2)/(d*(omt*d-gamt2));
  bg(k)=b1;
  bgrl(k)=bbar;
  bgru(k)=bhat;
  bgl(k)=btch;
 end
end
