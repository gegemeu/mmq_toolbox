function [y,e]=mmq_noisy(y0,noise);
%MMQ_NOISY add noise to the vector y
%
% Author G. Meurant
% Dec 2006
%
% initialize Matlab 4 random number generator
randn('seed',0)
% initialize Matlab 6 random number generator
%randn('state',0)

m=size(y0,1);
e = randn (m, 1);
e = (noise / norm (e, 2)) * e;
y = y0 + e;