function tr=mmq_est_trps_mod(a,k,mu,kap,lmin,lmax);
%MMQ_EST_TRPS_MOD estimate of the partial sums of the eigenvalues of a (< mu)
% the step function is approximated by
% x/(1+exp((x-mu)/kap)))
% computes 2k modified moments and uses the Golub and Welsch algorithm
% lmin, lmax estimates of the smallest and largest eigenvalues of a
%
% Author G. Meurant
% March 2008
%

% computes the 2k moments of a
[mom,bc,ac,cc]=mmq_trace_chebyshift(k,a,lmin,lmax);

% compute the Jacobi matrix (monic polynomials
[gamma,aa,b,mu0]=mmq_modifcheb(k,mom,1,0,bc,ac,cc,1);

% symmetrize
b=sqrt(b);

% compute the nodes and weights
[t,w]=mmq_gaussquadrule_m(aa,b,mu0);

% compute the integral of the approximation of the step function
y=t./(1+exp((t-mu)/kap));
tr=sum(w.*y);
