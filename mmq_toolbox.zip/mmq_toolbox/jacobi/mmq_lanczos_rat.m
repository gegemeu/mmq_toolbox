function [alpha,beta]=mmq_lanczos_rat(t,w);
%MMQ_LANCZOS_RAT Rational Lanczos iteration for a diagonal matrix a, standard version
% kmax iterations 
%

%
% Author G. Meurant
% July 2008
%  

p=w(:);
rho2_old=1;
D=t(:);
beta=[];
kmax=length(t);

% first iteration
wk=p.*p;
rho2=sum(wk);
beta2=rho2/rho2_old;
al=D'*wk/rho2;
rho2_old=rho2;
alpha(1)=al;
if kmax <= 1
  return
end
p_old=p;
p=D.*p-al*p;

for k=2:kmax
  wk=p.*p;
  rho2=sum(wk);
  beta2=rho2/rho2_old;
  beta(k-1)=sqrt(beta2);
  rho2_old=rho2;
  al=D'*wk/rho2;
  alpha(k)=al;
  r=D.*p-al*p-beta2*p_old;
  p_old=p;
  p=r;
end

alpha=alpha(:);
beta=beta(:);

