function [trg,trgrl,trgru,trgl]=mmq_est_tria_rand(a,k,p,lmin,lmax);
%MMQ_EST_TRIA_RAND estimate of the trace of the inverse of a with moments + Monte Carlo
% bounds of z^T inv(a) z, z is a random vector with components 1 or -1
% k Lanczos iterations for each vector
% lmin, lmax lower and upper bounds of the smallest and largest eigenvalues of a
% average of the p results

%
% Author G. Meurant
% March 2008
%

% initialize the random number generator
% this can be removed to obtain different bounds at each call of the function
rand('state',0)
randn('state',0)

n=size(a,1);
bg=zeros(p,1);
bgrl=zeros(n,1);
bgru=zeros(n,1);
bgl=zeros(n,1);

% generate p random vectors
for i=1:p
  %z=mmq_rand_pmone(n);
  z=mmq_rand_pmone(n);
  [bgi,bgrli,bgrui,bgli]=mmq_bounds_fu_gauss(inline('1./x'),a,z,k,lmin,lmax);
  bg(i)=bgi(k); bgrl(i)=bgrli(k); bgru(i)=bgrui(k); bgl(i)=bgli(k);
end

% average of the results
trg=sum(bg)/p;
trgrl=sum(bgrl)/p;
trgru=sum(bgru)/p;
trgl=sum(bgl)/p;
