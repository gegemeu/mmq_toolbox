function k=mmq_angle(t,u,s,v,y);
%MMQ_ANGLE locates the l-corner by computing the angles
%
% u, s, v SVD
% t contains the values of the parameter
%
% Author G. Meurant
% Jan 2007
%
p=length(t);

% compute the points on the L-curve
[x,r] = mmq_flcurve (t,u,s,v,y);

q=0;
 
for i=1:p-1
 v=[r(i+1)-r(i);x(i+1)-x(i)];
 nv=norm(v);
 q=q+1;
 vq(:,q)=v/nv;
end
for i=1:q-1
 v1=vq(:,i);
 v2=vq(:,i+1);
 ac=acos(v1'*v2);
 dv=v2-v1;
 if dv(1) < 0 | dv(2) < 0
  w(i)=pi+ac;
 else
  w(i)=pi-ac;
 end
end
 
[mw,k]=min(w);
 
k=k+1;