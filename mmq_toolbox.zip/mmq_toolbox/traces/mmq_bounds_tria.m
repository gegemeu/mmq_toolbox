function [trmin,trmax]=mmq_bounds_tria(a,lmin,lmax);
%MMQ_BOUNDS_TRIA Golub and Bai bounds for the trace of the inverse of a
% using the two first moments mu1, mu2
%
% lmin, lmax are estimates of the smallest and largest eigenvalues of a
%
% Author G. Meurant
% March 2008
%

n=size(a,1);
mu1=trace(a);
mu2=norm(a,'fro')^2;

matl=[mu2 mu1; lmax^2 lmax];
matu=[mu2 mu1; lmin^2 lmin];

mn=[mu1 n];
n1=[n ; 1];

trmin=mn*inv(matl)*n1;
trmax=mn*inv(matu)*n1;

