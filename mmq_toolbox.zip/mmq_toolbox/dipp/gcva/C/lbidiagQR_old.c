/* lbidiagQR.c, MATLAB Version 4

   The calling syntax is:

       [Q, u, v] = lbidiagQR (gamma, delta, mu)

   This procedure computes the QR-decomposition of the (2n+1)-by-n
   matrix

       [  L   ]
       [      ]
       [ mu*I ]

   where L is an (n+1)-by-n lower bidiagonal matrix:

           [ gamma(1)                     ]
           [ delta(1)  ...                ]
       L = [           ...  ...           ]
           [                ...  gamma(n) ]
           [                     delta(n) ]

   Urs von Matt, October 26, 1994 */



#include <math.h>
#include "mex.h"
#include "blas.c"



static void lbidiagQR (n, gamma, delta, mu, Q, u, v)
  int    n;
  double *gamma, *delta, mu, *Q, *u, *v;

{ int    i, ldQ;
  double tmp;

  ldQ = 2*n;
  u [0] = gamma [0];
  for (i = 0; i < n; i++) {
    tmp = mu;
    rotg (&u [i], &tmp, &Q [2*i], &Q [2*i + ldQ]);
    tmp = delta [i];
    rotg (&u [i], &tmp, &Q [2*i+1], &Q [2*i+1 + ldQ]);
    if (i < n-1) {
      v [i] = 0.0;
      u [i+1] = gamma [i+1];
      rot (&v [i], &u [i+1], Q [2*i+1], Q [2*i+1 + ldQ]);
    }
  }
}



#define max(A, B)  ((A) > (B) ? (A) : (B))
#define min(A, B)  ((A) < (B) ? (A) : (B))

/* Input Arguments */
#define	gamma prhs[0]
#define	delta prhs[1]
#define	mu    prhs[2]

/* Output Arguments */
#define	Q plhs[0]
#define	u plhs[1]
#define	v plhs[2]

extern mexFunction (nlhs, plhs, nrhs, prhs)
  int    nlhs, nrhs;
  Matrix *plhs[], *prhs[];

{ int n;

  /* Check for proper number of arguments */
  if (nrhs != 3) {
    mexErrMsgTxt ("lbidiagQR requires three input arguments.");
  } else if (nlhs != 3) {
    mexErrMsgTxt ("lbidiagQR requires three output arguments.");
  }

  /* Check the dimensions of gamma. */
  n = max (mxGetM (gamma), mxGetN (gamma));
  if (min (mxGetM (gamma), mxGetN (gamma)) != 1) {
    mexErrMsgTxt ("gamma must be an n-by-1 or a 1-by-n matrix.");
  }

  /* Check the dimensions of delta. */
  if ((min (mxGetM (delta), mxGetN (delta)) != 1) ||
      (max (mxGetM (delta), mxGetN (delta)) != n)) {
    mexErrMsgTxt ("delta must be an n-by-1 or a 1-by-n matrix.");
  }

  /* Check the dimensions of mu. */
  if ((mxGetM (mu) != 1) || (mxGetN (mu) != 1)) {
    mexErrMsgTxt ("mu must be a scalar.");
  }

  /* Create matrices for the return arguments. */
  Q = mxCreateFull (2*n, 2, REAL);
  u = mxCreateFull (n, 1, REAL);
  v = mxCreateFull (n-1, 1, REAL);

  /* Do the actual computations in a subroutine. */
  lbidiagQR (n, mxGetPr (gamma), mxGetPr (delta), *mxGetPr (mu),
             mxGetPr (Q), mxGetPr (u), mxGetPr (v));
}
