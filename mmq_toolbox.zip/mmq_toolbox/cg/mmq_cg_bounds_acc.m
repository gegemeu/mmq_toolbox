function [res,x,nit,gest,agest,normglob1,normglob]=mmq_cg_bounds_acc(a,b,x0,epss,nitmax,delay,scaling,precond,varargin);
%MMQ_CD_BOUNDS_ACC preconditioned conjugate gradient for a symmetric matrix a
% with estimates of the maximum accuracy and bounds of the A-norm of the error
%
% input
%  a - matrix
%  b - right hand side 
%  x0 - starting vector,
%  epss - threshold for stopping criterion
%   (stop if norm(r^k)<= epss norm(r^0) or nit > nitmax
%  nitmax - maximum number of iterations
%  precond - type of preconditioning
%   ='no' M=I
%   ='sc' diagonal
%   ='ic' IC(0)
%   ='ch' IC(epsilon)
%   ='ss' SSOR with omega=1 
% param=varargin(1) - parameter needed by some preconditioners
%  = nothing for 'no', 'sc', 'ss' and 'ic'
%  = epsilon for 'ch'
%
% output
%  res - l_2 norm of computed residual
%  gest - Gauss lower bound on the A-norm of the error
%  agest - anti Gauss estimate of the A-norm of the error
%  x - approximate solution
%  nit - number of iterations
%  
% Author G. Meurant
% Feb 2009
%

n=size(a,1);
if nargin == 8
 param=[];
else
 param=varargin{1};
end

% unit round off
u=eps/2;
% max number of non zeros per row
nnp=mmq_maxnzpr(a);

dda=ones(n,1);
nd=1;

% initial vector and residual
x=x0;
r=b-a*x;

% init of preconditioners
[dd,l,d1,ld]=mmq_initprec(a,precond,param);

maxy=0;
maxy=mmq_stagest(a,l,d1,x,precond,maxy);
nb=mmq_stagestb(b,l,d1,x,precond);
maxx=max(x);

% solve of M z = r
z=mmq_solveprec(r,a,dd,l,precond,param);

p=z;
nit=0;
r0=r'*r;
res(1)=sqrt(r0);
rtr=z'*r;
r00=rtr;
% init for estimation of error
alp1=1;
bet1=0;
gam2=1;
c2=1;

eps2=epss*epss*r0;
resid=realmax;

% iterations
while resid >= eps2 & nit < nitmax
 nit=nit+1;
 ap=a*p;
 alp=rtr/(p'*ap);
 % estimates of the norm of the error
 om=1./alp+bet1/alp1;
 t(nit,nit)=om;
 
 if nit <= 10
  % compute eigenvalues to have an estimate of
  % the l_2 norm of inv(M)A
  vpt=eig(full(t(1:nit,1:nit)));
  maxvpt=max(vpt);
 end
 if nit == 1 
  told(1)=1./om;
  d=om;
 else
  c2=c2*gam2/d^2;
  dold=d;
  d=om-gam2/d;
  tnew=c2/d;
  dp=d-gam2/dold;
  
  % anti-Gauss estimate
  ag=2*c2/dp;
  if nit < delay
   told(nit)=tnew;
  else
   told(delay)=tnew;
  end
 end
 alp1=alp;
 
 x=x+alp*p;
 
 % estimate of the maximum accuracy (l_2 norm)
 maxx=max([maxx max(x)]);
 maxy=mmq_stagest(a,l,d1,x,precond,maxy);
 normest=u*maxvpt*maxy*ld;
 normest1=normest*nnp;
 nor=u*maxvpt*maxx*ld^2;
 % eventually multiply by nnp (max nb of non zero per row)
 nor1=nor*nnp;
 
 % computed residual
 r=r-alp*ap;
 
 % solve of M z = r
 z=mmq_solveprec(r,a,dd,l,precond,param);
 
 rtrz=z'*r;
 rk=r'*r;
 resid=rk;
 
 % residual l_2 norm
 res(nit+1)=sqrt(rk);
 
 bet=rtrz/rtr;
 beta(nit)=bet;
 rtr=rtrz;
 
 % estimates of A-norm of the error
 gam2=bet/alp^2;
 gam=sqrt(gam2);
 t(nit,nit+1)=gam;
 t(nit+1,nit)=gam;
 t=sparse(t);
 
 % gest  =  Gauss lower bound
 % agest = anti Gauss estimate
 if nit > max([delay 1])
  est=sum(told(1:delay));
  gest(nit-delay)=sqrt(r00*est);
  if ag+est > 0
   agest(nit-delay)=sqrt(r00*(ag+est));
  else
   agest(nit-delay)=gest(nit-delay);
  end
 end
 if nit >= delay
  temp=told(2:delay);
  told(1:delay-1)=temp;
 end
 
 bet1=bet;
 
 p=z+bet*p;
 
end

% estimate of maximum accuracy
ub=u*nb;
normglob=0.2*(ub+normest);
normglob1=5*(ub+normest1);

iprint=1;
if iprint == 1
 disp('------------------------')
 
 str1=sprintf(' precond = %s %g',precond,param);
 disp([str1])
 trueresi=norm(b-a*x);
 
 str=sprintf(' number of iterations = %g ',nit);
 disp(' ')
 disp(str)
 
 % Estimate of A-norm at convergence (Gauss)
 str=sprintf(' estimate of A-norm at convergence = %g ',gest(end));
 disp(' ')
 disp(str)
 
 % "true" residual
 str=sprintf(' norm of "true" residual at convergence = %g ',trueresi);
 disp(' ')
 disp(str)
 disp(' ')

 str=sprintf(' global estimates of max accuracy = %g, %g,',normglob,normglob1);
 str1=sprintf(' ratio of the norm of the true residual with estimate = %g, %g',trueresi/normglob,trueresi/normglob1);
 disp([str str1])
 str3=sprintf(' relative norm of the computed residual = %g',sqrt(resid/r0));
 disp(' ')
 disp(str3)
end
 

