%MMQ_RUN_TEST_TRACE_EST run the test for the trace estimator
%
% Author Urs von Matt
%

m = 100;
n = 50;
c = -0.6;
noise = 1E-8;
mmq_test_trace_est (m, n, c, noise);

noise = 1E-6;
mmq_test_trace_est (m, n, c, noise);

noise = 1E-4;
mmq_test_trace_est (m, n, c, noise);

noise = 1E-2;
mmq_test_trace_est (m, n, c, noise);


m = 1000;
n = 500;
c = -0.06;
noise = 1E-8;
mmq_test_trace_est (m, n, c, noise);

noise = 1E-6;
mmq_test_trace_est (m, n, c, noise);

noise = 1E-4;
mmq_test_trace_est (m, n, c, noise);

noise = 1E-2;
mmq_test_trace_est (m, n, c, noise);


m = 10000;
n = 5000;
c = -0.006;
noise = 1E-8;
mmq_test_trace_est (m, n, c, noise);

noise = 1E-6;
mmq_test_trace_est (m, n, c, noise);

noise = 1E-4;
mmq_test_trace_est (m, n, c, noise);

noise = 1E-2;
mmq_test_trace_est (m, n, c, noise);
