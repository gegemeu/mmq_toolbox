function ut0 = mmq_fcorner (lambda,y,u,s,v)
%MMQ_FCORNER computes the rotated values of the l-curve
% computes the log of the function
%
% Author  G. Meurant
% Jan 2007
%

[m_lambda, n_lambda] = size (lambda);
ut0 = zeros (m_lambda, n_lambda);
N = m_lambda * n_lambda;

lambda=10.^lambda;

d = u' * y;

nrri=zeros(N,1);
nxxi=nrri;
nrrr=nrri;
nxxx=nrri;

for i = 1:N
 if lambda (i) < 0
  error ('MMQ_FCORNER: lambda (i) < 0');
 end
 mu = lambda (i);
 
 % compute the norm of c-Ax using the  singular values of A
 
 t = s.^2 + mu;
 num=  sum ((mu*d ./ t).^2);
 
 % norm of x
 
 den=sum((s .* d ./ t).^2);
 
 nri=sqrt(num);
 nxi=sqrt(den);
 
 nrri(i)=nri;
 nxxi(i)=nxi;
 
end

lnr=log10(nrri);
lnx=log10(nxxi);

% locate the origin (in log scale)

origin=mmq_l_origin(lnr,lnx);

% change the origin

lnr=lnr-origin(1);
lnx=lnx-origin(2);

% rotate by -pi/4

[nr,nx]=mmq_rotat(lnr,lnx,-pi/4);

fig=0;
if fig == 1
 loglog(nrri,nxxi,'o-')
 pause
 figure
 plot(nr,nx,'ro-')
 pause
end

ut0=nx;