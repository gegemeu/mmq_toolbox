%MMQ_RUN_TEST_GCV_FOXGOOD_LARGE run GCV for the Foxgood problem
%
% Author G. Meurant Dec 2006
%

warning off

% Severely ill-posed test problem
% (regutools/foxgood)

gcase = 4;
m=500;
n=500;

noise = 1E-7;
mmq_test_gcv;

pause

noise = 1E-5;
mmq_test_gcv;

pause

noise = 1E-3;
mmq_test_gcv;

pause

noise = 1E-1;
mmq_test_gcv;

pause

noise = 10;
mmq_test_gcv;


warning on